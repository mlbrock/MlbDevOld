/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	Keyword Matching Logic (KMLFUNCS) Program Module								*/
/*	***********************************************************************	*/
/*
	File Name			:	%M%

	File Version		:	%I%

	Last Extracted		:	%D%	%T%

	Last Updated		:	%E%	%U%

	File Description	:	Sorts an array of 'KML_SYMBOL' structures.

	Revision History	:	1998-03-19 --- Creation.
									Michael L. Brock
*/
/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*		Necessary include files . . .														*/
/*	***********************************************************************	*/

#include "kmlfuncs.h"

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	BOH

	NAME        :	KML_SORT_SymbolList

	SYNOPSIS    :	void KML_SORT_SymbolList(case_flag, count, list);

						int           case_flag;

						unsigned int  count;

						KML_SYMBOL   *list;

	DESCRIPTION :	Sorts an array of ''KML_SYMBOL'' structures using
						the comparison function ``KML_SCMP_Symbol``.

						The ``ptr`` member of the ''KML_SYMBOL''
						structure is used as the basis of the comparison in
						the sort.

	PARAMETERS  :	Parameters to this function are as follow:

						(.) ``case_flag`` specifies whether the sort is to be
						performed in a case-sensitive fashion.

						(..) If ``case_flag`` is a non-zero value, the sort
						will be performed in a case-sensitive fashion.

						(..) If ``case_flag`` is ''0'', the sort will be
						performed in a case-insensitive fashion.

						(.) ``count`` is the number of elements in the array
						``list``.

						(.) ``list`` is the array of ''KML_SYMBOL'' structures
						which is to be sorted by this function.

	RETURNS     :	Void.

	NOTES       :	

	CAVEATS     :	

	SEE ALSO    :	KML_FREE_SymbolList
						KML_COPY_SymbolList
						KML_INIT_SymbolList
						KML_SCMP_Symbol

	EXAMPLES    :	

	AUTHOR      :	Michael L. Brock

	COPYRIGHT   :	Copyright 1998 Michael L. Brock

	OUTPUT INDEX:	KML_SORT_SymbolList
						Sort Functions:Database:KML_SORT_SymbolList
						KML_SYMBOL Functions:KML_SORT_SymbolList

	PUBLISH XREF:	KML_SORT_SymbolList

	PUBLISH NAME:	KML_SORT_SymbolList

	ENTRY CLASS	:	Sort Functions

EOH */
/*	***********************************************************************	*/
void KML_SORT_SymbolList(case_flag, match_count, match_list)
int           case_flag;
unsigned int  match_count;
KML_SYMBOL   *match_list;
{
	STR_ARRAY_qsort(((void *) case_flag), match_count, ((void *) match_list),
		sizeof(KML_SYMBOL),
		((int (*)(void *, const void *, const void *, size_t))
		KML_SCMP_Symbol));
}
/*	***********************************************************************	*/

