/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	Keyword Matching Logic (KMLFUNCS) Program Module								*/
/*	***********************************************************************	*/
/*
	File Name			:	%M%

	File Version		:	%I%

	Last Extracted		:	%D%	%T%

	Last Updated		:	%E%	%U%

	File Description	:	Compares two 'KML_BLOCK' structures.

	Revision History	:	1998-03-19 --- Creation.
									Michael L. Brock
*/
/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*		Necessary include files . . .														*/
/*	***********************************************************************	*/

#include <string.h>

#include "kmlfuncs.h"

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	BOH

	NAME        :	KML_SCMP_Block

	SYNOPSIS    :	return_code = KML_SCMP_Block(case_flag, ptr_1,
							ptr_2, data_length);

						int              return_code;

						void            *case_flag;

						const KML_BLOCK *ptr_1;

						const KML_BLOCK *ptr_2;

						size_t           data_length;

	DESCRIPTION :	Compares two ''KML_BLOCK'' structures to
						determine their equivalence.

						The ``start_ptr`` member of the ''KML_BLOCK''
						structure is used as the basis of the comparison.

	PARAMETERS  :	Parameters to this function are as follow:

						(.) ``case_flag`` is an ''int'' cast to a ''void'' pointer
						in accordance with the requirements of the STRFUNCS list
						functions.

						(..) If ``((int) case_flag)`` evaluates to a non-zero
						value, the comparison will be performed in a
						case-sensitive fashion.

						(..) If ``((int) case_flag)`` evaluates to a zero
						value, the comparison will be performed in a
						case-insensitive fashion.

						(.) ``ptr_1`` points to the first ''KML_BLOCK''
						structure to be compared.

						(.) ``ptr_2`` points to the second ''KML_BLOCK''
						structure to be compared.

						(.) ``data_length`` is the size the areas to which
						``ptr_1`` and ``ptr_2`` point. Because it is unnecessary
						to the comparison of ''KML_BLOCK'' structures,
						it may be zero (''0'').

	RETURNS     :	Returns from this function are as follow:

						(.) negative if the first ''KML_BLOCK'' structure
						is less than second.

						(.) positive if the first ''KML_BLOCK'' structure
						is greater than second.

						(.) zero if the structures are equivalent.

	NOTES       :  The ``data_length`` parameter is present only because this
						function is used internally by the STRFUNCS list functions.
						This parameter provides function-call compatibility with
						other, more generic, functions such as
						``KML_SORT_BlockList``.

	CAVEATS     :	

	SEE ALSO    :	

	EXAMPLES    :	

	AUTHOR      :	Michael L. Brock

	COPYRIGHT   :	Copyright 1998 Michael L. Brock

	OUTPUT INDEX:	KML_SCMP_Block
						Comparison Functions:KML_SCMP_Block
						KML_BLOCK Functions:KML_SCMP_Block

	PUBLISH XREF:	KML_SCMP_Block

	PUBLISH NAME:	KML_SCMP_Block

	ENTRY CLASS	:	Comparison Functions

EOH */
/*	***********************************************************************	*/
int KML_SCMP_Block(case_flag, ptr_1, ptr_2, data_length)
void            *case_flag;
const KML_BLOCK *ptr_1;
const KML_BLOCK *ptr_2;
size_t           data_length;
{
	return((((int) case_flag)) ?
		strcmp(ptr_1->start_ptr, ptr_2->start_ptr) :
		stricmp(ptr_1->start_ptr, ptr_2->start_ptr));
}
/*	***********************************************************************	*/

