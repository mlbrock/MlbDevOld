/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	Keyword Matching Logic (KMLFUNCS) Program Module								*/
/*	***********************************************************************	*/
/*
	File Name			:	%M%

	File Version		:	%I%

	Last Extracted		:	%D%	%T%

	Last Updated		:	%E%	%U%

	File Description	:	Compares two 'KML_STRING' structures.

	Revision History	:	1998-03-19 --- Creation.
									Michael L. Brock
*/
/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*		Necessary include files . . .														*/
/*	***********************************************************************	*/

#include <string.h>

#include "kmlfuncs.h"

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	BOH

	NAME        :	KML_SCMP_String

	SYNOPSIS    :	return_code = KML_SCMP_String(case_flag, ptr_1,
							ptr_2, data_length);

						int               return_code;

						void             *case_flag;

						const KML_STRING *ptr_1;

						const KML_STRING *ptr_2;

						size_t            data_length;

	DESCRIPTION :	Compares two ''KML_STRING'' structures to
						determine their equivalence.

						The ``start_ptr`` member of the ''KML_STRING''
						structure is used as the basis of the comparison.

	PARAMETERS  :	Parameters to this function are as follow:

						(.) ``case_flag`` is an ''int'' cast to a ''void'' pointer
						in accordance with the requirements of the STRFUNCS list
						functions.

						(..) If ``((int) case_flag)`` evaluates to a non-zero
						value, the comparison will be performed in a
						case-sensitive fashion.

						(..) If ``((int) case_flag)`` evaluates to a zero
						value, the comparison will be performed in a
						case-insensitive fashion.

						(.) ``ptr_1`` points to the first ''KML_STRING''
						structure to be compared.

						(.) ``ptr_2`` points to the second ''KML_STRING''
						structure to be compared.

						(.) ``data_length`` is the size the areas to which
						``ptr_1`` and ``ptr_2`` point. Because it is unnecessary
						to the comparison of ''KML_STRING'' structures,
						it may be zero (''0'').

	RETURNS     :	Returns from this function are as follow:

						(.) negative if the first ''KML_STRING'' structure
						is less than second.

						(.) positive if the first ''KML_STRING'' structure
						is greater than second.

						(.) zero if the structures are equivalent.

	NOTES       :  The ``data_length`` parameter is present only because this
						function is used internally by the STRFUNCS list functions.
						This parameter provides function-call compatibility with
						other, more generic, functions such as
						``KML_SORT_StringList``.

	CAVEATS     :	

	SEE ALSO    :	

	EXAMPLES    :	

	AUTHOR      :	Michael L. Brock

	COPYRIGHT   :	Copyright 1998 Michael L. Brock

	OUTPUT INDEX:	KML_SCMP_String
						Comparison Functions:KML_SCMP_String
						KML_STRING Functions:KML_SCMP_String

	PUBLISH XREF:	KML_SCMP_String

	PUBLISH NAME:	KML_SCMP_String

	ENTRY CLASS	:	Comparison Functions

EOH */
/*	***********************************************************************	*/
int KML_SCMP_String(case_flag, ptr_1, ptr_2, data_length)
void             *case_flag;
const KML_STRING *ptr_1;
const KML_STRING *ptr_2;
size_t            data_length;
{
	return((((int) case_flag)) ?
		strcmp(ptr_1->start_ptr, ptr_2->start_ptr) :
		stricmp(ptr_1->start_ptr, ptr_2->start_ptr));
}
/*	***********************************************************************	*/

