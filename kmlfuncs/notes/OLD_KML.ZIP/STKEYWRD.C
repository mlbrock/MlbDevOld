/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	Keyword Matching Logic (KMLFUNCS) Program Module								*/
/*	***********************************************************************	*/
/*
	File Name			:	%M%

	File Version		:	%I%

	Last Extracted		:	%D%	%T%

	Last Updated		:	%E%	%U%

	File Description	:	Sorts an array of 'KML_KEYWORD' structures.

	Revision History	:	1998-03-19 --- Creation.
									Michael L. Brock
*/
/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*		Necessary include files . . .														*/
/*	***********************************************************************	*/

#include "kmlfuncs.h"

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	BOH

	NAME        :	KML_SORT_KeywordList

	SYNOPSIS    :	void KML_SORT_KeywordList(case_flag, count, list);

						int           case_flag;

						unsigned int  count;

						KML_KEYWORD  *list;

	DESCRIPTION :	Sorts an array of ''KML_KEYWORD'' structures using
						the comparison function ``KML_SCMP_Keyword``.

						The ``keyword`` member of the ''KML_KEYWORD''
						structure is used as the basis of the comparison in
						the sort.

	PARAMETERS  :	Parameters to this function are as follow:

						(.) ``case_flag`` specifies whether the sort is to be
						performed in a case-sensitive fashion.

						(..) If ``case_flag`` is a non-zero value, the sort
						will be performed in a case-sensitive fashion.

						(..) If ``case_flag`` is ''0'', the sort will be
						performed in a case-insensitive fashion.

						(.) ``count`` is the number of elements in the array
						``list``.

						(.) ``list`` is the array of ''KML_KEYWORD'' structures
						which is to be sorted by this function.

	RETURNS     :	Void.

	NOTES       :	

	CAVEATS     :	

	SEE ALSO    :	KML_FREE_KeywordList
						KML_COPY_KeywordList
						KML_INIT_KeywordList
						KML_SCMP_Keyword

	EXAMPLES    :	

	AUTHOR      :	Michael L. Brock

	COPYRIGHT   :	Copyright 1998 Michael L. Brock

	OUTPUT INDEX:	KML_SORT_KeywordList
						Sort Functions:Database:KML_SORT_KeywordList
						KML_KEYWORD Functions:KML_SORT_KeywordList

	PUBLISH XREF:	KML_SORT_KeywordList

	PUBLISH NAME:	KML_SORT_KeywordList

	ENTRY CLASS	:	Sort Functions

EOH */
/*	***********************************************************************	*/
void KML_SORT_KeywordList(case_flag, match_count, match_list)
int           case_flag;
unsigned int  match_count;
KML_KEYWORD  *match_list;
{
	STR_ARRAY_qsort(((void *) case_flag), match_count, ((void *) match_list),
		sizeof(KML_KEYWORD),
		((int (*)(void *, const void *, const void *, size_t))
		KML_SCMP_Keyword));
}
/*	***********************************************************************	*/

