/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	Keyword Matching Logic (KMLFUNCS) Program Module								*/
/*	***********************************************************************	*/
/*
	File Name			:	%M%

	File Version		:	%I%

	Last Extracted		:	%D%	%T%

	Last Updated		:	%E%	%U%

	File Description	:	Sorts an array of 'KML_COMMENT' structures.

	Revision History	:	1998-03-19 --- Creation.
									Michael L. Brock
*/
/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*		Necessary include files . . .														*/
/*	***********************************************************************	*/

#include "kmlfuncs.h"

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	BOH

	NAME        :	KML_SORT_CommentList

	SYNOPSIS    :	void KML_SORT_CommentList(case_flag, count, list);

						int           case_flag;

						unsigned int  count;

						KML_COMMENT  *list;

	DESCRIPTION :	Sorts an array of ''KML_COMMENT'' structures using
						the comparison function ``KML_SCMP_Comment``.

						The ``start_ptr`` member of the ''KML_COMMENT''
						structure is used as the basis of the comparison in
						the sort.

	PARAMETERS  :	Parameters to this function are as follow:

						(.) ``case_flag`` specifies whether the sort is to be
						performed in a case-sensitive fashion.

						(..) If ``case_flag`` is a non-zero value, the sort
						will be performed in a case-sensitive fashion.

						(..) If ``case_flag`` is ''0'', the sort will be
						performed in a case-insensitive fashion.

						(.) ``count`` is the number of elements in the array
						``list``.

						(.) ``list`` is the array of ''KML_COMMENT'' structures
						which is to be sorted by this function.

	RETURNS     :	Void.

	NOTES       :	

	CAVEATS     :	

	SEE ALSO    :	KML_FREE_CommentList
						KML_COPY_CommentList
						KML_INIT_CommentList
						KML_SCMP_Comment

	EXAMPLES    :	

	AUTHOR      :	Michael L. Brock

	COPYRIGHT   :	Copyright 1998 Michael L. Brock

	OUTPUT INDEX:	KML_SORT_CommentList
						Sort Functions:Database:KML_SORT_CommentList
						KML_COMMENT Functions:KML_SORT_CommentList

	PUBLISH XREF:	KML_SORT_CommentList

	PUBLISH NAME:	KML_SORT_CommentList

	ENTRY CLASS	:	Sort Functions

EOH */
/*	***********************************************************************	*/
void KML_SORT_CommentList(case_flag, match_count, match_list)
int           case_flag;
unsigned int  match_count;
KML_COMMENT  *match_list;
{
	STR_ARRAY_qsort(((void *) case_flag), match_count, ((void *) match_list),
		sizeof(KML_COMMENT),
		((int (*)(void *, const void *, const void *, size_t))
		KML_SCMP_Comment));
}
/*	***********************************************************************	*/


