/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	Keyword Matching Logic (KMLFUNCS) Program Module								*/
/*	***********************************************************************	*/
/*
	File Name			:	%M%

	File Version		:	%I%

	Last Extracted		:	%D%	%T%

	Last Updated		:	%E%	%U%

	File Description	:	Matches names.

	Revision History	:	1998-03-19 --- Creation.
									Michael L. Brock
*/
/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*		Necessary include files . . .														*/
/*	***********************************************************************	*/

#include <memory.h>
#include <stdlib.h>
#include <string.h>

#include <genfuncs.h>

#include "kmlfuncs.h"

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/
#ifndef NARGS
void KML_BuildCharIndexForNames(unsigned int name_count, KML_NAME *name_list,
	int case_flag, KML_CHAR_INDEX *char_index);
#else
void KML_BuildCharIndexForNames();
#endif /* #ifndef NARGS */
/*	***********************************************************************	*/

/*	***********************************************************************	*/
int KML_MatchNames(domain_ptr, in_string, error_text)
KML_DOMAIN *domain_ptr;
const char *in_string;
char       *error_text;
{
	int             return_code = KMLFUNCS_SUCCESS;
	int             min_length  = 1;
	const char     *tmp_ptr;
	const char     *in_ptr;
	unsigned int    match_count;
	unsigned int    match_index;
	KML_NAME       *name_ptr;
	KML_MATCH       match_data;
	KML_CHAR_INDEX *char_index_ptr;
	KML_CHAR_INDEX  char_index_list[UCHAR_MAX + 1];

	if (!domain_ptr->name_count)
		goto EXIT_FUNCTION;

	KML_BuildCharIndexForNames(domain_ptr->name_count, domain_ptr->name_list,
		KMLFUNCS_FALSE, char_index_list);

	/*
		If each of the characters which may introduce a name is not also in
		the list of subsequent valid characters for names, then the minimum
		length of a name is two characters.
	*/
	tmp_ptr = domain_ptr->name_list->first_char;
	while (*tmp_ptr) {
		if (strchr(domain_ptr->name_list->other_chars, *tmp_ptr) == NULL) {
			min_length = 2;
			break;
		}
		tmp_ptr++;
	}

	in_ptr      = in_string;
	match_count = domain_ptr->match_count;
	match_index = 0;

	while (*in_ptr) {
		if ((match_index < match_count) &&
			(in_ptr == domain_ptr->match_list[match_index].ptr)) {
			in_ptr += domain_ptr->match_list[match_index].length;
			match_index++;
		}
		else if (((char_index_ptr = (char_index_list +
			((unsigned int) *((unsigned char *) in_ptr))))->count) &&
			((min_length == 1) || (*(in_ptr + 1) &&
			(strchr(char_index_ptr->type_ptr.name_ptr->other_chars,
			*(in_ptr + 1)) != NULL)))) {
			KML_INIT_Match(&match_data);
			name_ptr                     = char_index_ptr->type_ptr.name_ptr;
			match_data.type              = KML_TYPE_NAME;
			match_data.type_value        = 0L;
			match_data.type_ptr.name_ptr = name_ptr;
			match_data.ptr               = in_ptr;
			in_ptr++;
			while (*in_ptr &&
				(strchr(char_index_ptr->type_ptr.name_ptr->other_chars,
				*in_ptr) != NULL) && ((match_index < match_count) ||
				(in_ptr < domain_ptr->match_list[match_index].ptr)))
				in_ptr++;
			match_data.closure_ptr = (*in_ptr) ? (in_ptr - 1) : in_ptr;
			match_data.length      = ((unsigned int)
				(match_data.closure_ptr - match_data.ptr)) + 1;
			while ((match_index < match_count) &&
				(in_ptr > domain_ptr->match_list[match_index].ptr))
				match_index++;
			if ((return_code = KML_AddMatch(domain_ptr, &match_data,
				error_text)) != KMLFUNCS_SUCCESS)
				goto EXIT_FUNCTION;
		}
		else
			in_ptr++;
	}

	KML_SORT_MatchList(domain_ptr->match_count, domain_ptr->match_list);

EXIT_FUNCTION:

	return(return_code);
}
/*	***********************************************************************	*/

/*	***********************************************************************	*/
void KML_BuildCharIndexForNames(name_count, name_list, case_flag, char_index)
unsigned int    name_count;
KML_NAME       *name_list;
int             case_flag;
KML_CHAR_INDEX *char_index;
{
	const unsigned char *tmp_ptr;
	unsigned char        tmp_char;

	KML_INIT_CharIndexList(UCHAR_MAX, char_index);

	if (name_count) {
		tmp_ptr = ((const unsigned char *) name_list->first_char);
		while (*tmp_ptr) {
			tmp_char = *tmp_ptr;
			if (case_flag && isalpha(*tmp_ptr)) {
				tmp_char                                                =
					STRFUNCS_toupper(tmp_char);
				char_index[((unsigned int) tmp_char)].type_ptr.name_ptr =
					name_list;
				char_index[((unsigned int) tmp_char)].count             = 1;
				tmp_char                                                =
					STRFUNCS_tolower(tmp_char);
			}
			char_index[((unsigned int) tmp_char)].type_ptr.name_ptr = name_list;
			char_index[((unsigned int) tmp_char)].count             = 1;
			tmp_ptr++;
		}
	}
}
/*	***********************************************************************	*/

#ifdef TEST_MAIN

#ifndef NARGS
int main(int argc, char **argv);
#else
int main();
#endif /* #ifndef NARGS */

int main(argc, argv)
int    argc;
char **argv;
{
	int           return_code;
	unsigned int  count_1;
	unsigned int  count_2;
	KML_DOMAIN    domain_data;
	char         *file_buffer;
	char          error_text[KMLFUNCS_MAX_ERROR_TEXT];

	fprintf(stderr, "Test routine for 'KML_MatchNames()'\n");
	fprintf(stderr, "---- ------- --- --------------------\n\n");

	if (argc == 1) {
		sprintf(error_text, "USAGE:\n   %s <source-file> [<source-file> ...]",
			argv[0]);
		return_code = KMLFUNCS_BAD_ARGS_FAILURE;
	}
	else if ((return_code = KML_TEST_InitializeDomain("c", &domain_data,
		error_text)) == KMLFUNCS_SUCCESS) {
		for (count_1 = 1; count_1 < argc; count_1++) {
			STR_EMIT_CharLine('=', 78, NULL, NULL);
			printf("File: %s\n", argv[count_1]);
			STR_EMIT_CharLine('-', 78, NULL, NULL);
			if ((return_code = KML_TFREAD_ReadFileBuffer(argv[count_1], NULL,
				&file_buffer, error_text)) != KMLFUNCS_SUCCESS)
				break;
			if ((return_code = KML_MatchNames(&domain_data, file_buffer,
				error_text)) != KMLFUNCS_SUCCESS)
				break;
			for (count_2 = 0; count_2 < domain_data.match_count; count_2++) {
				printf("%-*.*s\n", domain_data.match_list[count_2].length,
					domain_data.match_list[count_2].length,
					domain_data.match_list[count_2].ptr);
				STR_EMIT_CharLine('-', 78, NULL, NULL);
			}
			fprintf(stderr, "File: %s --- %u matches.\n", argv[count_1],
				domain_data.match_count);
			free(file_buffer);
			KML_FREE_MatchList(&domain_data.match_count,
				&domain_data.match_list);
		}              
		STR_EMIT_CharLine('=', 78, NULL, NULL);
		KML_FREE_Domain(&domain_data);
	}

	if (return_code != KMLFUNCS_SUCCESS)
		fprintf(stderr, "\n\nERROR: %s\n", error_text);

	return(return_code);
}

#endif /* #ifdef TEST_MAIN */


