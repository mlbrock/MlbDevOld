/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	Keyword Matching Logic (KMLFUNCS) Program Module								*/
/*	***********************************************************************	*/
/*
	File Name			:	%M%

	File Version		:	%I%

	Last Extracted		:	%D%	%T%

	Last Updated		:	%E%	%U%

	File Description	:	Matches blocks.

	Revision History	:	1998-03-19 --- Creation.
									Michael L. Brock
*/
/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*		Necessary include files . . .														*/
/*	***********************************************************************	*/

#include <memory.h>
#include <stdlib.h>
#include <string.h>

#include <genfuncs.h>

#include "kmlfuncs.h"

/*	***********************************************************************	*/

/*	***********************************************************************	*/
int KML_MatchBlocks(domain_ptr, in_string, error_text)
KML_DOMAIN *domain_ptr;
const char *in_string;
char       *error_text;
{
	int             return_code = KMLFUNCS_SUCCESS;
	unsigned int    count_1;
	const char     *in_ptr;
	unsigned int    in_length;
	const char     *tmp_ptr;
	unsigned int    tmp_length;
	unsigned int    match_count;
	unsigned int    match_index;
	KML_BLOCK      *block_ptr;
	KML_MATCH       match_data;
	int             found_flag;
	int             internal_flag;
	unsigned int    internal_count;
	KML_CHAR_INDEX *char_index_ptr;
	KML_CHAR_INDEX  char_index_list[UCHAR_MAX + 1];
#ifndef NARGS
	int             (*cmp_func)(const char *, const char *, size_t);
#else
	int             (*cmp_func)();
#endif /* #ifndef NARGS */

	KML_BuildCharIndex(domain_ptr->block_count, domain_ptr->block_list,
		sizeof(KML_BLOCK), offsetof(KML_BLOCK, start_ptr),
		domain_ptr->block_case_flag, char_index_list);

	in_ptr      = in_string;
	in_length   = strlen(in_string);
	match_count = domain_ptr->match_count;
	match_index = 0;                       
	cmp_func    = (domain_ptr->block_case_flag) ? strncmp : strnicmp;

	while (*in_ptr) {
		if ((match_index < match_count) &&
			(in_ptr == domain_ptr->match_list[match_index].ptr)) {
			in_ptr    += domain_ptr->match_list[match_index].length;
			in_length -= domain_ptr->match_list[match_index].length;
			match_index++;
		}
		else if ((char_index_ptr = (char_index_list +
			((unsigned int) *((unsigned char *) in_ptr))))->count) {
			found_flag  = KMLFUNCS_FALSE;
			/*
					We could do this (and the corresponding decrement) within
				the 'for' loop, but CodeGuard complains under NT.
			*/
			block_ptr = char_index_ptr->type_ptr.block_ptr + 1;
			for (count_1 = 0; count_1 < char_index_ptr->count; count_1++) {
				block_ptr--;
				if ((block_ptr->start_length <= in_length) &&
					(!(*cmp_func)(block_ptr->start_ptr, in_ptr,
					block_ptr->start_length))) {
					found_flag     = KMLFUNCS_TRUE;
					internal_flag  = KMLFUNCS_FALSE;
					internal_count = 0;
					KML_INIT_Match(&match_data);
					match_data.type                = KML_TYPE_BLOCK;
					match_data.type_value          = 0L;
					match_data.type_ptr.block_ptr  = block_ptr;
					match_data.length              = block_ptr->start_length;
					match_data.ptr                 = in_ptr;
					in_ptr                        += block_ptr->start_length;
					in_length                     -= block_ptr->start_length;
					tmp_ptr                        = in_ptr;
					tmp_length                     = in_length;
					while (*tmp_ptr) {
						if ((match_index < match_count) &&
							(tmp_ptr == domain_ptr->match_list[match_index].ptr)) {
							tmp_ptr    +=
								domain_ptr->match_list[match_index].length;
							tmp_length -=
								domain_ptr->match_list[match_index].length;
							match_index++;
						}
						else if ((block_ptr->start_length <= tmp_length) &&
							(!(*cmp_func)(block_ptr->start_ptr, tmp_ptr,
							block_ptr->start_length))) {
							internal_flag = KMLFUNCS_TRUE;
							internal_count++;
							tmp_ptr    += block_ptr->start_length;
							tmp_length -= block_ptr->start_length;
						}
						else if ((block_ptr->end_length <= tmp_length) &&
							(!(*cmp_func)(block_ptr->end_ptr, tmp_ptr,
							block_ptr->end_length))) {
							if (internal_count--) {
								tmp_ptr    += block_ptr->end_length;
								tmp_length -= block_ptr->end_length;
							}
							else {
								match_data.closure_ptr  = tmp_ptr +
									(block_ptr->end_length - 1);
								tmp_ptr                 += block_ptr->end_length;
								break;
							}
						}
						else {
							tmp_ptr++;
							tmp_length--;
						}
					}
					if (match_data.closure_ptr == NULL)
						match_data.closure_ptr = tmp_ptr;
					while ((match_index < match_count) &&
						(in_ptr > domain_ptr->match_list[match_index].ptr))
						match_index++;
					if ((return_code = KML_AddMatch(domain_ptr, &match_data,
						error_text)) != KMLFUNCS_SUCCESS)
						goto EXIT_FUNCTION;
					break;
				}
			}
			if (found_flag != KMLFUNCS_TRUE) {
				in_ptr++;
				in_length--;
			}
		}
		else {
			in_ptr++;
			in_length--;
		}
	}

	KML_SORT_MatchList(domain_ptr->match_count, domain_ptr->match_list);

EXIT_FUNCTION:

	return(return_code);
}
/*	***********************************************************************	*/

#ifdef TEST_MAIN

#ifndef NARGS
int main(int argc, char **argv);
#else
int main();
#endif /* #ifndef NARGS */

int main(argc, argv)
int    argc;
char **argv;
{
	int           return_code;
	unsigned int  count_1;
	unsigned int  count_2;
	KML_DOMAIN    domain_data;
	char         *file_buffer;
	char          error_text[KMLFUNCS_MAX_ERROR_TEXT];

	fprintf(stderr, "Test routine for 'KML_MatchBlocks()'\n");
	fprintf(stderr, "---- ------- --- -------------------\n\n");

	if (argc == 1) {
		sprintf(error_text, "USAGE:\n   %s <source-file> [<source-file> ...]",
			argv[0]);
		return_code = KMLFUNCS_BAD_ARGS_FAILURE;
	}
	else if ((return_code = KML_TEST_InitializeDomain("c", &domain_data,
		error_text)) == KMLFUNCS_SUCCESS) {
		for (count_1 = 1; count_1 < argc; count_1++) {
			STR_EMIT_CharLine('=', 78, NULL, NULL);
			printf("File: %s\n", argv[count_1]);
			STR_EMIT_CharLine('-', 78, NULL, NULL);
			if ((return_code = KML_TFREAD_ReadFileBuffer(argv[count_1], NULL,
				&file_buffer, error_text)) != KMLFUNCS_SUCCESS)
				break;
			if ((return_code = KML_MatchBlocks(&domain_data, file_buffer,
				error_text)) != KMLFUNCS_SUCCESS)
				break;
			for (count_2 = 0; count_2 < domain_data.match_count; count_2++) {
				printf("%-*.*s\n", domain_data.match_list[count_2].length,
					domain_data.match_list[count_2].length,
					domain_data.match_list[count_2].ptr);
				STR_EMIT_CharLine('-', 78, NULL, NULL);
			}
			fprintf(stderr, "File: %s --- %u matches.\n", argv[count_1],
				domain_data.match_count);
			free(file_buffer);
			KML_FREE_MatchList(&domain_data.match_count,
				&domain_data.match_list);
		}              
		STR_EMIT_CharLine('=', 78, NULL, NULL);
		KML_FREE_Domain(&domain_data);
	}

	if (return_code != KMLFUNCS_SUCCESS)
		fprintf(stderr, "\n\nERROR: %s\n", error_text);

	return(return_code);
}

#endif /* #ifdef TEST_MAIN */


