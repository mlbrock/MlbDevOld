/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	Keyword Matching Logic (KMLFUNCS) Program Module								*/
/*	***********************************************************************	*/
/*
	File Name			:	%M%

	File Version		:	%I%

	Last Extracted		:	%D%	%T%

	Last Updated		:	%E%	%U%

	File Description	:	Matches strings.

	Revision History	:	1998-03-19 --- Creation.
									Michael L. Brock
*/
/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*		Necessary include files . . .														*/
/*	***********************************************************************	*/

#include <memory.h>
#include <stdlib.h>
#include <string.h>

#include <genfuncs.h>

#include "kmlfuncs.h"

/*	***********************************************************************	*/

/*	***********************************************************************	*/
int KML_MatchStrings(domain_ptr, in_string, error_text)
KML_DOMAIN  *domain_ptr;
const char  *in_string;
char        *error_text;
{
	int             return_code = KMLFUNCS_SUCCESS;
	const char     *in_ptr;
	KML_STRING     *string_ptr;
	KML_MATCH       match_data;
	KML_CHAR_INDEX *char_index_ptr;
	KML_CHAR_INDEX  char_index_list[UCHAR_MAX + 1];

	KML_BuildCharIndex(domain_ptr->string_count, domain_ptr->string_list,
		sizeof(KML_STRING), offsetof(KML_STRING, start_ptr), KMLFUNCS_FALSE,
		char_index_list);

	in_ptr = in_string;

	while (*in_ptr) {
		if ((char_index_ptr = (char_index_list +
			((unsigned int) *((unsigned char *) in_ptr))))->count) {
			KML_INIT_Match(&match_data);
			string_ptr                     = char_index_ptr->type_ptr.string_ptr;
			match_data.type                = KML_TYPE_STRING;
			match_data.type_value          = 0L;
			match_data.type_ptr.string_ptr = string_ptr;
			match_data.ptr                 = in_ptr;
			in_ptr++;
			while (*in_ptr) {
				if (!strcmp(in_ptr, string_ptr->escape_ptr))
					in_ptr += string_ptr->escape_length;
				else if (*in_ptr == *string_ptr->end_ptr)
					break;
				else
					in_ptr++;
			}
			match_data.closure_ptr = in_ptr;
			if (*in_ptr == *string_ptr->end_ptr) {
				match_data.length  = ((unsigned int)
					(in_ptr - match_data.ptr)) + 1;
				in_ptr++;
			}
			else
				match_data.length  = ((unsigned int)
					(in_ptr - match_data.ptr));
			if ((return_code = KML_AddMatch(domain_ptr, &match_data,
				error_text)) != KMLFUNCS_SUCCESS)
				goto EXIT_FUNCTION;
		}
		else
			in_ptr++;
	}

	KML_SORT_MatchList(domain_ptr->match_count, domain_ptr->match_list);

EXIT_FUNCTION:

	return(return_code);
}
/*	***********************************************************************	*/

#ifdef TEST_MAIN

#ifndef NARGS
int main(int argc, char **argv);
#else
int main();
#endif /* #ifndef NARGS */

int main(argc, argv)
int    argc;
char **argv;
{
	int           return_code;
	unsigned int  count_1;
	unsigned int  count_2;
	KML_DOMAIN    domain_data;
	char         *file_buffer;
	char          error_text[KMLFUNCS_MAX_ERROR_TEXT];

	fprintf(stderr, "Test routine for 'KML_MatchStrings()'\n");
	fprintf(stderr, "---- ------- --- --------------------\n\n");

	if (argc == 1) {
		sprintf(error_text, "USAGE:\n   %s <source-file> [<source-file> ...]",
			argv[0]);
		return_code = KMLFUNCS_BAD_ARGS_FAILURE;
	}
	else if ((return_code = KML_TEST_InitializeDomain("c", &domain_data,
		error_text)) == KMLFUNCS_SUCCESS) {
		for (count_1 = 1; count_1 < argc; count_1++) {
			STR_EMIT_CharLine('=', 78, NULL, NULL);
			printf("File: %s\n", argv[count_1]);
			STR_EMIT_CharLine('-', 78, NULL, NULL);
			if ((return_code = KML_TFREAD_ReadFileBuffer(argv[count_1], NULL,
				&file_buffer, error_text)) != KMLFUNCS_SUCCESS)
				break;
			if ((return_code = KML_MatchStrings(&domain_data, file_buffer,
				error_text)) != KMLFUNCS_SUCCESS)
				break;
			for (count_2 = 0; count_2 < domain_data.match_count; count_2++) {
				printf("%-*.*s\n", domain_data.match_list[count_2].length,
					domain_data.match_list[count_2].length,
					domain_data.match_list[count_2].ptr);
				STR_EMIT_CharLine('-', 78, NULL, NULL);
			}
			fprintf(stderr, "File: %s --- %u matches.\n", argv[count_1],
				domain_data.match_count);
			free(file_buffer);
			KML_FREE_MatchList(&domain_data.match_count,
				&domain_data.match_list);
		}              
		STR_EMIT_CharLine('=', 78, NULL, NULL);
		KML_FREE_Domain(&domain_data);
	}

	if (return_code != KMLFUNCS_SUCCESS)
		fprintf(stderr, "\n\nERROR: %s\n", error_text);

	return(return_code);
}

#endif /* #ifdef TEST_MAIN */


