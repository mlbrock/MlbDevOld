/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	Keyword Matching Logic (KMLFUNCS) Program Module								*/
/*	***********************************************************************	*/
/*
	File Name			:	%M%

	File Version		:	%I%

	Last Extracted		:	%D%	%T%

	Last Updated		:	%E%	%U%

	File Description	:	Matches comments.

	Revision History	:	1998-03-19 --- Creation.
									Michael L. Brock
*/
/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*		Necessary include files . . .														*/
/*	***********************************************************************	*/

#include <memory.h>
#include <stdlib.h>
#include <string.h>

#include <genfuncs.h>

#include "kmlfuncs.h"

/*	***********************************************************************	*/

/*	***********************************************************************	*/
int KML_MatchComments(domain_ptr, in_string, error_text)
KML_DOMAIN *domain_ptr;
const char *in_string;
char       *error_text;
{
	int             return_code = KMLFUNCS_SUCCESS;
	unsigned int    count_1;
	const char     *in_ptr;
	unsigned int    in_length;
	unsigned int    match_count;
	unsigned int    match_index;
	const char     *tmp_ptr;
	KML_COMMENT    *comment_ptr;
	KML_MATCH       match_data;
	int             found_flag;
	KML_CHAR_INDEX *char_index_ptr;
	KML_CHAR_INDEX  char_index_list[UCHAR_MAX + 1];
#ifndef NARGS
	int             (*cmp_func)(const char *, const char *, size_t);
#else
	int             (*cmp_func)();
#endif /* #ifndef NARGS */

	KML_BuildCharIndex(domain_ptr->comment_count, domain_ptr->comment_list,
		sizeof(KML_COMMENT), offsetof(KML_COMMENT, start_ptr),
		domain_ptr->comment_case_flag, char_index_list);

	in_ptr      = in_string;
	in_length   = strlen(in_string);
	match_count = domain_ptr->match_count;
	match_index = 0;
	cmp_func    = (domain_ptr->comment_case_flag) ? strncmp : strnicmp;

	while (*in_ptr) {
		if ((match_index < match_count) &&
			(in_ptr == domain_ptr->match_list[match_index].ptr)) {
			in_ptr    += domain_ptr->match_list[match_index].length;
			in_length -= domain_ptr->match_list[match_index].length;
			match_index++;
		}
		else if ((char_index_ptr = (char_index_list +
			((unsigned int) *((unsigned char *) in_ptr))))->count) {
			found_flag  = KMLFUNCS_FALSE;
			/*
					We could do this (and the corresponding decrement) within
				the 'for' loop, but CodeGuard complains under NT.
			*/
			comment_ptr = char_index_ptr->type_ptr.comment_ptr + 1;
			for (count_1 = 0; count_1 < char_index_ptr->count; count_1++) {
				comment_ptr--;
				if ((comment_ptr->start_length <= in_length) &&
					(!(*cmp_func)(comment_ptr->start_ptr, in_ptr,
					comment_ptr->start_length))) {
					found_flag = KMLFUNCS_TRUE;
					KML_INIT_Match(&match_data);
					match_data.type                 = KML_TYPE_COMMENT;
					match_data.type_value           = 0L;
					match_data.type_ptr.comment_ptr = comment_ptr;
					match_data.ptr                  = in_ptr;
					if (comment_ptr->end_length) {
						in_ptr    += comment_ptr->start_length;
						in_length -= comment_ptr->start_length;
						while (*in_ptr) {
							if ((match_index < match_count) &&
								(in_ptr == domain_ptr->match_list[match_index].ptr)) {
								in_ptr    +=
									domain_ptr->match_list[match_index].length;
								in_length -=
									domain_ptr->match_list[match_index].length;
								match_index++;
							}
							else if ((comment_ptr->end_length <= in_length) &&
								(!(*cmp_func)(comment_ptr->end_ptr, in_ptr,
								comment_ptr->end_length))) {
								match_data.length       = ((unsigned int)
									(in_ptr - match_data.ptr)) +
									comment_ptr->end_length;
								match_data.closure_ptr  = in_ptr +
									(comment_ptr->end_length - 1);
								in_ptr                 += comment_ptr->end_length;
								in_length              -= comment_ptr->end_length;
								break;
							}
							else {
								in_ptr++;
								in_length--;
							}
						}
						if (match_data.closure_ptr == NULL) {
							match_data.length      = ((unsigned int)
								(in_ptr - match_data.ptr));
							match_data.closure_ptr = in_ptr;
						}
					}
					else if ((tmp_ptr = KML_GetEndOfLine(in_ptr +
						comment_ptr->start_length)) != NULL) {
						match_data.length       = ((unsigned int)
							(tmp_ptr - in_ptr)) +
							(((*tmp_ptr == '\r') && (*(tmp_ptr + 1) == '\n')) ?
							2 : 1);
						in_ptr                  = tmp_ptr +
							(((*tmp_ptr == '\r') && (*(tmp_ptr + 1) == '\n')) ?
							2 : 1);
						match_data.closure_ptr  = in_ptr - 1;
						in_length              -= match_data.length;
					}
					else {
						match_data.length      = in_length;
						in_ptr                 = in_string + in_length;
						match_data.closure_ptr = in_ptr;
						in_length              = 0;  
					}
					while ((match_index < match_count) &&
						(in_ptr > domain_ptr->match_list[match_index].ptr))
						match_index++;
					if ((return_code = KML_AddMatch(domain_ptr, &match_data,
						error_text)) != KMLFUNCS_SUCCESS)
						goto EXIT_FUNCTION;
					break;
				}
			}
			if (found_flag != KMLFUNCS_TRUE) {
				in_ptr++;
				in_length--;
			}
		}
		else {
			in_ptr++;
			in_length--;
		}
	}

	KML_SORT_MatchList(domain_ptr->match_count, domain_ptr->match_list);

EXIT_FUNCTION:

	return(return_code);
}
/*	***********************************************************************	*/

#ifdef TEST_MAIN

#ifndef NARGS
int main(int argc, char **argv);
#else
int main();
#endif /* #ifndef NARGS */

int main(argc, argv)
int    argc;
char **argv;
{
	int           return_code;
	unsigned int  count_1;
	unsigned int  count_2;
	KML_DOMAIN    domain_data;
	char         *file_buffer;
	char          error_text[KMLFUNCS_MAX_ERROR_TEXT];

	fprintf(stderr, "Test routine for 'KML_MatchComments()'\n");
	fprintf(stderr, "---- ------- --- ---------------------\n\n");

	if (argc == 1) {
		sprintf(error_text, "USAGE:\n   %s <source-file> [<source-file> ...]",
			argv[0]);
		return_code = KMLFUNCS_BAD_ARGS_FAILURE;
	}
	else if ((return_code = KML_TEST_InitializeDomain("c", &domain_data,
		error_text)) == KMLFUNCS_SUCCESS) {
		for (count_1 = 1; count_1 < argc; count_1++) {
			STR_EMIT_CharLine('=', 78, NULL, NULL);
			printf("File: %s\n", argv[count_1]);
			STR_EMIT_CharLine('-', 78, NULL, NULL);
			if ((return_code = KML_TFREAD_ReadFileBuffer(argv[count_1], NULL,
				&file_buffer, error_text)) != KMLFUNCS_SUCCESS)
				break;
			if ((return_code = KML_MatchComments(&domain_data, file_buffer,
				error_text)) != KMLFUNCS_SUCCESS)
				break;
			for (count_2 = 0; count_2 < domain_data.match_count; count_2++) {
				printf("%-*.*s\n", domain_data.match_list[count_2].length,
					domain_data.match_list[count_2].length,
					domain_data.match_list[count_2].ptr);
				STR_EMIT_CharLine('-', 78, NULL, NULL);
			}
			fprintf(stderr, "File: %s --- %u matches.\n", argv[count_1],
				domain_data.match_count);
			free(file_buffer);
			KML_FREE_MatchList(&domain_data.match_count,
				&domain_data.match_list);
		}              
		STR_EMIT_CharLine('=', 78, NULL, NULL);
		KML_FREE_Domain(&domain_data);
	}

	if (return_code != KMLFUNCS_SUCCESS)
		fprintf(stderr, "\n\nERROR: %s\n", error_text);

	return(return_code);
}

#endif /* #ifdef TEST_MAIN */


