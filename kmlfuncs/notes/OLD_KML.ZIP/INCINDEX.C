/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	Keyword Matching Logic (KMLFUNCS) Program Module								*/
/*	***********************************************************************	*/
/*
	File Name			:	%M%

	File Version		:	%I%

	Last Extracted		:	%D%	%T%

	Last Updated		:	%E%	%U%

	File Description	:	Initializes 'KML_CHAR_INDEX' structures.

	Revision History	:	1998-03-19 --- Creation.
									Michael L. Brock
*/
/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*		Necessary include files . . .														*/
/*	***********************************************************************	*/

#include <memory.h>

#include "kmlfuncs.h"

/*	***********************************************************************	*/

/* *********************************************************************** */
/* *********************************************************************** */
/* BOH

	NAME			:	KML_INIT_CharIndex

	SYNOPSIS		:	void KML_INIT_CharIndex(ptr);

						KML_CHAR_INDEX *ptr;

	DESCRIPTION	:	Initializes the members of a ''KML_CHAR_INDEX''
						structure to their default values.

	PARAMETERS  :	Parameters to this function are as follow:

						(.) ``ptr`` points to the ''KML_CHAR_INDEX''
						structure to be initialized by this function.

	RETURNS		:	Void.

	NOTES			:	

	CAVEATS		:	

	SEE ALSO		:	KML_INIT_CharIndexList

	EXAMPLES		:	

	AUTHOR		:	Michael L. Brock

	COPYRIGHT   :	Copyright 1998 Michael L. Brock

	OUTPUT INDEX:	KML_INIT_CharIndex
						Initialization Functions:KML_INIT_CharIndex
						KML_CHAR_INDEX Functions:KML_INIT_CharIndex

	PUBLISH XREF:	KML_INIT_CharIndex

	PUBLISH NAME:	KML_INIT_CharIndex

	ENTRY CLASS	:	Initialization Functions

EOH */
/*	***********************************************************************	*/
/*
	CODE NOTE: To be removed.
*/
void KML_INIT_CharIndex(ptr)
KML_CHAR_INDEX *ptr;
{
	memset(ptr, '\0', sizeof(*ptr));

	ptr->type_ptr.void_ptr = NULL;
	ptr->count             = 0;
}
/*	***********************************************************************	*/

/* *********************************************************************** */
/* *********************************************************************** */
/* BOH

	NAME			:	KML_INIT_CharIndexList

	SYNOPSIS		:	void KML_INIT_CharIndexList(count, list);

						unsigned int    count;

						KML_CHAR_INDEX *list;

	DESCRIPTION	:	Initializes the elements of a array of ''KML_CHAR_INDEX''
						structures to their default values.

	PARAMETERS  :	Parameters to this function are as follow:

						(.) ``count`` is the number of elements in the array
						``list``.

						(.) ``list`` is the array of ''KML_CHAR_INDEX''
						structures to be initialized by this function.

	RETURNS		:	Void.

	NOTES			:	

	CAVEATS		:	

	SEE ALSO		:	KML_INIT_CharIndex

	EXAMPLES		:	

	AUTHOR		:	Michael L. Brock

	COPYRIGHT   :	Copyright 1998 Michael L. Brock

	OUTPUT INDEX:	KML_INIT_CharIndexList
						Initialization Functions:KML_INIT_CharIndexList
						KML_CHAR_INDEX Functions:KML_INIT_CharIndexList

	PUBLISH XREF:	KML_INIT_CharIndexList

	PUBLISH NAME:	KML_INIT_CharIndexList

	ENTRY CLASS	:	Initialization Functions

EOH */
/*	***********************************************************************	*/
/*
	CODE NOTE: To be removed.
*/
void KML_INIT_CharIndexList(count, list)
unsigned int    count;
KML_CHAR_INDEX *list;
{
	while (count--)
		KML_INIT_CharIndex(list++);
}
/*	***********************************************************************	*/

