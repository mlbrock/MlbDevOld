/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	Keyword Matching Logic (KMLFUNCS) Program Module								*/
/*	***********************************************************************	*/
/*
	File Name			:	%M%

	File Version		:	%I%

	Last Extracted		:	%D%	%T%

	Last Updated		:	%E%	%U%

	File Description	:	Compares two 'KML_SYMBOL' structures.

	Revision History	:	1998-03-19 --- Creation.
									Michael L. Brock
*/
/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*		Necessary include files . . .														*/
/*	***********************************************************************	*/

#include <string.h>

#include "kmlfuncs.h"

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	BOH

	NAME        :	KML_SCMP_Symbol

	SYNOPSIS    :	return_code = KML_SCMP_Symbol(case_flag, ptr_1,
							ptr_2, data_length);

						int               return_code;

						void             *case_flag;

						const KML_SYMBOL *ptr_1;

						const KML_SYMBOL *ptr_2;

						size_t            data_length;

	DESCRIPTION :	Compares two ''KML_SYMBOL'' structures to
						determine their equivalence.

						The ``ptr`` member of the ''KML_SYMBOL''
						structure is used as the basis of the comparison.

	PARAMETERS  :	Parameters to this function are as follow:

						(.) ``case_flag`` is an ''int'' cast to a ''void'' pointer
						in accordance with the requirements of the STRFUNCS list
						functions.

						(..) If ``((int) case_flag)`` evaluates to a non-zero
						value, the comparison will be performed in a
						case-sensitive fashion.

						(..) If ``((int) case_flag)`` evaluates to a zero
						value, the comparison will be performed in a
						case-insensitive fashion.

						(.) ``ptr_1`` points to the first ''KML_SYMBOL''
						structure to be compared.

						(.) ``ptr_2`` points to the second ''KML_SYMBOL''
						structure to be compared.

						(.) ``data_length`` is the size the areas to which
						``ptr_1`` and ``ptr_2`` point. Because it is unnecessary
						to the comparison of ''KML_SYMBOL'' structures,
						it may be zero (''0'').

	RETURNS     :	Returns from this function are as follow:

						(.) negative if the first ''KML_SYMBOL'' structure
						is less than second.

						(.) positive if the first ''KML_SYMBOL'' structure
						is greater than second.

						(.) zero if the structures are equivalent.

	NOTES       :  The ``data_length`` parameter is present only because this
						function is used internally by the STRFUNCS list functions.
						This parameter provides function-call compatibility with
						other, more generic, functions such as
						``KML_SORT_SymbolList``.

	CAVEATS     :	

	SEE ALSO    :	

	EXAMPLES    :	

	AUTHOR      :	Michael L. Brock

	COPYRIGHT   :	Copyright 1998 Michael L. Brock

	OUTPUT INDEX:	KML_SCMP_Symbol
						Comparison Functions:KML_SCMP_Symbol
						KML_SYMBOL Functions:KML_SCMP_Symbol

	PUBLISH XREF:	KML_SCMP_Symbol

	PUBLISH NAME:	KML_SCMP_Symbol

	ENTRY CLASS	:	Comparison Functions

EOH */
/*	***********************************************************************	*/
int KML_SCMP_Symbol(case_flag, ptr_1, ptr_2, data_length)
void             *case_flag;
const KML_SYMBOL *ptr_1;
const KML_SYMBOL *ptr_2;
size_t            data_length;
{
	return((((int) case_flag)) ?
		strcmp(ptr_1->ptr, ptr_2->ptr) :
		stricmp(ptr_1->ptr, ptr_2->ptr));
}
/*	***********************************************************************	*/

