/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	Keyword Matching Logic (KMLFUNCS) Program Module								*/
/*	***********************************************************************	*/
/*
	File Name			:	%M%

	File Version		:	%I%

	Last Extracted		:	%D%	%T%

	Last Updated		:	%E%	%U%

	File Description	:	Matches keywords.

	Revision History	:	1998-03-19 --- Creation.
									Michael L. Brock
*/
/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*		Necessary include files . . .														*/
/*	***********************************************************************	*/

#include <memory.h>
#include <stdlib.h>
#include <string.h>

#include <genfuncs.h>

#include "kmlfuncs.h"

/*	***********************************************************************	*/

/*	***********************************************************************	*/
int KML_MatchKeywords(domain_ptr, in_string, error_text)
KML_DOMAIN *domain_ptr;
const char *in_string;
char       *error_text;
{
	int             return_code = KMLFUNCS_SUCCESS;
	unsigned int    found_flag;
	unsigned int    count_1;
	const char     *in_ptr;
	unsigned int    in_length;
	const char     *tmp_ptr;
	KML_KEYWORD    *keyword_ptr;
	KML_MATCH       match_data;
	KML_CHAR_INDEX *char_index_ptr;
	KML_CHAR_INDEX  char_index_list[UCHAR_MAX + 1];
	unsigned char   name_flag_list[UCHAR_MAX + 1];
#ifndef NARGS
	int             (*cmp_func)(const char *, const char *, size_t);
#else
	int             (*cmp_func)();
#endif /* #ifndef NARGS */

	KML_BuildCharIndex(domain_ptr->keyword_count, domain_ptr->keyword_list,
		sizeof(KML_KEYWORD), offsetof(KML_KEYWORD, keyword),
		domain_ptr->keyword_case_flag, char_index_list);

	memset(name_flag_list, '\0', sizeof(name_flag_list));
	if (domain_ptr->name_count && (domain_ptr->name_list != NULL)) {
		tmp_ptr = domain_ptr->name_list->first_char;
		while (*tmp_ptr)
			name_flag_list[((unsigned int) *((unsigned char *) tmp_ptr++))] = 1;
		tmp_ptr = domain_ptr->name_list->other_chars;
		while (*tmp_ptr)
			name_flag_list[((unsigned int) *((unsigned char *) tmp_ptr++))] = 1;
	}

	in_ptr    = in_string;
	in_length = strlen(in_string);
	cmp_func  = (domain_ptr->keyword_case_flag) ? strncmp : strnicmp;

	while (*in_ptr) {
		if ((char_index_ptr = (char_index_list +
			((unsigned int) *((unsigned char *) in_ptr))))->count) {
			found_flag  = KMLFUNCS_FALSE;
			/*
					We could do this (and the corresponding decrement) within
				the 'for' loop, but CodeGuard complains under NT.
			*/
			keyword_ptr = char_index_ptr->type_ptr.keyword_ptr + 1;
			for (count_1 = 0; count_1 < char_index_ptr->count; count_1++) {
				keyword_ptr--;
				if ((keyword_ptr->length <= in_length) &&
					(!(*cmp_func)(keyword_ptr->keyword, in_ptr,
					keyword_ptr->length)) &&
					((in_ptr == in_string) || isspace(*(in_ptr - 1)) ||
					iscntrl(*(in_ptr - 1)) || (!name_flag_list
					[((unsigned int) *((unsigned char *) (in_ptr - 1)))])) &&
					((!(*(tmp_ptr = (in_ptr + keyword_ptr->length)))) ||
					isspace(*tmp_ptr) || iscntrl(*tmp_ptr) || (!name_flag_list
					[((unsigned int) *((unsigned char *) tmp_ptr))]))) {
					found_flag = KMLFUNCS_TRUE;
					KML_INIT_Match(&match_data);
					match_data.type                  = KML_TYPE_KEYWORD;
					match_data.type_value            = 0L;
					match_data.type_ptr.keyword_ptr  = keyword_ptr;
					match_data.length                = keyword_ptr->length;
					match_data.ptr                   = in_ptr;
					match_data.closure_ptr           = in_ptr +
						(keyword_ptr->length - 1);
					in_ptr                          += keyword_ptr->length;
					in_length                       -= keyword_ptr->length;
					if ((return_code = KML_AddMatch(domain_ptr, &match_data,
						error_text)) != KMLFUNCS_SUCCESS)
						goto EXIT_FUNCTION;
					break;
				}
			}
			if (found_flag != KMLFUNCS_TRUE) {
				in_ptr++;
				in_length--;
			}
		}
		else {
			in_ptr++;
			in_length--;
		}
	}

	KML_SORT_MatchList(domain_ptr->match_count, domain_ptr->match_list);

EXIT_FUNCTION:

	return(return_code);
}
/*	***********************************************************************	*/

/*	***********************************************************************	*/
void KML_ConcatenateKeywords(domain_ptr)
KML_DOMAIN *domain_ptr;
{
	unsigned int  count_1;
	unsigned int  count_2;
	const char   *tmp_ptr;

	for (count_1 = 0; count_1 < domain_ptr->match_count; ) {
		if ((domain_ptr->match_list[count_1].type == KML_TYPE_KEYWORD) &&
			((count_1 + 1) < domain_ptr->match_count) &&
			(domain_ptr->match_list[count_1 + 1].type == KML_TYPE_KEYWORD)) {
			tmp_ptr = domain_ptr->match_list[count_1].ptr +
				domain_ptr->match_list[count_1].length;
			while ((tmp_ptr < domain_ptr->match_list[count_1 + 1].ptr) &&
				(isspace(*tmp_ptr) || iscntrl(*tmp_ptr)))
				tmp_ptr++;
			if (tmp_ptr == domain_ptr->match_list[count_1 + 1].ptr) {
				domain_ptr->match_list[count_1].length = ((unsigned int)
					(domain_ptr->match_list[count_1 + 1].ptr -
					domain_ptr->match_list[count_1].ptr)) +
					domain_ptr->match_list[count_1 + 1].length;
				for (count_2 = (count_1 + 1);
					count_2 < (domain_ptr->match_count - 1); count_2++)
					domain_ptr->match_list[count_2] =
						domain_ptr->match_list[count_2 + 1];
				domain_ptr->match_count--;
			}
			else
				count_1++;
		}
		else
			count_1++;
	}
}
/*	***********************************************************************	*/

#ifdef TEST_MAIN

#ifndef NARGS
int main(int argc, char **argv);
#else
int main();
#endif /* #ifndef NARGS */

int main(argc, argv)
int    argc;
char **argv;
{
	int           return_code;
	unsigned int  count_1;
	unsigned int  count_2;
	KML_DOMAIN    domain_data;
	char         *file_buffer;
	char          error_text[KMLFUNCS_MAX_ERROR_TEXT];

	fprintf(stderr, "Test routine for 'KML_MatchKeywords()'\n");
	fprintf(stderr, "---- ------- --- ---------------------\n\n");

	if (argc == 1) {
		sprintf(error_text, "USAGE:\n   %s <source-file> [<source-file> ...]",
			argv[0]);
		return_code = KMLFUNCS_BAD_ARGS_FAILURE;
	}
	else if ((return_code = KML_TEST_InitializeDomain("c", &domain_data,
		error_text)) == KMLFUNCS_SUCCESS) {
		for (count_1 = 1; count_1 < argc; count_1++) {
			STR_EMIT_CharLine('=', 78, NULL, NULL);
			printf("File: %s\n", argv[count_1]);
			STR_EMIT_CharLine('-', 78, NULL, NULL);
			if ((return_code = KML_TFREAD_ReadFileBuffer(argv[count_1], NULL,
				&file_buffer, error_text)) != KMLFUNCS_SUCCESS)
				break;
			if ((return_code = KML_MatchKeywords(&domain_data, file_buffer,
				error_text)) != KMLFUNCS_SUCCESS)
				break;
			KML_ConcatenateKeywords(&domain_data);
			for (count_2 = 0; count_2 < domain_data.match_count; count_2++) {
				printf("%-*.*s\n", domain_data.match_list[count_2].length,
					domain_data.match_list[count_2].length,
					domain_data.match_list[count_2].ptr);
				STR_EMIT_CharLine('-', 78, NULL, NULL);
			}
			fprintf(stderr, "File: %s --- %u matches.\n", argv[count_1],
				domain_data.match_count);
			free(file_buffer);
			KML_FREE_MatchList(&domain_data.match_count,
				&domain_data.match_list);
		}              
		STR_EMIT_CharLine('=', 78, NULL, NULL);
		KML_FREE_Domain(&domain_data);
	}

	if (return_code != KMLFUNCS_SUCCESS)
		fprintf(stderr, "\n\nERROR: %s\n", error_text);

	return(return_code);
}

#endif /* #ifdef TEST_MAIN */


