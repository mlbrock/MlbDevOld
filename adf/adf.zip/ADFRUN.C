/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	Automated Documentation Facility (ADF) Program Module							*/
/*	***********************************************************************	*/
/*
	File Name			:	%M%

	File Version		:	%I%

	Last Extracted		:	%D%	%T%

	Last Updated		:	%E%	%U%

	File Description	:	

	Revision History	:	1995-07-27 --- Creation.
									Michael L. Brock
*/
/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*		Necessary include files . . .														*/
/*	***********************************************************************	*/

#include <stdlib.h>
#include <string.h>

#include <genfuncs.h>

#include "adf.h"

/*	***********************************************************************	*/

/*	***********************************************************************	*/
int ADF_RUN_AllocFileString(control_ptr, alloc_length, error_text)
ADF_CONTROL  *control_ptr; 
unsigned int  alloc_length;
char         *error_text;
{
	return(ADF_RUN_AllocString(alloc_length, "the complete file name string",
		&control_ptr->output_file_name_length,
		&control_ptr->output_file_name, error_text));
}
/*	***********************************************************************	*/

/*	***********************************************************************	*/
int ADF_RUN_AllocHTextString(control_ptr, link_length, error_text)
ADF_CONTROL  *control_ptr;
unsigned int  link_length;
char         *error_text;
{
	return(ADF_RUN_AllocString(link_length, "a hyper text link string",
		&control_ptr->htext_link_name_length, &control_ptr->htext_link_name,
		error_text));
}
/*	***********************************************************************	*/

/*	***********************************************************************	*/
int ADF_RUN_AllocString(alloc_length, alloc_text, string_length, string_ptr,
	error_text)
unsigned int   alloc_length;
const char    *alloc_text;
unsigned int  *string_length;
char         **string_ptr;
char          *error_text;
{
	int           return_code = ADF_SUCCESS;
	char         *tmp_ptr;

	if (alloc_length > *string_length) {
		tmp_ptr = (*string_ptr == NULL) ? calloc(alloc_length, sizeof(char)) :
			realloc(*string_ptr, alloc_length * sizeof(char));
		if (tmp_ptr != NULL) {
			*string_length = alloc_length;
			*string_ptr    = tmp_ptr;
		}
		else {
			sprintf(error_text, "%s %s failed (%u bytes required).",
				"Attempt to allocate", alloc_text, alloc_length);
			return_code = ADF_MEMORY_FAILURE;
		}
	}

	return(return_code);
}
/*	***********************************************************************	*/

/*	***********************************************************************	*/
char *ADF_RUN_CleanName(in_name)
char *in_name;
{
	char *tmp_ptr = in_name;

	while (*tmp_ptr) {
		*tmp_ptr = (isgraph(*tmp_ptr)) ? *tmp_ptr : '_';
		tmp_ptr++;
	}

	return(in_name);
}
/*	***********************************************************************	*/

/*	***********************************************************************	*/
int ADF_RUN_OpenOutputFile(control_ptr, error_text)
ADF_CONTROL *control_ptr;
char        *error_text;
{
	int return_code = ADF_SUCCESS;

	ADF_RUN_CleanName(control_ptr->output_file_name);

	if ((control_ptr->output_file_ptr = fopen(control_ptr->output_file_name,
		"w")) == NULL) {
		sprintf(error_text,
			"Unable to open output file '%-.500s' for writing: ",
			control_ptr->output_file_name);
		ADF_GetLastErrorString(error_text);
		return_code = ADF_SYSTEM_FAILURE;
	}

	return(return_code);
}
/*	***********************************************************************	*/

/*	***********************************************************************	*/
int ADF_RUN_OpenLogFile(control_ptr, error_text)
ADF_CONTROL *control_ptr;
char        *error_text;
{
	int  return_code = ADF_SUCCESS;
	char buffer[4096];

#ifdef __MSDOS__
	sprintf(buffer, "%s%sADF_LOG.LOG", (control_ptr->log_dir == NULL) ? "" :
		control_ptr->log_dir, (control_ptr->log_dir == NULL) ? "" : "\\",
		control_ptr->log_dir);
#else
	char time_buffer[100];
	GEN_Format_time_t(&control_ptr->start_time.tv_sec, time_buffer);
	time_buffer[10] = '.';
# ifdef _Windows
	time_buffer[13] = '.';
   time_buffer[16] = '.';
# endif /* # ifdef _Windows */
	if ((control_ptr->log_dir == NULL) &&
		((control_ptr->log_dir = strdup(".")) == NULL)) {
		strcpy(error_text,
			"Unable to copy the default log file directory '.'.");
		return_code = ADF_MEMORY_FAILURE;
	}
	else
		sprintf(buffer, "%s/%s.ADF_LOG.%s.%u", control_ptr->log_dir,
			time_buffer, control_ptr->host_name, control_ptr->process_id);
#endif /* #ifdef __MSDOS__ */

	if (return_code == ADF_SUCCESS) {
		if ((control_ptr->log_file_name = strdup(buffer)) == NULL) {
			strcpy(error_text, "Unable to copy the name of the log file.");
			return_code = ADF_MEMORY_FAILURE;
		}
		else if ((control_ptr->log_file_ptr =
			ADF_fopen(control_ptr->log_file_name, "w")) == NULL) {
			sprintf(error_text, "%s '%-.500s' for writing --- ",
				"Unable to open the log file", control_ptr->log_file_name);
			ADF_GetLastErrorString(error_text);
			return_code = ADF_FAILURE;
		}
	}

	return(return_code);
}
/*	***********************************************************************	*/

/*	***********************************************************************	*/
void ADF_RUN_LogOutputFile(control_ptr, entry_ptr, output_file_name)
ADF_CONTROL     *control_ptr;
const ADF_ENTRY *entry_ptr;
const char      *output_file_name;
{
	if (control_ptr->log_flag == ADF_TRUE)
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, NULL,
			ADF_FALSE, "%s '%s' %s '%s' %s '%s' %s '%s'.\n",
			"Wrote the ADF entry named", entry_ptr->base_name,
			"defined in the source file", entry_ptr->full_name,
			"in the ADF database file",
			control_ptr->in_file_list[entry_ptr->file_index].file_name,
			(output_file_name == NULL) ? "to" : "to the output file",
			(output_file_name == NULL) ? "stdout" : output_file_name);
}
/*	***********************************************************************	*/

