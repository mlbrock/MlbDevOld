/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	Automated Documentation Facility (ADF) Program Module							*/
/*	***********************************************************************	*/
/*
	File Name			:	%M%

	File Version		:	%I%

	Last Extracted		:	%D%	%T%

	Last Updated		:	%E%	%U%

	File Description	:	Run-time logic for the executable 'adfdiff'.

	Revision History	:	1996-04-05 --- Creation.
									Michael L. Brock
*/
/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*		Necessary include files . . .														*/
/*	***********************************************************************	*/

#include <locale.h>
#include <memory.h>
#include <stdlib.h>
#include <string.h>

#include <genfuncs.h>

#include "adf.h"

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

#define ADF_RUN_DIFF_VERSION_NUMBER		"01.00.00A"

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

static const ADF_RUN_USAGE ADF_RUN_DIFF_UsageFuncList[] = {
	{	ADF_TRUE,	ADF_BUSE_Help,						NULL	},
	{	ADF_TRUE,	ADF_BUSE_Version,					NULL	},
	{	ADF_TRUE,	ADF_BUSE_CheckOnlyFlag,			NULL	},
	{	ADF_TRUE,	ADF_BUSE_LogFlag,					NULL	},
	{	ADF_TRUE,	ADF_BUSE_LogDir,					NULL	},
	{	ADF_TRUE,	ADF_BUSE_QuietFlag,				NULL	},
	{	ADF_TRUE,	ADF_BUSE_ContOnErrorFlag,		NULL	},
	{	ADF_TRUE,	ADF_BUSE_CludeEntry,				NULL	},
	{	ADF_TRUE,	ADF_BUSE_CludeHText,				NULL	},
	{	ADF_TRUE,	ADF_OUSE_AreaOrderType,			NULL	},
	{	ADF_TRUE,	ADF_BUSE_IgnoreSection,			NULL	}
};

static const unsigned int  ADF_RUN_DIFF_UsageFuncCount  =
	sizeof(ADF_RUN_DIFF_UsageFuncList) / sizeof(ADF_RUN_DIFF_UsageFuncList[0]);

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

#ifdef __MSDOS__
extern unsigned int _stklen = 32000;
#endif /* __MSDOS__ */

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

#ifndef NARGS
int main(int argc, char **argv);
#else
int main();
#endif /* #ifndef NARGS */

#ifndef NARGS
static int  ADF_RUN_DIFF_DoDiff(ADF_CONTROL *control_ptr, char *error_text);
static int  ADF_RUN_DIFF_OpenADFFiles(ADF_CONTROL *control_ptr,
	unsigned int *entry_count_1, ADF_ENTRY **entry_list_1,
	unsigned int *entry_count_2, ADF_ENTRY **entry_list_2, char *error_text);
static int  ADF_RUN_DIFF_GetParams(ADF_CONTROL *control_ptr, unsigned int argc,
	char **argv, char *error_text);
static int  ADF_RUN_DIFF_CreateUsageList(ADF_CONTROL *control_ptr,
	unsigned int *usage_count, char ***usage_list, char *error_text);
static void ADF_RUN_DIFF_ShowSettings(const ADF_CONTROL *control_ptr);
static int  ADF_RUN_DIFF_CheckParams(ADF_CONTROL *control_ptr,
	char *error_text);
static int  ADF_RUN_DIFF_Parse(ADF_CONTROL *control_ptr, unsigned int argc,
	char **argv, int init_flag, unsigned int current_arg, char *error_text);
static void ADF_RUN_DIFF_End(ADF_CONTROL *control_ptr, int signal_number,
	int *exit_code_ptr, const char *message_buffer);
#else
static int  ADF_RUN_DIFF_DoDiff();
static int  ADF_RUN_DIFF_OpenADFFiles();
static int  ADF_RUN_DIFF_GetParams();
static int  ADF_RUN_DIFF_CreateUsageList();
static void ADF_RUN_DIFF_ShowSettings();
static int  ADF_RUN_DIFF_CheckParams();
static int  ADF_RUN_DIFF_Parse();
static void ADF_RUN_DIFF_End();
#endif /* #ifndef NARGS */

/*	***********************************************************************	*/

/*	***********************************************************************	*/
int main(argc, argv)
int    argc;
char **argv;
{
	int         return_code;
	ADF_CONTROL control_data;
	char        error_text[ADF_MAX_ERROR_TEXT];

	memset(&control_data, '\0', sizeof(control_data));

	if ((return_code = ADF_RUN_DIFF_GetParams(&control_data,
		((unsigned int) argc), argv, error_text)) == ADF_SUCCESS) {
		if (control_data.check_only_flag != ADF_TRUE)
			return_code = ADF_RUN_DIFF_DoDiff(&control_data, error_text);
		if ((return_code != ADF_SUCCESS) &&
			(control_data.log_flag == ADF_TRUE))
			ADF_LogMessage(NULL, LOG_ERR, control_data.log_file_ptr, stderr,
				ADF_FALSE, "%s\n", error_text);
		ADF_RUN_DIFF_End(&control_data, 0, NULL, NULL);
		GEN_SIGNAL_SignalDefault();
	}

	if (return_code != ADF_SUCCESS)
		fprintf(stderr, "\n\nERROR: %s\n\n%s", error_text,
			(return_code != ADF_BAD_ARGS_FAILURE) ? "" :
			"       Help is available with the '-HELP' parameter.\n\n");

	return(return_code);
}
/*	***********************************************************************	*/

/*	***********************************************************************	*/
static int ADF_RUN_DIFF_DoDiff(control_ptr, error_text)
ADF_CONTROL *control_ptr;
char        *error_text;
{
	int              return_code   = ADF_SUCCESS;
	unsigned int     entry_count_1 = 0;
	ADF_ENTRY       *entry_list_1  = NULL;
	unsigned int     entry_count_2 = 0;
	ADF_ENTRY       *entry_list_2  = NULL;
	unsigned int     not_found_1   = 0;
	unsigned int     not_found_2   = 0;
	unsigned int     no_match      = 0;
	unsigned int     diff_area_index;
	unsigned int     diff_para_index;
	unsigned int     count_1;
	unsigned int     found_index;
	ADF_ENTRY_DATA   entry_data_list_1[ADF_AREA_COUNT];
	ADF_ENTRY_DATA   entry_data_list_2[ADF_AREA_COUNT];
#ifndef NARGS
	void           (*output_function)(void *, char *, ...);
#else
	void           (*output_function)();
#endif /* #ifndef NARGS */
	void            *output_control;

	output_function = ((void (*)(void *, char *, ...)) fprintf);
	output_control  = stdout;

	control_ptr->keep_bad_see_also_flag = ADF_TRUE;

	ADF_INIT_AreaDataList(entry_data_list_1);
	ADF_INIT_AreaDataList(entry_data_list_2);

	if ((return_code = ADF_RUN_DIFF_OpenADFFiles(control_ptr, &entry_count_1,
		&entry_list_1, &entry_count_2, &entry_list_2, error_text)) !=
		ADF_SUCCESS)
		goto EXIT_FUNCTION;

	for (count_1 = 0; count_1 < entry_count_1; ) {
		if (ADF_FIND_FindEntryByBaseName(entry_count_2, entry_list_2,
			entry_list_1[count_1].base_name, &found_index) !=
			STRFUNCS_ITEM_FOUND) {
			if (!not_found_1++) {
				printf("Entries in '%s', but not in '%s':\n",
					control_ptr->in_file_name_list[0],
					control_ptr->in_file_name_list[1]);
				printf("------- -- ");
				STR_EMIT_Char('-', strlen(control_ptr->in_file_name_list[0]) + 2,
					output_function, output_control);
				printf("  --- --- -- ");
				STR_EMIT_CharLine('-',
					strlen(control_ptr->in_file_name_list[1]) + 3, output_function,
					output_control);
			}
			printf("Base name '%s' in source file '%s'\n",
				entry_list_1[count_1].base_name, entry_list_1[count_1].file_name);
			mema_remove(&entry_count_1, ((void **) &entry_list_1),
				sizeof(*entry_list_1), count_1, 1);
		}
		else
			count_1++;
	}

	for (count_1 = 0; count_1 < entry_count_2; ) {
		if (ADF_FIND_FindEntryByBaseName(entry_count_1, entry_list_1,
			entry_list_2[count_1].base_name, &found_index) !=
			STRFUNCS_ITEM_FOUND) {
			if (!not_found_2++) {
				if (not_found_1)
					STR_EMIT_CharLine('=', 78, output_function, output_control);
				printf("Entries in '%s', but not in '%s':\n",
					control_ptr->in_file_name_list[1],
					control_ptr->in_file_name_list[0]);
				printf("------- -- ");
				STR_EMIT_Char('-',
					strlen(control_ptr->in_file_name_list[1]) + 2, output_function,
					output_control);
				printf("  --- --- -- ");
				STR_EMIT_CharLine('-',
					strlen(control_ptr->in_file_name_list[0]) + 3, output_function,
					output_control);
			}
			printf("Base name '%s' in source file '%s'\n",
				entry_list_2[count_1].base_name, entry_list_2[count_1].file_name);
			mema_remove(&entry_count_2, ((void **) &entry_list_2),
				sizeof(*entry_list_2), count_1, 1);
		}
		else
			count_1++;
	}

	for (count_1 = 0; count_1 < entry_count_1; count_1++) {
		ADF_FREE_AreaDataList(entry_data_list_1);
		ADF_INIT_AreaDataList(entry_data_list_2);
		if ((return_code = ADF_GetEntry(control_ptr, entry_list_1 + count_1,
			entry_data_list_2, error_text)) != ADF_SUCCESS)
			break;
		if ((return_code = ADF_COPY_EntryDataList(entry_data_list_2,
			entry_data_list_1, error_text)) != ADF_SUCCESS)
			break;
		ADF_INIT_AreaDataList(entry_data_list_2);
		ADF_FIND_FindEntryByBaseName(entry_count_2, entry_list_2,
			entry_list_1[count_1].base_name, &found_index);
		if ((return_code = ADF_GetEntry(control_ptr, entry_list_2 + found_index,
			entry_data_list_2, error_text)) != ADF_SUCCESS)
			break;
		if (control_ptr->area_order_type != ADF_AREA_ORDER_TYPE_INTERNAL) {
			ADF_SORT_EntrySections(control_ptr->area_order_type,
				entry_data_list_1);
			ADF_SORT_EntrySections(control_ptr->area_order_type,
				entry_data_list_2);
		}
		if (ADF_CMP_EntryDataList(entry_data_list_1, entry_data_list_2,
			&diff_area_index, &diff_para_index) != 0) {
			if (!no_match++) {
				if (not_found_1 || not_found_2)
					STR_EMIT_CharLine('=', 78, output_function, output_control);
				printf("Entries in '%s', different in '%s':\n",
					control_ptr->in_file_name_list[0],
					control_ptr->in_file_name_list[1]);
				printf("------- -- ");
				STR_EMIT_Char('-', strlen(control_ptr->in_file_name_list[0]) + 2,
					output_function, output_control);
				printf("  --------- -- ");
				STR_EMIT_CharLine('-',
					strlen(control_ptr->in_file_name_list[1]) + 3, output_function,
					output_control);
			}
			printf("Base name '%s', from file '%s'/'%s'.\n",
				entry_list_1[count_1].base_name,
				entry_list_1[count_1].file_name, entry_list_2[count_1].file_name);
		}
	}

	if (not_found_1 || not_found_2 || no_match)
		STR_EMIT_CharLine('=', 78, output_function, output_control);

EXIT_FUNCTION:

	mema_remove_all(&entry_count_1, ((void **) &entry_list_1));
	mema_remove_all(&entry_count_2, ((void **) &entry_list_2));

	ADF_FREE_AreaDataList(entry_data_list_1);
	ADF_INIT_AreaDataList(entry_data_list_2);

	return(return_code);
}
/*	***********************************************************************	*/

/*	***********************************************************************	*/
static int ADF_RUN_DIFF_OpenADFFiles(control_ptr, entry_count_1, entry_list_1,
	entry_count_2, entry_list_2, error_text)
ADF_CONTROL   *control_ptr;
unsigned int  *entry_count_1;
ADF_ENTRY    **entry_list_1;
unsigned int  *entry_count_2;
ADF_ENTRY    **entry_list_2;
char          *error_text;
{
	int          return_code = ADF_SUCCESS;
	unsigned int count_1;

	*entry_count_1 = 0;
	*entry_list_1  = NULL;
	*entry_count_2 = 0;
	*entry_list_2  = NULL;

	for (count_1 = 0; count_1 < 2; count_1++) {
		if ((return_code = ADF_OpenADFFileIn(control_ptr,
			control_ptr->in_file_name_list[count_1], error_text)) !=
			ADF_SUCCESS) {
			if (count_1)
				mema_remove_all(entry_count_1, ((void **) entry_list_1));
			break;
		}
		ADF_SORT_EntryList(ADF_SORT_ENTRY_BASE_NAME,
			control_ptr->in_entry_count, control_ptr->in_entry_list);
		if (!count_1) {
			*entry_count_1 = control_ptr->in_entry_count;
			*entry_list_1  = control_ptr->in_entry_list;
		}
		else {
			*entry_count_2 = control_ptr->in_entry_count;
			*entry_list_2  = control_ptr->in_entry_list;
		}
		control_ptr->in_entry_count = 0;
		control_ptr->in_entry_list  = NULL;
		mema_remove_all(&control_ptr->in_htext_count,
			((void **) &control_ptr->in_htext_list));
	}

	return(return_code);
}
/*	***********************************************************************	*/

/*	***********************************************************************	*/
static int ADF_RUN_DIFF_GetParams(control_ptr, argc, argv, error_text)
ADF_CONTROL   *control_ptr;
unsigned int   argc;
char         **argv;
char          *error_text;
{
	int            return_code;
	unsigned int   usage_count = 0;
	char         **usage_list  = NULL;
	char          *prog;

	ADF_INIT_Control(control_ptr);

#ifndef NARGS
	GEN_SIGNAL_SignalInit(&control_ptr->signal_received_flag,
		&control_ptr->queue_signal_flag, control_ptr,
		&control_ptr->log_file_ptr,
		((int (*)(const void *, size_t, size_t, void *)) ADF_fwrite),
		((void (*)(void *, int, int *, const char *)) ADF_RUN_DIFF_End));
#else
	GEN_SIGNAL_SignalInit(&control_ptr->signal_received_flag,
		&control_ptr->queue_signal_flag, control_ptr,
		&control_ptr->log_file_ptr, ADF_fwrite, ADF_RUN_DIFF_End);
#endif /* #ifndef NARGS */
	GEN_SIGNAL_SignalSet();

	gettimeofday(&control_ptr->start_time, ((struct timezone *) NULL));

	control_ptr->overhead_end_time = control_ptr->start_time;

	control_ptr->process_id        = getpid();

	if (setlocale(LC_ALL, "C") == NULL) {
		strcpy(error_text, "Attempt to 'setlocale(LC_ALL, \"C\")' failed.");
		return_code = ADF_FAILURE;
		goto EXIT_FUNCTION;
	}

/*
	if ((return_code = SPS_GEN_SetResourceLimitsToMax(error_text)) !=
		ADF_SUCCESS)
		goto EXIT_FUNCTION;
*/

	if ((control_ptr->program_name = strdup(argv[0])) == NULL) {
		sprintf(error_text,
			"Unable to allocate memory for the program name.");
		return_code = ADF_MEMORY_FAILURE;
		goto EXIT_FUNCTION;
	}

	if (gethostname(control_ptr->host_name,
		sizeof(control_ptr->host_name) - 1)) {
		strcpy(error_text, "Unable to determine the current host-name: ");
		ADF_GetLastErrorString(error_text);
		return_code = ADF_SYSTEM_FAILURE;
		goto EXIT_FUNCTION;
	}

	if (getwd(control_ptr->current_dir) == NULL) {
		strcpy(error_text, "Unable to determine the current directory: ");
		ADF_GetLastErrorString(error_text);
		return_code = ADF_SYSTEM_FAILURE;
		goto EXIT_FUNCTION;
	}

	prog = control_ptr->program_name;
	/* For Unix */
	prog = (strrchr(prog, '/')  != NULL) ? (strrchr(prog, '/')  + 1) : prog;
	/* For VMS */
	prog = (strrchr(prog, ']')  != NULL) ? (strrchr(prog, ']')  + 1) : prog;
	/* For MS-DOS */
	prog = (strrchr(prog, ':')  != NULL) ? (strrchr(prog, ':')  + 1) : prog;
	/* For MS-DOS */
	prog = (strrchr(prog, '\\') != NULL) ? (strrchr(prog, '\\') + 1) : prog;

	if ((control_ptr->short_program_name = strdup(prog)) == NULL) {
		sprintf(error_text, "%s (%u bytes required).",
			"Unable to allocate memory for the short program name",
			strlen(argv[0]) + 1);
		return_code = ADF_MEMORY_FAILURE;
		goto EXIT_FUNCTION;
	}

	if ((return_code = ADF_RUN_DIFF_CreateUsageList(control_ptr,
		&usage_count, &usage_list, error_text)) != ADF_SUCCESS)
		goto EXIT_FUNCTION;

#ifndef NARGS
	if ((return_code = ADF_GetParams(control_ptr,
		((unsigned int) argc), argv, &control_ptr->help_flag,
		&control_ptr->version_flag,
		((int (*)(void *, unsigned int, char **, int, unsigned int, char *))
		ADF_RUN_DIFF_Parse), error_text)) == ADF_SUCCESS) {
#else
	else if ((return_code = ADF_GetParams(control_ptr,
		((unsigned int) argc), argv, &control_ptr->help_flag,
		&control_ptr->version_flag, ADF_RUN_DIFF_Parse, error_text)) ==
		ADF_SUCCESS) {
#endif /* #ifndef NARGS */
		if (control_ptr->help_flag == ADF_TRUE) {
			ADF_FREE_Control(control_ptr);
			GEN_SIGNAL_SignalDefault();
			ADF_DoFormatUsage(return_code, argv[0],
				"Help request with '-HELP' noted . . .", usage_list);
		}
		else if (control_ptr->version_flag == ADF_TRUE) {
			ADF_FREE_Control(control_ptr);
			GEN_SIGNAL_SignalDefault();
			fprintf(stderr, "%s Version Number %s\n", argv[0],
				ADF_RUN_DIFF_VERSION_NUMBER);
			exit(0);
		}
		else if ((return_code = ADF_RUN_DIFF_CheckParams(control_ptr,
			error_text)) == ADF_SUCCESS) {
			if (control_ptr->log_flag == ADF_TRUE) {
				if (control_ptr->quiet_flag == ADF_TRUE)
					ADF_SetLogMessageFlagFILE(ADF_FALSE);
				if ((return_code = ADF_RUN_OpenLogFile(control_ptr,
					error_text)) == ADF_SUCCESS)
					ADF_RUN_DIFF_ShowSettings(control_ptr);
			}
		}
		if (return_code != ADF_SUCCESS)
			ADF_RUN_DIFF_End(control_ptr, 0, NULL, NULL);
	}

EXIT_FUNCTION:

	gettimeofday(&control_ptr->overhead_end_time,
		((struct timezone *) NULL));

	strl_remove_all(&usage_count, &usage_list);

	if (return_code != ADF_SUCCESS)
		ADF_FREE_Control(control_ptr);

	return(return_code);
}
/*	***********************************************************************	*/

/*	***********************************************************************	*/
static int ADF_RUN_DIFF_CreateUsageList(control_ptr, usage_count, usage_list,
	error_text)
ADF_CONTROL    *control_ptr;
unsigned int   *usage_count;
char         ***usage_list;
char           *error_text;
{
	int          return_code = ADF_MEMORY_FAILURE;
	unsigned int count_1;
	char         buffer[4096];

	*usage_count = 0;
	*usage_list  = NULL;

	*error_text  = '\0';

	sprintf(buffer, "\t%s [<a mixture of '-' parameters, and '@' commands>]",
		control_ptr->short_program_name);
	if (strl_append(usage_count, usage_list, "Usage:") != STRFUNCS_SUCCESS)
		goto EXIT_FUNCTION;
	else if (strl_append(usage_count, usage_list, "------") !=
		STRFUNCS_SUCCESS)
		goto EXIT_FUNCTION;
	else if (strl_append(usage_count, usage_list, buffer) != STRFUNCS_SUCCESS)
		goto EXIT_FUNCTION;
	else if (strl_append(usage_count, usage_list, "\n") != STRFUNCS_SUCCESS)
		goto EXIT_FUNCTION;
	else if (strl_append(usage_count, usage_list, "Description:") !=
		STRFUNCS_SUCCESS)
		goto EXIT_FUNCTION;
	else if (strl_append(usage_count, usage_list, "------------") !=
		STRFUNCS_SUCCESS)
		goto EXIT_FUNCTION;

	sprintf(buffer, "\tThis is version %s of %s.", ADF_RUN_DIFF_VERSION_NUMBER,
		control_ptr->short_program_name);
	if (strl_append(usage_count, usage_list, buffer) != STRFUNCS_SUCCESS)
		goto EXIT_FUNCTION;
	else if (strl_append(usage_count, usage_list, "\n") != STRFUNCS_SUCCESS)
		goto EXIT_FUNCTION;

	if (strl_append(usage_count, usage_list, "Parameters:") !=
		STRFUNCS_SUCCESS)
		goto EXIT_FUNCTION;
	else if (strl_append(usage_count, usage_list, "-----------") !=
		STRFUNCS_SUCCESS)
		goto EXIT_FUNCTION;

	for (count_1 = 0; count_1 < ADF_RUN_DIFF_UsageFuncCount; count_1++) {
		if (((return_code =
			(*ADF_RUN_DIFF_UsageFuncList[count_1].usage_function)(NULL,
			ADF_RUN_DIFF_UsageFuncList[count_1].optional_flag, NULL, usage_count,
			usage_list, error_text)) != ADF_SUCCESS) ||
			((ADF_RUN_DIFF_UsageFuncList[count_1].added_text != NULL) &&
			((return_code = ADF_BUSE_AppendLine(
			ADF_RUN_DIFF_UsageFuncList[count_1].added_text, usage_count,
			usage_list, error_text)) != ADF_SUCCESS)))
			goto EXIT_FUNCTION;
	}

	if ((return_code = ADF_BUSE_AppendParamText(usage_count, usage_list,
		error_text)) != ADF_SUCCESS)
		goto EXIT_FUNCTION;

	return_code = ADF_BUSE_AppendNULL(usage_count, usage_list, error_text);

EXIT_FUNCTION:

	if (return_code != ADF_SUCCESS) {
		strl_remove_all(usage_count, usage_list);
		if (!(*error_text))
			strcpy(error_text, "Unable to allocate memory for the usage text.");
	}

	return(return_code);
}
/*	***********************************************************************	*/

/*	***********************************************************************	*/
static void ADF_RUN_DIFF_ShowSettings(control_ptr)
const ADF_CONTROL *control_ptr;
{
	unsigned int count_1;
	char         buffer[100];

	ADF_LogSeparatorStartLog(control_ptr->log_file_ptr, stderr);

	ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
		ADF_FALSE, "Program Name       : %s\n", control_ptr->program_name);
	ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
		ADF_FALSE, "Version Number     : %s\n", ADF_RUN_DIFF_VERSION_NUMBER);
	ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
		ADF_FALSE, "Host Name          : %s\n", control_ptr->host_name);
	ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
		ADF_FALSE, "Process ID         : %u\n", control_ptr->process_id);
	ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
		ADF_FALSE, "Current Directory  : %s\n", control_ptr->current_dir);
	ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
		ADF_FALSE, "Log File Name      : %s\n", control_ptr->log_file_name);

	ADF_LogSeparatorEqualChar(control_ptr->log_file_ptr, stderr);
}
/*	***********************************************************************	*/

/*	***********************************************************************	*/
static int ADF_RUN_DIFF_CheckParams(control_ptr, error_text)
ADF_CONTROL *control_ptr;
char        *error_text;
{
	int return_code = ADF_BAD_ARGS_FAILURE;

	if (!control_ptr->in_file_name_count)
		strcpy(error_text,
			"No ADF database files were specified on the command line.");
	else if (control_ptr->in_file_name_count == 1)
		strcpy(error_text,
			"Two ADF database files are required to perform the 'diff'.");
	else if (control_ptr->in_file_name_count > 2)
		strcpy(error_text,
			"Only two ADF database files are requireed to perform the 'diff'.");
	else
		return_code = ADF_SUCCESS;
		
	return(return_code);
}
/*	***********************************************************************	*/

/*	***********************************************************************	*/
static int ADF_RUN_DIFF_Parse(control_ptr, argc, argv, init_flag, current_arg,
	error_text)
ADF_CONTROL   *control_ptr;
unsigned int   argc;
char         **argv;
int            init_flag;
unsigned int   current_arg;
char          *error_text;
{
	int           return_code = ADF_SUCCESS;
	char         *this_arg;
	char         *data_ptr;
	unsigned int  arg_length;

	if (init_flag != ADF_TRUE) {
		this_arg = argv[current_arg];
		if (ADF_BARG_CheckOnlyFlag(this_arg, &arg_length, &data_ptr,
			&control_ptr->check_only_flag, &return_code, error_text) == ADF_TRUE)
			;
		else if (ADF_BARG_LogFlag(this_arg, &arg_length, &data_ptr,
			&control_ptr->log_flag, &return_code, error_text) == ADF_TRUE)
			;
		else if (ADF_BARG_LogDir(this_arg, &arg_length, &data_ptr,
			&control_ptr->log_dir, &return_code, error_text) == ADF_TRUE)
			;
		else if (ADF_BARG_QuietFlag(this_arg, &arg_length, &data_ptr,
			&control_ptr->quiet_flag, &return_code, error_text) == ADF_TRUE)
			;
		else if (ADF_BARG_ContOnErrorFlag(this_arg, &arg_length, &data_ptr,
			&control_ptr->cont_on_error_flag, &return_code, error_text) ==
			ADF_TRUE)
			;
		else if (ADF_BARG_CludeEntry(this_arg, &arg_length, &data_ptr,
			control_ptr, &return_code, error_text) == ADF_TRUE)
			;
		else if (ADF_BARG_CludeHText(this_arg, &arg_length, &data_ptr,
			control_ptr, &return_code, error_text) == ADF_TRUE)
			;
		else if (ADF_OARG_AreaOrderType(this_arg, &arg_length, &data_ptr,
			&control_ptr->area_order_type, &return_code, error_text) == ADF_TRUE)
			;
		else if (ADF_BARG_IgnoreSection(this_arg, &arg_length, &data_ptr,
			control_ptr->ignore_section_list, &return_code, error_text) ==
			ADF_TRUE)
			;
		else if (strl_append(&control_ptr->in_file_name_count,
			&control_ptr->in_file_name_list, this_arg) != STRFUNCS_SUCCESS) {
			strcpy(error_text,
				"Unable to allocate memory for the ADF database file list.");
			return_code = ADF_MEMORY_FAILURE;
		}
	}

	return(return_code);
}
/*	***********************************************************************	*/

/*	***********************************************************************	*/
static void ADF_RUN_DIFF_End(control_ptr, signal_number, exit_code_ptr,
	message_buffer)
ADF_CONTROL *control_ptr;
int          signal_number;
int         *exit_code_ptr;
const char  *message_buffer;
{
	unsigned long  total_usecs;
	struct timeval overhead_interval;
	struct timeval total_interval;
	struct rusage  rusage_data;
	char           tmp_buffer_1[512];
	char           tmp_buffer_2[512];
	char           tmp_interval[256];

	if (control_ptr->shut_down_flag == GENFUNCS_TRUE)
		return;

	control_ptr->shut_down_flag = GENFUNCS_TRUE;

	/*	**************************************************************	*/
	/*	**************************************************************	*/
	/*		Get the end time of the program . . .								*/
	/*	**************************************************************	*/
	gettimeofday(&control_ptr->end_time, ((struct timezone *) NULL));
	/*	**************************************************************	*/

	sprintf(tmp_buffer_1, "%s %s %s",
		"========== ===============", "=============",
		"========================================================");
	sprintf(tmp_buffer_2, "%s %s %s",
		"---------- ---------------", "-------------",
		"--------------------------------------------------------");

	/*	**************************************************************	*/
	/*	**************************************************************	*/
	/*		Inform the user that we're bailing out . . .						*/
	/*	**************************************************************	*/
	if (control_ptr->log_file_ptr != NULL) {
		ADF_LogSeparatorEqualChar(control_ptr->log_file_ptr, stderr);
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr,
			stderr, ADF_FALSE, "Exiting . . .\n");
	}
	else if ((ADF_GetLogMessageFlagFILE() == ADF_TRUE) &&
		(control_ptr->help_flag != ADF_TRUE) &&
		(control_ptr->version_flag != ADF_TRUE) &&
		(control_ptr->quiet_flag != ADF_TRUE))
		fprintf(stderr, "Exiting . . .\n");
	/*	**************************************************************	*/

	/*	**************************************************************	*/
	/*	**************************************************************	*/
	/*	**************************************************************	*/
	total_usecs            = GEN_GET_TIMEVAL_USECS(&control_ptr->end_time) -
		GEN_GET_TIMEVAL_USECS(&control_ptr->start_time);
	total_interval.tv_sec  = ((long) total_usecs) / 1000000L;
	total_interval.tv_usec = ((long) total_usecs) % 1000000L;
	if (control_ptr->overhead_end_time.tv_sec ||
		control_ptr->overhead_end_time.tv_usec) {
		total_usecs               =
			GEN_GET_TIMEVAL_USECS(&control_ptr->overhead_end_time) -
			GEN_GET_TIMEVAL_USECS(&control_ptr->start_time);
		overhead_interval.tv_sec  = ((long) total_usecs) / 1000000L;
		overhead_interval.tv_usec = ((long) total_usecs) % 1000000L;
	}
	else {
		overhead_interval.tv_sec  = 0L;
		overhead_interval.tv_usec = 0L;
	}
	/*	**************************************************************	*/

	/*	**************************************************************	*/
	/*	**************************************************************	*/
	/*		Show timing statistics . . .											*/
	/*	**************************************************************	*/
	if (control_ptr->log_file_ptr != NULL) {
		ADF_LogSeparatorString(control_ptr->log_file_ptr, stderr,
			tmp_buffer_1);
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
			ADF_FALSE, "%-28.28s: %s\n", "Start Time",
			GEN_Format_timeval(&control_ptr->start_time, tmp_interval));
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
			ADF_FALSE, "%-28.28s: %s\n", "End Time",
			GEN_Format_timeval(&control_ptr->end_time, tmp_interval));
		ADF_LogSeparatorString(control_ptr->log_file_ptr, stderr,
			tmp_buffer_2);
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
			ADF_FALSE, "%-28.28s: %s\n", "Overhead Time",
			GEN_FormatInterval_timeval(&overhead_interval, tmp_interval));
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
			ADF_FALSE, "%-28.28s: %s\n", "Total Time",
			GEN_FormatInterval_timeval(&total_interval, tmp_interval));
		ADF_LogSeparatorString(control_ptr->log_file_ptr, stderr, tmp_buffer_2);
	}
	/*	**************************************************************	*/

	/*	**************************************************************	*/
	/*	**************************************************************	*/
	/*		Show system resource usage . . .										*/
	/*	**************************************************************	*/
	if (control_ptr->log_file_ptr != NULL) {
		if (getrusage(RUSAGE_SELF, &rusage_data))
			memset(&rusage_data, '\0', sizeof(rusage_data));
		ADF_LogSeparatorString(control_ptr->log_file_ptr, stderr, tmp_buffer_1);
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
			ADF_FALSE, "%-28.28s: %s\n", "Total User Time",
			GEN_FormatInterval_timeval(&rusage_data.ru_utime, tmp_interval));
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
			ADF_FALSE, "%-28.28s: %s\n", "Total System Time",
			GEN_FormatInterval_timeval(&rusage_data.ru_stime, tmp_interval));
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
			ADF_FALSE, "%-28.28s: %10ld\n", "Maximum Resident Set Size",
			rusage_data.ru_maxrss);
#if 0
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
			ADF_FALSE, "%-28.28s: %10ld\n", "?",
			rusage_data.ru_ixrss);
#endif /* #if 0 */
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
			ADF_FALSE, "%-28.28s: %10ld\n", "Integral Resident Set Size",
			rusage_data.ru_idrss);
#if 0
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
			ADF_FALSE, "%-28.28s: %10ld\n", "?",
			rusage_data.ru_isrss);
#endif /* #if 0 */
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
			ADF_FALSE, "%-28.28s: %10ld\n", "Minor Page Faults",
			rusage_data.ru_minflt);
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
			ADF_FALSE, "%-28.28s: %10ld\n", "Major Page Faults",
			rusage_data.ru_majflt);
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
			ADF_FALSE, "%-28.28s: %10ld\n", "Process Swapped Count",
			rusage_data.ru_nswap);
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
			ADF_FALSE, "%-28.28s: %10ld\n", "Block Input Count",
			rusage_data.ru_inblock);
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
			ADF_FALSE, "%-28.28s: %10ld\n", "Block Output Count",
			rusage_data.ru_oublock);
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
			ADF_FALSE, "%-28.28s: %10ld\n", "Messages Sent",
			rusage_data.ru_msgsnd);
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
			ADF_FALSE, "%-28.28s: %10ld\n", "Messages Received",
			rusage_data.ru_msgrcv);
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
			ADF_FALSE, "%-28.28s: %10ld\n", "Signals Received",
			rusage_data.ru_nsignals);
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
			ADF_FALSE, "%-28.28s: %10ld\n", "Voluntary Context Switches",
			rusage_data.ru_nvcsw);
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
			ADF_FALSE, "%-28.28s: %10ld\n", "Involuntary Context Switches",
			rusage_data.ru_nivcsw);
		ADF_LogSeparatorString(control_ptr->log_file_ptr, stderr, tmp_buffer_1);
	}
	/*	**************************************************************	*/

	/*	**************************************************************	*/
	/*	**************************************************************	*/
	/*		Free the memory allocated to store the program name . . .	*/
	/*	**************************************************************	*/
	if (control_ptr->program_name != NULL) {
		free(control_ptr->program_name);
		control_ptr->program_name = NULL;
	}
	/*	**************************************************************	*/

	/*	**************************************************************	*/
	/*	**************************************************************	*/
	/*		Close the log file (if open) and free-up any memory which	*/
	/*	associated with it . . .													*/
	/*	**************************************************************	*/
	if (control_ptr->log_file_ptr != NULL) {
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
			ADF_FALSE, "Closing the log file '%s'.\n",
			control_ptr->log_file_name);
		ADF_LogSeparatorEndLog(control_ptr->log_file_ptr, stderr);
		ADF_fclose(control_ptr->log_file_ptr);
		control_ptr->log_file_ptr = NULL;
	}
	if (control_ptr->log_dir != NULL) {
		free(control_ptr->log_dir);
		control_ptr->log_dir = NULL;
	}
	if (control_ptr->log_file_name != NULL) {
		free(control_ptr->log_file_name);
		control_ptr->log_file_name = NULL;
	}
	/*	**************************************************************	*/

	ADF_FREE_Control(control_ptr);
}
/*	***********************************************************************	*/

