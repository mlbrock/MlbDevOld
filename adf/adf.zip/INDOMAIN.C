/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	Automated Documentation Facility (ADF) Program Module							*/
/*	***********************************************************************	*/
/*
	File Name			:	%M%

	File Version		:	%I%

	Last Extracted		:	%D%	%T%

	Last Updated		:	%E%	%U%

	File Description	:	Intializes an ADF domain specification.

	Revision History	:	1994-06-13 --- Creation.
									Michael L. Brock
*/
/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*		Necessary include files . . .														*/
/*	***********************************************************************	*/

#include <memory.h>

#include "adf.h"

/*	***********************************************************************	*/

/*	***********************************************************************	*/
void ADF_INIT_Domain(ptr)
ADF_DOMAIN *ptr;
{
	memset(ptr, '\0', sizeof(*ptr));

	ptr->domain_name        = NULL;
	ptr->domain_description = NULL;
	ptr->file_type_count    = 0;
	ptr->file_type_list     = NULL;
	ptr->section_count      = 0;
	ptr->section_list       = NULL;

	ADF_INIT_Pattern(&ptr->boh_pattern);
	ADF_INIT_Pattern(&ptr->eoh_pattern);
	ADF_INIT_Pattern(&ptr->bol_pattern);
	ADF_INIT_Pattern(&ptr->eol_pattern);
	ADF_INIT_Pattern(&ptr->empty_line_pattern);
	ADF_INIT_Pattern(&ptr->strip_pattern);
}
/*	***********************************************************************	*/

/*	***********************************************************************	*/
void ADF_INIT_DomainList(count, list)
unsigned int  count;
ADF_DOMAIN   *list;
{
	while (count--)
		ADF_INIT_Domain(list++);
}
/*	***********************************************************************	*/

