/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	Automated Documentation Facility (ADF) Program Module							*/
/*	***********************************************************************	*/
/*
	File Name			:	%M%

	File Version		:	%I%

	Last Extracted		:	%D%	%T%

	Last Updated		:	%E%	%U%

	File Description	:	Outputs the list of ADF domain definitions to the
								specified output handler.

	Revision History	:	1994-06-15 --- Creation.
									Michael L. Brock
*/
/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*		Necessary include files . . .														*/
/*	***********************************************************************	*/

#include "adf.h"

/*	***********************************************************************	*/

/*	***********************************************************************	*/
void ADF_EMIT_Def(domain_count, domain_list, output_function, output_control)
unsigned int       domain_count;
const ADF_DOMAIN  *domain_list;
#ifndef NARGS
void             (*output_function)(void *, char *, ...);
#else
void              (*output_function)();
#endif /* #ifndef NARGS */
void               *output_control;
{
	unsigned int count_1;

#ifndef NARGS
	output_function = (output_function != NULL) ? output_function :
		((void (*)(void *, char *, ...)) fprintf);
#else
	output_function = (output_function != NULL) ? output_function : fprintf;
#endif /* #ifndef NARGS */
	output_control  = (output_control  != NULL) ? output_control  : stdout;

	for (count_1 = 0; count_1 < domain_count; count_1++)
		ADF_EMIT_DomainDef(domain_list + count_1, output_function,
			output_control);
}
/*	***********************************************************************	*/

