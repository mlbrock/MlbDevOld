/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	Automated Documentation Facility (ADF) Program Module							*/
/*	***********************************************************************	*/
/*
	File Name			:	%M%

	File Version		:	%I%

	Last Extracted		:	%D%	%T%

	Last Updated		:	%E%	%U%

	File Description	:	Manages use man-page-specific data.

	Revision History	:	1996-09-12 --- Creation.
									Michael L. Brock
*/
/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*		Necessary include files . . .														*/
/*	***********************************************************************	*/

#include <memory.h>
#include <stdlib.h>

#include "adf.h"

/*	***********************************************************************	*/

/*	***********************************************************************	*/
void ADF_InitDataMAN(man_data_ptr)
ADF_MAN_DATA *man_data_ptr;
{
	memset(man_data_ptr, '\0', sizeof(*man_data_ptr));

	man_data_ptr->section_name = NULL;
	man_data_ptr->owner_name   = NULL;
}
/*	***********************************************************************	*/

/*	***********************************************************************	*/
void ADF_FreeDataMAN(man_data_ptr)
ADF_MAN_DATA *man_data_ptr;
{
	if (man_data_ptr->section_name != NULL)
		free(man_data_ptr->section_name);

	if (man_data_ptr->owner_name != NULL)
		free(man_data_ptr->owner_name);

	ADF_InitDataMAN(man_data_ptr);
}
/*	***********************************************************************	*/

