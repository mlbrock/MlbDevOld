/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	Automated Documentation Facility (ADF) Include File							*/
/*	***********************************************************************	*/
/*
	File Name			:	%M%

	File Version		:	%I%

	Last Extracted		:	%D%	%T%

	Last Updated		:	%E%	%U%

	File Description	:	Include file for the Automated Documentation Facility.

	Revision History	:	1994-06-09 --- Creation.
									Michael L. Brock
*/
/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*		Necessary include files . . .														*/
/*	***********************************************************************	*/

#ifndef h__ADF_H__h

#define h__ADF_H__h	1

#include <limits.h>
#include <stdio.h>
#include <syslog.h>
#include <time.h>
#include <sys/param.h>
#include <sys/time.h>
#include <sys/resource.h>

#ifdef __STDC__
# include <stdarg.h>
#elif __MSDOS__
# include <stdarg.h>
#else
# include <varargs.h>
#endif /* #ifdef __STDC__ */

#include <strfuncs.h>
#include <spffuncs.h>

#include <mfile.h>

/*	***********************************************************************	*/

/* *********************************************************************** */
/* *********************************************************************** */
/* 	The macro 'offsetof' is defined by ANSI C. If it's not available on	*/
/* this system, define it . . .															*/
/* *********************************************************************** */

#ifndef offsetof
# define offsetof(structure_name, member_name) \
	((size_t) &(((structure_name *) 0)->member_name))
#endif /* #ifndef offsetof */

/* *********************************************************************** */

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

#define ADF_PATTERN_SPACE_CHAR			'\001'

#define ADF_DB_SIGNATURE_1					"Automated Documentation Facility (ADF)"
#define ADF_DB_SIGNATURE_2					"--------- ------------- -------- -----"
#define ADF_DB_COPYRIGHT					"Copyright 1992-1996, Michael L. Brock"
#define ADF_DB_END_SIGNATURE				"END_OF_ADF_FILE"

#define ADF_VERSION							"01.00.00"

#define ADF_FILE_INCOMPLETE_FLAG			((unsigned long) 0L)
#define ADF_FILE_COMPLETE_FLAG			((unsigned long) 0X55AA55AAL)

#ifdef __MSDOS__
#define ADF_END_OF_LINE_CHAR				"\r\n"
#else
#define ADF_END_OF_LINE_CHAR				"\n"
#endif /* #ifdef __MSDOS__ */

#define ADF_FILE_PAGE_SIZE					4096

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

#define ADF_TRUE								1
#define ADF_FALSE								0

#define ADF_SUCCESS							0
#define ADF_FAILURE							-1
#define ADF_BAD_ARGS_FAILURE				-2
#define ADF_MEMORY_FAILURE					-3
#define ADF_DB_FAILURE						-4
#define ADF_SYSTEM_FAILURE					-5
#define ADF_PARSE_FAILURE					-6

#define ADF_MAX_ERROR_TEXT					2048

#define ADF_ENTRY_DESCRIP_LENGTH			(1024 + 512)

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

#define ADF_AREA_NAME_LENGTH				32

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/
#define ADF_PARSE_TYPE_AREA_NAME			SPF_USER_TYPE(1)
#define ADF_PARSE_TYPE_PATTERN			SPF_USER_TYPE(2)
#define ADF_PARSE_TYPE_SECTION			SPF_USER_TYPE(3)
#define ADF_PARSE_TYPE_DOMAIN				SPF_USER_TYPE(4)
/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

#define ADF_AREA_BASE_NAME					 0
#define ADF_AREA_NAME						 1
#define ADF_AREA_SYNOPSIS					 2
#define ADF_AREA_CODE_SYNTAX				 3
#define ADF_AREA_DESCRIPTION				 4
#define ADF_AREA_DEFINITIONS				 5
#define ADF_AREA_TERMINOLOGY				 6
#define ADF_AREA_OPTIONS					 7
#define ADF_AREA_PARAMETERS				 8
#define ADF_AREA_COMMANDS					 9
#define ADF_AREA_MEMBERS					10
#define ADF_AREA_RETURNS					11
#define ADF_AREA_ERROR_MESSAGES			12
#define ADF_AREA_ENVIRONMENT				13
#define ADF_AREA_FILES						14
#define ADF_AREA_ALGORITHMS				15
#define ADF_AREA_DEBUGGING					16
#define ADF_AREA_DIAGNOSTICS				17
#define ADF_AREA_NOTES						18
#define ADF_AREA_CAVEATS					19
#define ADF_AREA_DEFAULTS					20
#define ADF_AREA_BUGS						21
#define ADF_AREA_LIMITATIONS				22
#define ADF_AREA_COMPATIBILITY			23
#define ADF_AREA_IDIOSYNCRACIES			24
#define ADF_AREA_SEE_ALSO					25
#define ADF_AREA_EXAMPLES					26
#define ADF_AREA_CODE_EXAMPLES			27
#define ADF_AREA_AUTHORS					28
#define ADF_AREA_CONTRIBUTORS				29
#define ADF_AREA_ACKNOWLEDGMENTS			30
#define ADF_AREA_CREDITS					31
#define ADF_AREA_REFERENCES				32
#define ADF_AREA_RESTRICTIONS				33
#define ADF_AREA_DISCLAIMERS				34
#define ADF_AREA_COPYING					35
#define ADF_AREA_COPYRIGHTS				36
#define ADF_AREA_TRADEMARKS				37
#define ADF_AREA_SOURCE_FILE_NAME		38
#define ADF_AREA_SOURCE_FILE_DATE		39
#define ADF_AREA_MAN_SECTION				40
#define ADF_AREA_TAB_SETTING				41
#define ADF_AREA_OUTPUT_INDEX				42
#define ADF_AREA_PUBLISH_XREF				43
#define ADF_AREA_PUBLISH_NAME				44
#define ADF_AREA_SOURCE_FILE_FULL_NAME	45
#define ADF_AREA_ENTRY_CLASS_NAME		46

#define ADF_AREA_COUNT						47

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

#define ADF_CFORMAT_MARKER_CHAR			'\001'

#define ADF_CFORMAT_TYPE_NONE				((unsigned int)   0)
#define ADF_CFORMAT_TYPE_BOLD				((unsigned int)   1)
#define ADF_CFORMAT_TYPE_ITALIC			((unsigned int)   2)
#define ADF_CFORMAT_TYPE_ULINED			((unsigned int)   4)
#define ADF_CFORMAT_TYPE_OLINED			((unsigned int)   8)
#define ADF_CFORMAT_TYPE_STHRU			((unsigned int)  16)
#define ADF_CFORMAT_TYPE_EINDEX			((unsigned int)  32)
#define ADF_CFORMAT_TYPE_SUBSCRIPT		((unsigned int)  64)
#define ADF_CFORMAT_TYPE_SUPERSCRIPT	((unsigned int) 128)
#define ADF_CFORMAT_TYPE_HTEXT			((unsigned int) 256)

#define ADF_CFORMAT_TYPE_ALL				((unsigned int) 0XFFFFU)

#define ADF_CFORMAT_CHAR_NONE				'\0'
#define ADF_CFORMAT_CHAR_BOLD				'B'
#define ADF_CFORMAT_CHAR_ITALIC			'I'
#define ADF_CFORMAT_CHAR_ULINED			'U'
#define ADF_CFORMAT_CHAR_OLINED			'O'
#define ADF_CFORMAT_CHAR_STHRU			'T'
#define ADF_CFORMAT_CHAR_EINDEX			'X'
#define ADF_CFORMAT_CHAR_SUBSCRIPT		'Y'
#define ADF_CFORMAT_CHAR_SUPERSCRIPT	'Z'
#define ADF_CFORMAT_CHAR_HTEXT			'H'

#define ADF_CFORMAT_CHAR_NONE_1			'\0'
#define ADF_CFORMAT_CHAR_BOLD_1			'B'
#define ADF_CFORMAT_CHAR_ITALIC_1		'I'
#define ADF_CFORMAT_CHAR_ULINED_1		'U'
#define ADF_CFORMAT_CHAR_OLINED_1		'O'
#define ADF_CFORMAT_CHAR_STHRU_1			'T'
#define ADF_CFORMAT_CHAR_EINDEX_1		'X'
#define ADF_CFORMAT_CHAR_SUBSCRIPT_1	'Y'
#define ADF_CFORMAT_CHAR_SUPERSCRIPT_1	'Z'
#define ADF_CFORMAT_CHAR_HTEXT_1			'H'

#define ADF_CFORMAT_CHAR_NONE_2			'\0'
#define ADF_CFORMAT_CHAR_BOLD_2			'b'
#define ADF_CFORMAT_CHAR_ITALIC_2		'i'
#define ADF_CFORMAT_CHAR_ULINED_2		'u'
#define ADF_CFORMAT_CHAR_OLINED_2		'o'
#define ADF_CFORMAT_CHAR_STHRU_2			't'
#define ADF_CFORMAT_CHAR_EINDEX_2		'x'
#define ADF_CFORMAT_CHAR_SUBSCRIPT_2	'y'
#define ADF_CFORMAT_CHAR_SUPERSCRIPT_2	'z'
#define ADF_CFORMAT_CHAR_HTEXT_2			'h'

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

#define ADF_PFORMAT_MARKER_CHAR			'\002'

#define ADF_PFORMAT_COUNT					160

#define ADF_PFORMAT_LENGTH					18

#define ADF_PFORMAT_TYPE_NONE				0
#define ADF_PFORMAT_TYPE_BB				1
#define ADF_PFORMAT_TYPE_IN				2
#define ADF_PFORMAT_TYPE_NM				3

#define ADF_PFORMAT_TYPE_COUNT			4

#define ADF_PFORMAT_LEVEL_COUNT			4

#define ADF_PFORMAT_BRACE_TYPE_COUNT	4

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

#define ADF_BASIC_CHAR_MULTIPLIER		3

#define ADF_CFORMAT_MULTIPLIER			100

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

#define ADF_PREP_FILE_MODE_EITHER		0
#define ADF_PREP_FILE_MODE_CREATE		1
#define ADF_PREP_FILE_MODE_UPDATE		2

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

#define ADF_DUP_HANDLER_NONE				0
#define ADF_DUP_HANDLER_FIRST				1
#define ADF_DUP_HANDLER_LAST				2

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/
#define ADF_BOH_SPEC_FILE_TYPE			0
#define ADF_BOH_SPEC_MAN_PAGE				1
#define ADF_BOH_SPEC_TAB_SETTING			2

#define ADF_BOH_SPEC_COUNT					3
/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/
#define ADF_DEFAULT_MAN_PAGE				"3"
/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/
#define ADF_VALID_MAN_PAGE_STRING		"123456789lnop"
/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/
#define ADF_DEFAULT_TAB_VALUE				3
#define ADF_DEFAULT_TAB_STRING			"3"
/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

#define ADF_OUTPUT_TYPE_ASCII				0
#define ADF_OUTPUT_TYPE_FRAME				1
#define ADF_OUTPUT_TYPE_HTML				2
#define ADF_OUTPUT_TYPE_MAN				3
#define ADF_OUTPUT_TYPE_PS					4
#define ADF_OUTPUT_TYPE_RTF				5

#define ADF_OUTPUT_TYPE_COUNT				6

#define ADF_OUTPUT_TYPE_NAME_LENGTH		63

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

#define ADF_GENERATE_TYPE_ENTRY			0
#define ADF_GENERATE_TYPE_TOC				1
#define ADF_GENERATE_TYPE_CLASS_TOC		2
#define ADF_GENERATE_TYPE_TOF				3
#define ADF_GENERATE_TYPE_INDEX			4
#define ADF_GENERATE_TYPE_PERM_INDEX	5

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

#define ADF_AREA_NAME_TYPE_INTERNAL		0
#define ADF_AREA_NAME_TYPE_DEF			1

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

#define ADF_AREA_ORDER_TYPE_INTERNAL	0
#define ADF_AREA_ORDER_TYPE_DEF			1
#define ADF_AREA_ORDER_TYPE_SOURCE		2

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

#define ADF_SORT_ENTRY_ENTRY				0
#define ADF_SORT_ENTRY_BASE_NAME			1
#define ADF_SORT_ENTRY_FILE_NAME			2
#define ADF_SORT_ENTRY_CORE_NAME			3
#define ADF_SORT_ENTRY_FILE_TYPE			4
#define ADF_SORT_ENTRY_MAN_PAGE			5

#define ADF_SORT_ENTRY_DICT_ORDER		6

#define ADF_SORT_HTEXT_ENTRY				0
#define ADF_SORT_HTEXT_TEXT				1

#define ADF_SORT_IGNORE_CASE				64

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

#define ADF_CLUDE_TYPE_BASE_NAME			0
#define ADF_CLUDE_TYPE_FILE_NAME			1
#define ADF_CLUDE_TYPE_FILE_TYPE			2
#define ADF_CLUDE_TYPE_MAN_PAGE			3

#define ADF_CLUDE_TYPE_COUNT				4

#define ADF_CLUDE_BASIS_INCLUDE			0
#define ADF_CLUDE_BASIS_EXCLUDE			1

#define ADF_CLUDE_BASIS_COUNT				2

typedef struct {
	unsigned int   clude_count;
	char         **clude_list;
} ADF_CLUDE;

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

#ifdef __MSDOS__
# define ADF_fclose							fclose
# define ADF_fflush							fflush
# define ADF_fopen							fopen
# define ADF_fprintf							fprintf
# define ADF_fread							fread
# define ADF_fseek							fseek
# define ADF_ftell							ftell
# define ADF_fwrite							fwrite
#elif _Windows
# define ADF_fclose							fclose
# define ADF_fflush							fflush
# define ADF_fopen							fopen
# define ADF_fprintf							fprintf
# define ADF_fread							fread
# define ADF_fseek							fseek
# define ADF_ftell							ftell
# define ADF_fwrite							fwrite
#else
# define ADF_fclose							mclose
# define ADF_fflush							mflush
# define ADF_fopen							mopen
# define ADF_fprintf							mprintf
# define ADF_fread							mread
# define ADF_fseek							mseek
# define ADF_ftell							mtell
# define ADF_fwrite							mwrite
#endif /* #ifdef __MSDOS__ */

#ifdef __MSDOS__
# include <alloc.h>
# define ADF_BIG_char						char huge
# define ADF_BIG_void						void huge
# define ADF_BIG_calloc						farcalloc
# define ADF_BIG_malloc						farmalloc
# define ADF_BIG_realloc					farrealloc
# define ADF_BIG_free						farfree
#else
# define ADF_BIG_char						char
# define ADF_BIG_void						void
# define ADF_BIG_calloc						calloc
# define ADF_BIG_malloc						malloc
# define ADF_BIG_realloc					realloc
# define ADF_BIG_free						free
#endif /* #ifdef __MSDOS__ */

#define ADF_FILE_PAD_LENGTH				sizeof(double)

#define ADF_FILE_ENTRY_DIR_OFFSET		0
#define ADF_FILE_HYPER_TEXT_OFFSET		1
#define ADF_FILE_ENTRY_DIR_LENGTH		2
#define ADF_FILE_HYPER_TEXT_LENGTH		3
#define ADF_FILE_ENTRY_DIR_COUNT			4
#define ADF_FILE_HYPER_TEXT_COUNT		5

#define ADF_FILE_EOF_COUNT					6

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

#ifdef __MSDOS__
typedef FILE  ADF_FILE;
#elif _Windows
typedef FILE  ADF_FILE;
#else
typedef MFILE ADF_FILE;
#endif /* #ifdef __MSDOS__ */

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

#define ADF_MAN_MARGIN_PADDING			3

#define ADF_MAN_CFORMAT_TYPE				(ADF_CFORMAT_TYPE_BOLD |	\
	ADF_CFORMAT_TYPE_ITALIC | ADF_CFORMAT_TYPE_SUBSCRIPT |			\
	ADF_CFORMAT_TYPE_SUPERSCRIPT)

#define ADF_HTML_CFORMAT_TYPE				(ADF_CFORMAT_TYPE_BOLD |	\
	ADF_CFORMAT_TYPE_ITALIC | ADF_CFORMAT_TYPE_ULINED |				\
	ADF_CFORMAT_TYPE_STHRU | ADF_CFORMAT_TYPE_SUBSCRIPT |				\
	ADF_CFORMAT_TYPE_SUPERSCRIPT | ADF_CFORMAT_TYPE_HTEXT)

#define ADF_RTF_CFORMAT_TYPE				(ADF_CFORMAT_TYPE_BOLD |	\
	ADF_CFORMAT_TYPE_ITALIC | ADF_CFORMAT_TYPE_ULINED |				\
	ADF_CFORMAT_TYPE_STHRU | ADF_CFORMAT_TYPE_EINDEX |					\
	ADF_CFORMAT_TYPE_SUBSCRIPT | ADF_CFORMAT_TYPE_SUPERSCRIPT)

#define ADF_FRAME_CFORMAT_TYPE			(ADF_CFORMAT_TYPE_BOLD |	\
	ADF_CFORMAT_TYPE_ITALIC | ADF_CFORMAT_TYPE_ULINED |				\
	ADF_CFORMAT_TYPE_OLINED | ADF_CFORMAT_TYPE_STHRU |					\
	ADF_CFORMAT_TYPE_EINDEX | ADF_CFORMAT_TYPE_SUBSCRIPT |			\
	ADF_CFORMAT_TYPE_SUPERSCRIPT | ADF_CFORMAT_TYPE_HTEXT)

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

#define ADF_HTML_VERSION_1_0				0
#define ADF_HTML_VERSION_2_0				1
#define ADF_HTML_VERSION_PLUS				2
#define ADF_HTML_VERSION_DEFAULT			ADF_HTML_VERSION_1_0

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

#ifdef __MSDOS__
# include <direct.h>
# include <dir.h>
#define getpid()								666
#define gethostname(name, length)		\
	(nstrcat(name, "MS-DOS-Machine", length) == NULL)
#define getwd(name)							getcwd(name, 100)
#define getrusage(who, rusage)			\
	(memset(rusage, '\0', sizeof(*rusage)) == NULL)
#elif _Windows
# include <direct.h>
# include <dir.h>
#define getpid()								666
#define gethostname(name, length)		\
	(nstrcat(name, "Windows-Machine", length) == NULL)
#define getwd(name)							getcwd(name, 100)
#define getrusage(who, rusage)			\
	(memset(rusage, '\0', sizeof(*rusage)) == NULL)
#endif /* #ifdef __MSDOS__ */

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

#define ADF_DICT_ORDER_CHAR(in_char)			\
	((isalpha(in_char)) ? toupper(in_char) :	\
	(isdigit(in_char) ? ((in_char - '0') + 1) : '\0'))

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

typedef struct {
	unsigned int   pattern_count;
	char         **pattern_list;
	char          *pattern_optimization;
} ADF_PATTERN;

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

typedef struct {
	unsigned int   file_index;
	unsigned int   entry_index;
	unsigned long  entry_offset;
	char          *base_name;
	char          *file_name;
	char          *core_name;
	char          *full_name;
	char          *file_type;
	char          *man_page;
	time_t         file_date;
	time_t         prep_date;
	int            href_flag;
} ADF_ENTRY;

typedef struct {
	unsigned int   file_index;
	unsigned int   entry_index;
	unsigned long  entry_offset;
	time_t         file_date;
	time_t         prep_date;
/*
	CODE NOTE: To be deleted.
	unsigned int   base_name_length;
	unsigned int   file_name_length;
	unsigned int   core_name_length;
	unsigned int   full_name_length;
	unsigned int   file_type_length;
	unsigned int   man_page_length;
*/
	unsigned int   base_name_offset;
	unsigned int   file_name_offset;
	unsigned int   core_name_offset;
	unsigned int   full_name_offset;
	unsigned int   file_type_offset;
	unsigned int   man_page_offset;
} ADF_ENTRY_FILE;

typedef struct {
	unsigned int data_length;
	unsigned int paragraph_count;
	unsigned int name_offset[ADF_AREA_COUNT];
	unsigned int name_length[ADF_AREA_COUNT];
	unsigned int section_offset[ADF_AREA_COUNT];
	unsigned int section_length[ADF_AREA_COUNT];
	unsigned int section_order[ADF_AREA_COUNT];
	unsigned int actual_order[ADF_AREA_COUNT];
} ADF_ENTRY_DATA_FILE;

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

typedef struct {
	unsigned int  file_index;
	unsigned int  entry_index;
	unsigned int  htext_length;
	char         *hyper_text;
	unsigned int  in_entry_index;
} ADF_HTEXT;

typedef struct {
	unsigned int  file_index;
	unsigned int  entry_index;
	unsigned int  htext_length;
	unsigned int  htext_offset;
} ADF_HTEXT_FILE;

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

typedef struct {
	char *area_name;
	char *area_tag;
	int   required_flag;
	int   pformat_flag;
	int   cformat_flag;
	int   eindex_flag;
	int   htext_flag;
	int   output_flag;
} ADF_AREA;

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

typedef struct {
	char         *section_name;
	char         *output_section_name;
	unsigned int  area_index;
	int           required_flag;
	int           wrap_flag;
	int           ltrim_flag;
	int           rtrim_flag;
	int           squeeze_flag;
	int           para_format_flag;
	int           char_format_flag;
	int           eindex_flag;
	int           htext_flag;
	ADF_PATTERN   match_pattern;
} ADF_SECTION;

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

typedef struct {
	char          *domain_name;
	char          *domain_description;
	unsigned int   file_type_count;
	char         **file_type_list;
	ADF_PATTERN    boh_pattern;
	ADF_PATTERN    eoh_pattern;
	ADF_PATTERN    bol_pattern;
	ADF_PATTERN    eol_pattern;
	ADF_PATTERN    empty_line_pattern;
	ADF_PATTERN    strip_pattern;
	unsigned int   section_count;
	ADF_SECTION   *section_list;
} ADF_DOMAIN;

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

typedef struct {
	ADF_SECTION   *section_ptr;
	unsigned int   section_index;
	char          *section_name;
	unsigned int   start_position;
	unsigned int   line_number;
	unsigned int   line_count;
	char         **line_list;
	char          *line_data;
} ADF_SOURCE_DATA;
	
/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

typedef struct {
	char         *format_string;
	int           char_format_flag;
	int           small_font_flag;
	unsigned int  indent_level;
	int           format_type;
	int           begin_rule_flag;
	int           end_rule_flag;
	int           supported_flag;
} ADF_PFORMAT_DEF;

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

typedef struct {
	int           pformat_flag;
	unsigned int  pformat_index;
	int           char_format_flag;
	int           small_font_flag;
	unsigned int  indent_level;
	int           format_type;
	int           begin_rule_flag;
	int           end_rule_flag;
	unsigned long numeric_value;
	unsigned int  first_count;
	unsigned int  last_count;
} ADF_PFORMAT;

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

typedef struct {
	ADF_PFORMAT  para_format;
	char        *text_ptr;
} ADF_PARA_DATA;

typedef struct {
	unsigned int   area_index;
	unsigned int   section_order;
	unsigned int   actual_order;
	char          *section_name;
	unsigned int   para_count;
	ADF_PARA_DATA *para_list;
} ADF_ENTRY_DATA;

typedef struct {
	int           cformat_type;
	unsigned int  htext_index;
	unsigned int  length;
	char         *ptr;
} ADF_PARA_TEXT;

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

typedef struct {
	time_t        creation_date;
	time_t        update_date;
	char          version_number[16];
	int           area_count;
	unsigned int  sizeof_ADF_ENTRY_FILE;
	unsigned int  sizeof_ADF_HTEXT_FILE;
	unsigned int  sizeof_ADF_ENTRY_DATA_FILE;
	unsigned long completion_flag;
	unsigned long file_length;
	unsigned long entry_data_offset;
	unsigned int  entry_data_length;
	unsigned long entry_list_offset;
	unsigned int  entry_list_length;
	unsigned int  entry_list_count;
	unsigned long htext_data_offset;
	unsigned int  htext_data_length;
	unsigned long htext_list_offset;
	unsigned int  htext_list_length;
	unsigned int  htext_list_count;
} ADF_FILE_HEADER;

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

typedef struct {
	char            *file_name;
	char            *href_string;
	int              href_flag;
	ADF_FILE        *file_ptr;
	char            *entry_buffer;
	char            *htext_buffer;
	ADF_FILE_HEADER  header;
	time_t           last_access_time;
} ADF_IN_FILE;

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

typedef struct tag_ADF_INDEX_ITEM {
	unsigned char               item_order;
	char                       *item_name;
	int                         entry_flag;
	unsigned int                index_item_count;
	struct tag_ADF_INDEX_ITEM  *index_item_list;
	const ADF_ENTRY            *entry_ptr;
	unsigned int                htext_index;
} ADF_INDEX_ITEM;

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/
typedef struct {
	unsigned char  item_order;
	unsigned int   entry_index;
	unsigned int   ref_count;
	unsigned int  *ref_list;
} ADF_PERM_INDEX;
/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

typedef struct {
	unsigned int  count;
	ADF_HTEXT    *list;
} ADF_HTEXT_CHARS;

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

typedef struct {
	int    optional_flag;
#ifndef NARGS
	int  (*usage_function)(const char *base_arg_ptr, int optional_flag,
		const char **extra_usage_list, unsigned int *usage_count,
		char ***usage_list, char *error_text);
#else
	int  (*usage_function)();
#endif /* #ifndef NARGS */
	char  *added_text;
} ADF_RUN_USAGE;

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/
typedef struct {
	char *ptr_1;
	char *ptr_2;
} ADF_STRING_PAIR;
/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/
typedef struct {
	char *document_name;
	char *owner_name;
	char *copyright;
	char *cover_name_1;
	char *cover_name_2;
	char *long_name;
	char *short_name;
} ADF_FRAME_DATA;
/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/
typedef struct {
	unsigned int     author_link_count;
	ADF_STRING_PAIR *author_link_list;
	unsigned int     copyright_link_count;
	ADF_STRING_PAIR *copyright_link_list;
	char             html_heading_level[15 + 1];
} ADF_HTML_DATA;
/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/
typedef struct {
	char *section_name;
	char *owner_name;
} ADF_MAN_DATA;
/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

typedef struct {
	char             *program_name;
	char             *short_program_name;
	char              host_name[MAXHOSTNAMELEN + 1];
	int               process_id;
	char              current_dir[MAXPATHLEN + 1];
	struct timeval    start_time;
	struct timeval    end_time;
	struct timeval    overhead_end_time;
	int               help_flag;
	int               version_flag;
	int               shut_down_flag;
	int               signal_received_flag;
	int               queue_signal_flag;
	unsigned int      domain_count;
	ADF_DOMAIN       *domain_list;
	char             *adf_def_file_name;
	char             *prep_adf_file_name;
	ADF_FILE         *prep_adf_file;
	int               prep_adf_file_mode;
	char             *prep_tmp_file_name;
	unsigned int      prep_src_file_length;
	char             *prep_src_file;
	unsigned int      prep_src_core_file_length;
	char             *prep_src_core_file;
	unsigned int      in_file_name_count;
	char            **in_file_name_list;
	unsigned int      htext_ref_file_name_count;
	char            **htext_ref_file_name_list;
	unsigned int      in_file_count;
	ADF_IN_FILE      *in_file_list;
	unsigned int      prep_entry_count;
	ADF_ENTRY        *prep_entry_list;
	unsigned int      prep_htext_count;
	ADF_HTEXT        *prep_htext_list;
	unsigned int      in_entry_count;
	ADF_ENTRY        *in_entry_list;
	unsigned int      in_htext_count;
	ADF_HTEXT        *in_htext_list;
	ADF_HTEXT_CHARS   in_htext_lookup_list[UCHAR_MAX + 1];
	unsigned int      in_entry_order_count;
	ADF_ENTRY       **in_entry_order_list;
	unsigned int      read_entry_buffer_length;
	char             *read_entry_buffer;
	unsigned int      current_para_line_count;
	unsigned int      in_para_line_count;
	ADF_PARA_TEXT    *in_para_line_list;
	unsigned int      in_para_htext_ptr_count;
	ADF_HTEXT       **in_para_htext_ptr_list;
	unsigned int      out_para_buffer_length;
	char             *out_para_buffer;
	unsigned int      wrap_buffer_length;
	char             *wrap_buffer;
	unsigned int      in_entry_para_count;
	ADF_PARA_DATA    *in_entry_para_list;
	char             *default_author;
	char             *default_copyright;
	char             *default_man_page;
	char             *log_dir;
	char             *log_file_name;
	ADF_FILE         *log_file_ptr;
	char             *output_dir;
	char             *output_dir_basic;
	unsigned int      output_file_name_length;
	char             *output_file_name;
	FILE             *output_file_ptr;
	unsigned int      htext_link_name_length;
	char             *htext_link_name;
	int               duplicate_handling_type;
	int               sort_order_type;
	int               output_type;
	int               check_only_flag;
	int               cont_on_error_flag;
	int               ignore_bad_cmnt_flag;
	int               forced_author_flag;
	int               forced_copyright_flag;
	int               forced_man_page_flag;
	int               check_comment_flag;
	int               error_on_no_comment_flag;
	int               no_required_sections_flag;
	int               ignore_bad_xrefs_flag;
	int               remove_bad_xrefs_flag;
	int               keep_bad_xrefs_flag;
	int               list_frame_xrefs_flag;
	int               xref_tree_flag;
	int               hyper_text_flag;
	int               generate_type;
	int               log_flag;
	int               quiet_flag;
	int               output_comment_flag;
	int               output_by_file_flag;
	int               output_to_stdout_flag;
	int               ignore_section_list[ADF_AREA_COUNT];
	int               area_name_type;
	int               area_order_type;
	int               keep_bad_see_also_flag;
	int               html_version;
	unsigned int      entry_include_count;
	unsigned int      entry_exclude_count;
	ADF_CLUDE         entry_clude[ADF_CLUDE_BASIS_COUNT][ADF_CLUDE_TYPE_COUNT];
	unsigned int      htext_include_count;
	unsigned int      htext_exclude_count;
	ADF_CLUDE			htext_clude[ADF_CLUDE_BASIS_COUNT];
	char             *area_name_list[ADF_AREA_COUNT];
	unsigned int      non_ref_index_count;
	char            **non_ref_index_list;
	int               rtf_para_style_list_flag;
	char             *rtf_para_style_list[ADF_PFORMAT_COUNT];
	ADF_FRAME_DATA    frame_data;
	ADF_HTML_DATA     html_data;
	ADF_MAN_DATA      man_data;
} ADF_CONTROL;

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*		Function prototypes . . .															*/
/*	***********************************************************************	*/

#ifndef NARGS
#else
#endif /* #ifndef NARGS */

	/*	*****************************************************************	*/
	/*	*****************************************************************	*/
	/*		Definition parse support function prototypes . . .					*/
	/*	*****************************************************************	*/
#ifndef NARGS
int ADF_PARSE_Any(SPF_CONTEXT *context_ptr, const SPF_SPEC *spec_ptr,
	const SPF_PARSE *parse_ptr, void *parent_ptr, char *error_text);
int ADF_PARSE_AreaName(const SPF_SPEC *spec_ptr, const SPF_PARSE *parse_ptr,
	unsigned int *area_name_ptr, char *error_text);
int ADF_PARSE_Domain(SPF_CONTEXT *context_ptr, const SPF_SPEC *spec_ptr,
	const SPF_PARSE *parse_ptr, void *parent_ptr, unsigned int *domain_count,
	ADF_DOMAIN **domain_list, char *error_text);
int ADF_PARSE_Main(SPF_CONTEXT *context_ptr, const char *file_name,
	const char *def_string, char *error_text);
int ADF_PARSE_Pattern(const SPF_SPEC *spec_ptr, const SPF_PARSE *parse_ptr,
	ADF_PATTERN *pattern_ptr, char *error_text);
int ADF_PARSE_Section(SPF_CONTEXT *context_ptr, const SPF_SPEC *spec_ptr,
	const SPF_PARSE *parse_ptr, void *parent_ptr, unsigned int *section_count,
	ADF_SECTION **section_list, char *error_text);
int ADF_PARSE_OptPat(ADF_PATTERN *in_pattern, char *error_text);
#else
#endif /* #ifndef NARGS */
	/*	*****************************************************************	*/

#ifndef NARGS
int   ADF_GetOutputTypeFromString(const char *output_type_string,
	int *output_type, char *error_text);
char *ADF_GetOutputTypeString(int output_type, char *output_type_string);
#else
int   ADF_GetOutputTypeFromString();
char *ADF_GetOutputTypeString();
#endif /* #ifndef NARGS */

#ifndef NARGS
int ADF_GetOutputFunctions(int output_type,
	int  (**init_function)(ADF_CONTROL *control_ptr, char *error_text),
	int  (**by_entry_function)(ADF_CONTROL *control_ptr,
		const ADF_ENTRY *entry_ptr, char *error_text),
	int  (**to_stdout_function)(ADF_CONTROL *control_ptr,
		const ADF_ENTRY *entry_ptr, const time_t *output_date, char *error_text),
	int  (**by_file_function)(ADF_CONTROL *control_ptr,
		unsigned int *entry_index, char *error_text),
	int  (**toc_function)(ADF_CONTROL *control_ptr, char *error_text),
	int  (**class_toc_function)(ADF_CONTROL *control_ptr, char *error_text),
	int  (**tof_function)(ADF_CONTROL *control_ptr, char *error_text),
	int  (**index_function)(ADF_CONTROL *control_ptr, char *error_text),
	int  (**perm_index_function)(ADF_CONTROL *control_ptr, char *error_text),
	void (**output_start_function)(ADF_CONTROL *control_ptr,
		const char *output_name, const time_t *output_date,
		void (*output_function)(void *, char *, ...), void *output_control),
	void (**output_end_function)(ADF_CONTROL *control_ptr,
		void (*output_function)(void *, char *, ...), void *output_control),
	void (**output_between_function)(ADF_CONTROL *control_ptr,
		const ADF_ENTRY *entry_ptr, const char *output_name,
		void (*output_function)(void *, char *, ...), void *output_control),
	char *error_text);
#else
#endif /* #ifndef NARGS */

#ifndef NARGS
int ADF_GetAreaList(ADF_CONTROL *control_ptr, const ADF_ENTRY *entry_ptr,
	ADF_ENTRY_DATA *entry_data_ptr, unsigned int *out_count, char ***out_list,
	char *error_text);
int ADF_GetAreaString(ADF_CONTROL *control_ptr, const ADF_ENTRY *entry_ptr,
	ADF_ENTRY_DATA *entry_data_ptr, char **out_string, char *error_text);
#else
int ADF_GetAreaList();
int ADF_GetAreaString();
#endif /* #ifndef NARGS */

#ifndef NARGS
int ADF_ASCII_OutputByEntry(ADF_CONTROL *control_ptr,
	const ADF_ENTRY *entry_ptr, char *error_text);
int ADF_ASCII_OutputToStdout(ADF_CONTROL *control_ptr,
	const ADF_ENTRY *entry_ptr, const time_t *output_date, char *error_text);
int ADF_ASCII_OutputByFile(ADF_CONTROL *control_ptr,
	unsigned int *entry_index, char *error_text);
int ADF_ASCII_OutputTOC(ADF_CONTROL *control_ptr, char *error_text);
int ADF_ASCII_OutputIndex(ADF_CONTROL *control_ptr, char *error_text);
#else
#endif /* #ifndef NARGS */

#ifndef NARGS
int  ADF_FRAME_OutputByEntry(ADF_CONTROL *control_ptr,
	const ADF_ENTRY *entry_ptr, char *error_text);
int  ADF_FRAME_OutputToStdout(ADF_CONTROL *control_ptr,
	const ADF_ENTRY *entry_ptr, const time_t *output_date, char *error_text);
int  ADF_FRAME_OutputByFile(ADF_CONTROL *control_ptr,
	unsigned int *entry_index, char *error_text);
int  ADF_FRAME_OutputIndex(ADF_CONTROL *control_ptr, char *error_text);
int  ADF_FRAME_OutputTOC(ADF_CONTROL *control_ptr, char *error_text);
void ADF_FRAME_OutputStart(ADF_CONTROL *control_ptr, const char *output_name,
	const time_t *output_date, void (*output_function)(void *, char *, ...),
	void *output_control);
void ADF_FRAME_OutputEnd(ADF_CONTROL *control_ptr,
	void (*output_function)(void *, char *, ...), void *output_control);
#else
#endif /* #ifndef NARGS */

#ifndef NARGS
int  ADF_HTML_OutputByEntry(ADF_CONTROL *control_ptr,
	const ADF_ENTRY *entry_ptr, char *error_text);
int  ADF_HTML_OutputToStdout(ADF_CONTROL *control_ptr,
	const ADF_ENTRY *entry_ptr, const time_t *output_date, char *error_text);
int  ADF_HTML_OutputByFile(ADF_CONTROL *control_ptr,
	unsigned int *entry_index, char *error_text);
int  ADF_HTML_OutputIndex(ADF_CONTROL *control_ptr, char *error_text);
int  ADF_HTML_OutputPermIndex(ADF_CONTROL *control_ptr, char *error_text);
int  ADF_HTML_OutputTOC(ADF_CONTROL *control_ptr, char *error_text);
int  ADF_HTML_OutputClassTOC(ADF_CONTROL *control_ptr, char *error_text);
int  ADF_HTML_OutputTOF(ADF_CONTROL *control_ptr, char *error_text);
#else
#endif /* #ifndef NARGS */

#ifndef NARGS
int  ADF_MAN_OutputByEntry(ADF_CONTROL *control_ptr,
	const ADF_ENTRY *entry_ptr, char *error_text);
int  ADF_MAN_OutputToStdout(ADF_CONTROL *control_ptr,
	const ADF_ENTRY *entry_ptr, const time_t *output_date, char *error_text);
int  ADF_MAN_OutputByFile(ADF_CONTROL *control_ptr,
	unsigned int *entry_index, char *error_text);
int  ADF_MAN_OutputIndex(ADF_CONTROL *control_ptr, char *error_text);
int  ADF_MAN_OutputTOC(ADF_CONTROL *control_ptr, char *error_text);
#else
#endif /* #ifndef NARGS */

#ifndef NARGS
int ADF_PS_OutputByEntry(ADF_CONTROL *control_ptr,
	const ADF_ENTRY *entry_ptr, char *error_text);
int ADF_PS_OutputToStdout(ADF_CONTROL *control_ptr,
	const ADF_ENTRY *entry_ptr, const time_t *output_date, char *error_text);
int ADF_PS_OutputByFile(ADF_CONTROL *control_ptr,
	unsigned int *entry_index, char *error_text);
int ADF_PS_OutputIndex(ADF_CONTROL *control_ptr, char *error_text);
int ADF_PS_OutputTOC(ADF_CONTROL *control_ptr, char *error_text);
#else
#endif /* #ifndef NARGS */

#ifndef NARGS
int  ADF_RTF_OutputInit(ADF_CONTROL *control_ptr, char *error_text);
int  ADF_RTF_OutputByEntry(ADF_CONTROL *control_ptr,
	const ADF_ENTRY *entry_ptr, char *error_text);
int  ADF_RTF_OutputToStdout(ADF_CONTROL *control_ptr,
	const ADF_ENTRY *entry_ptr, const time_t *output_date, char *error_text);
int  ADF_RTF_OutputByFile(ADF_CONTROL *control_ptr,
	unsigned int *entry_index, char *error_text);
void ADF_RTF_OutputStart(ADF_CONTROL *control_ptr, const char *output_name,
	const time_t *output_date, void (*output_function)(void *, char *, ...),
	void *output_control);
void ADF_RTF_OutputEnd(ADF_CONTROL *control_ptr,
	void (*output_function)(void *, char *, ...), void *output_control);
#else
#endif /* #ifndef NARGS */

#ifndef NARGS
int ADF_DoSource(ADF_CONTROL *control_ptr, unsigned int domain_count,
	const ADF_DOMAIN *domain_list, const char *file_name, char *error_text);
#else
#endif /* #ifndef NARGS */

#ifndef NARGS
int   ADF_ValidateManPage(const char *man_page, char *error_text);
char *ADF_GetDefaultManSection(const char *man_page, char *man_section); 
#else
int   ADF_ValidateManPage();
char *ADF_GetDefaultManSection();
#endif /* #ifndef NARGS */

#ifndef NARGS
void ADF_InitDataFRAME(ADF_FRAME_DATA *frame_data_ptr);
void ADF_FreeDataFRAME(ADF_FRAME_DATA *frame_data_ptr);
void ADF_InitDataHTML(ADF_HTML_DATA *html_data_ptr);
void ADF_FreeDataHTML(ADF_HTML_DATA *html_data_ptr);
void ADF_InitDataMAN(ADF_MAN_DATA *man_data_ptr);
void ADF_FreeDataMAN(ADF_MAN_DATA *man_data_ptr);
#else
#endif /* #ifndef NARGS */

#ifndef NARGS
int  ADF_StringPairParse(const char *string_pair_name,
	const char *string_pair_data, unsigned int *string_pair_count,
	ADF_STRING_PAIR **string_pair_list, char *error_text);
int  ADF_StrPairAlloc(const char *string_ptr_1, const char *string_ptr_2,
	ADF_STRING_PAIR *string_pair_ptr, char *error_text);
int  ADF_StrPairListAlloc(const char *string_ptr_1, const char *string_ptr_2,
	unsigned int *string_pair_count, ADF_STRING_PAIR **string_pair_list,
	char *error_text);
void ADF_StrPairFree(ADF_STRING_PAIR *string_pair_ptr);
void ADF_StrPairListFree(unsigned int *string_pair_count,
	ADF_STRING_PAIR **string_pair_list);
void ADF_StrPairInit(ADF_STRING_PAIR *string_pair_ptr);
int  ADF_SEARCH_StrPairList(const char *string_ptr_1, const char *string_ptr_2,
	unsigned int *string_pair_count, ADF_STRING_PAIR **string_pair_list,
	char *error_text);
#else
#endif /* #ifndef NARGS */

#ifndef NARGS
int ADF_FixParagraph(ADF_CONTROL *control_ptr, const ADF_ENTRY *entry_ptr,
	ADF_PARA_DATA *para_ptr, unsigned int cformat_flags, char *error_text);
int ADF_FixParagraphWrap(ADF_CONTROL *control_ptr, const ADF_ENTRY *entry_ptr,
	ADF_PARA_DATA *para_ptr, unsigned int cformat_flags,
	unsigned int output_width, unsigned int tab_setting,
	unsigned int left_padding, char *error_text);
#else
int ADF_FixParagraph();
int ADF_FixParagraphWrap();
#endif /* #ifndef NARGS */

#ifndef NARGS
int  ADF_GetEntry(ADF_CONTROL *control_ptr, const ADF_ENTRY *entry_ptr,
	ADF_ENTRY_DATA *entry_data_list, char *error_text);
#else
#endif /* #ifndef NARGS */

#ifndef NARGS
int  ADF_CMP_EntryDataList(const ADF_ENTRY_DATA *entry_data_list_1,
	const ADF_ENTRY_DATA *entry_data_list_2, unsigned int *diff_area_index,
	unsigned int *diff_para_index);
int  ADF_CMP_EntryData(const ADF_ENTRY_DATA *entry_data_ptr_1,
	const ADF_ENTRY_DATA *entry_data_ptr_2, unsigned int *diff_para_index);
#else
int  ADF_CMP_EntryDataList();
int  ADF_CMP_EntryData();
#endif /* #ifndef NARGS */

#ifndef NARGS
int  ADF_COPY_EntryDataList(const ADF_ENTRY_DATA *in_entry_data_list,
	ADF_ENTRY_DATA *out_entry_data_list, char *error_text);
int  ADF_COPY_EntryData(const ADF_ENTRY_DATA *in_entry_data_ptr,
	ADF_ENTRY_DATA *out_entry_data_ptr, char *error_text);
#else
int  ADF_COPY_EntryDataList();
int  ADF_COPY_EntryData();
#endif /* #ifndef NARGS */

#ifndef NARGS
void ADF_FREE_AreaDataList(ADF_ENTRY_DATA *entry_data_list);
void ADF_FREE_AreaData(ADF_ENTRY_DATA *entry_data_ptr);
#else
void ADF_FREE_AreaDataList();
void ADF_FREE_AreaData();
#endif /* #ifndef NARGS */

#ifndef NARGS
void ADF_INIT_AreaDataList(ADF_ENTRY_DATA *entry_data_list);
void ADF_INIT_AreaData(ADF_ENTRY_DATA *entry_data_ptr);
#else
void ADF_INIT_AreaDataList();
void ADF_INIT_AreaData();
#endif /* #ifndef NARGS */

#ifndef NARGS
int  ADF_COPY_ParaDataList(unsigned int in_para_count,
	const ADF_PARA_DATA *in_para_list, unsigned int *out_para_count,
	ADF_PARA_DATA **out_para_list, char *error_text);
int  ADF_COPY_ParaData(const ADF_PARA_DATA *in_para_ptr,
	ADF_PARA_DATA *out_para_ptr, char *error_text);
#else
int  ADF_COPY_ParaDataList();
int  ADF_COPY_ParaData();
#endif /* #ifndef NARGS */

#ifndef NARGS
void ADF_FREE_ParaDataList(unsigned int *para_count,
	ADF_PARA_DATA **para_list);
void ADF_FREE_ParaData(ADF_PARA_DATA *para_ptr);
#else
void ADF_FREE_ParaDataList();
void ADF_FREE_ParaData();
#endif /* #ifndef NARGS */

#ifndef NARGS
void ADF_INIT_ParaDataList(unsigned int para_count, ADF_PARA_DATA *para_list);
void ADF_INIT_ParaData(ADF_PARA_DATA *para_ptr);
#else
void ADF_INIT_ParaDataList();
void ADF_INIT_ParaData();
#endif /* #ifndef NARGS */

#ifndef NARGS
int  ADF_ApplyCludesEntry(ADF_CONTROL *control_ptr, const char *base_name,
	const char *file_name, const char *file_type, const char *man_page);
int  ADF_ApplyCludesHText(ADF_CONTROL *control_ptr, const char *hyper_text);
void ADF_FREE_CludeItem(ADF_CLUDE *clude_ptr);
void ADF_INIT_CludeItem(ADF_CLUDE *clude_ptr);
#else
#endif /* #ifndef NARGS */

#ifndef NARGS
int  ADF_LoadInFileList(ADF_CONTROL *control_ptr, char *error_text);
int  ADF_LoadHTextRefFileList(ADF_CONTROL *control_ptr, char *error_text);
int  ADF_OpenADFFileIn(ADF_CONTROL *control_ptr, const char *file_name,
	char *error_text);
int  ADF_OpenADFFileHTextRef(ADF_CONTROL *control_ptr, const char *file_name,
	const char *href_string, char *error_text);
int  ADF_OpenADFFile(ADF_CONTROL *control_ptr, const char *file_name,
	const char *href_string, ADF_IN_FILE *in_file_ptr, char *error_text);
void ADF_CloseADFFileIn(ADF_CONTROL *control_ptr);
#else
#endif /* #ifndef NARGS */

#ifndef NARGS
int  ADF_OpenADFFilePrep(ADF_CONTROL *control_ptr, const char *file_name,
	char *error_text);
void ADF_CloseADFFilePrep(ADF_CONTROL *control_ptr);
int  ADF_WriteADFHumanHeader(ADF_FILE *prep_adf_file_ptr,
	const ADF_FILE_HEADER *header_ptr, char *error_text);
int  ADF_AddToPrepList(ADF_CONTROL *control_ptr, const char *base_name,
	const char *file_name, const char *core_name, const char *full_name,
	const char *file_type, const char *man_page, const time_t *file_date,
	const time_t *prep_date, const ADF_DOMAIN *domain_ptr,
	const ADF_SOURCE_DATA *area_list, unsigned int publish_xref_count,
	char **publish_xref_list, char *error_text);
int  ADF_WriteTrailer(ADF_CONTROL *control_ptr, unsigned int entry_count,
	const ADF_ENTRY *entry_list, unsigned int htext_count,
	const ADF_HTEXT *htext_list, char *error_text);
#else
#endif /* #ifndef NARGS */

#ifndef NARGS
void ADF_RemoveExistingEntry(ADF_CONTROL *control_ptr,
	unsigned int entry_index);
void ADF_RemoveHText(const ADF_ENTRY *entry_ptr, unsigned int *htext_count,
	ADF_HTEXT **htext_list);
#else
void ADF_RemoveExistingEntry();
void ADF_RemoveHText();
#endif /* #ifndef NARGS */

#ifndef NARGS
char            *ADF_DescribeEntry(const ADF_ENTRY *entry_ptr, char *buffer);
char            *ADF_DescribeInEntry(const ADF_ENTRY *entry_ptr,
	const ADF_IN_FILE *in_file_ptr, char *buffer);
const ADF_ENTRY *ADF_FIND_LookUpEntryByEntry(unsigned int entry_count,
	const ADF_ENTRY *entry_list, unsigned int file_index,
	unsigned int entry_index, unsigned int *found_index);
int              ADF_FIND_FindEntryByEntry(unsigned int entry_count,
	const ADF_ENTRY *entry_list, unsigned int file_index,
	unsigned int entry_index, unsigned int *found_index);
int              ADF_FIND_FindEntryByBaseName(unsigned int entry_count,
	const ADF_ENTRY *entry_list, const char *base_name,
	unsigned int *found_index);
int              ADF_FIND_FindHTextByText(unsigned int htext_count,
	const ADF_HTEXT *htext_list, const char *hyper_text,
	unsigned int *found_index);
int              ADF_AllocateEntryItem(ADF_ENTRY *entry_ptr,
	const char *base_name, const char *file_name, const char *core_name,
	const char *full_name, const char *file_type, const char *man_page,
	char *error_text);
int              ADF_AllocateHTextItem(ADF_HTEXT *htext_ptr,
	const char *hyper_text, char *error_text);
void             ADF_FreeEntryListPrep(ADF_CONTROL *control_ptr);
void             ADF_FreeHTextListPrep(ADF_CONTROL *control_ptr);
void             ADF_FreeEntryListIn(ADF_CONTROL *control_ptr);
void             ADF_FreeHTextListIn(ADF_CONTROL *control_ptr);
void             ADF_FreeEntryItem(ADF_ENTRY *entry_ptr);
void             ADF_FreeHTextItem(ADF_HTEXT *htext_ptr);
void             ADF_SORT_EntryList(int sort_type, unsigned int entry_count,
	ADF_ENTRY *entry_list);
void             ADF_SORT_HTextList(int sort_type, unsigned int htext_count,
	ADF_HTEXT *htext_list);
int              ADF_FinalizeEntries(ADF_CONTROL *control_ptr,
	char *error_text);
int              ADF_ReadEntry(ADF_CONTROL *control_ptr,
	const ADF_ENTRY *entry_ptr, ADF_ENTRY_DATA_FILE *entry_data_ptr,
	ADF_SOURCE_DATA *area_list, char *error_text);
int              ADF_WriteEntry(ADF_CONTROL *control_ptr,
	ADF_ENTRY *entry_ptr, const ADF_SOURCE_DATA *area_list, char *error_text);
void             ADF_SORT_EntrySections(int sort_type,
	ADF_ENTRY_DATA *entry_data_list);
#else
#endif /* #ifndef NARGS */

#ifndef NARGS
void ADF_FreeInFileList(ADF_CONTROL *control_ptr);
void ADF_FREE_InFileItem(ADF_IN_FILE *in_file_ptr);
void ADF_INIT_InFilePtr(ADF_IN_FILE *in_file_ptr);
int  ADF_PadFile(ADF_FILE *adf_file_ptr, char *error_text);
int  ADF_PadFileBasic(ADF_FILE *adf_file_ptr, unsigned long pad_modulus,
	char *error_text);
int  ADF_FRead(void *buffer, unsigned int size, unsigned int count,
	ADF_FILE *adf_file_ptr, char *error_text);
int  ADF_FWrite(const void *buffer, unsigned int size, unsigned int count,
	ADF_FILE *adf_file_ptr, char *error_text);
#else
#endif /* #ifndef NARGS */

#ifndef NARGS
const ADF_PFORMAT_DEF *ADF_MatchParaFormat(const char *in_string,
	char *para_format_ptr, unsigned int *para_format_index,
	unsigned int *pattern_end_index);
const ADF_PFORMAT_DEF *ADF_GetParaFormat(unsigned int para_format_index);
char                  *ADF_MakeFormatString(unsigned int pformat_index,
	char *pformat_string);
#else
#endif /* #ifndef NARGS */

#ifndef NARGS
int ADF_MatchPattern(const char *in_string, const char *pattern_string,
	unsigned int *pattern_end_index);
int ADF_MatchPatternList(const char *in_string, unsigned int pattern_count,
	const char **pattern_list, unsigned int *pattern_end_index);
int ADF_MatchPatternPtr(const char *in_string, const ADF_PATTERN *pattern_ptr,
	unsigned int *pattern_end_index);
#else
#endif /* #ifndef NARGS */

#ifndef NARGS
int  ADF_BuildIndexItemList(ADF_CONTROL *control_ptr,
	unsigned int *index_item_count, ADF_INDEX_ITEM **index_item_list,
	char *error_text);
int  ADF_BuildClassTOCItemList(ADF_CONTROL *control_ptr,
	unsigned int *index_item_count, ADF_INDEX_ITEM **index_item_list,
	char *error_text);
int  ADF_BuildPermIndex(ADF_CONTROL *control_ptr,
	unsigned int *index_item_count, ADF_PERM_INDEX **index_item_list,
	char *error_text);
void ADF_FreeIndexItemList(unsigned int *index_item_count,
	ADF_INDEX_ITEM **index_item_list);
void ADF_FreeIndexItem(ADF_INDEX_ITEM *index_item_ptr);
void ADF_FreePermIndexList(unsigned int *index_item_count,
	ADF_PERM_INDEX **index_item_list);
void ADF_FreePermIndex(ADF_PERM_INDEX *index_item_ptr);
#else
#endif /* #ifndef NARGS */

#ifndef NARGS
void ADF_INIT_Control(ADF_CONTROL *control_ptr);
void ADF_INIT_Domain(ADF_DOMAIN *ptr);
void ADF_INIT_DomainList(unsigned int count, ADF_DOMAIN *list);
void ADF_INIT_Pattern(ADF_PATTERN *ptr);
void ADF_INIT_Section(ADF_SECTION *ptr);
void ADF_INIT_SectionList(unsigned int count, ADF_SECTION *list);
#else
#endif /* #ifndef NARGS */

#ifndef NARGS
int ADF_COPY_Domain(const ADF_DOMAIN *in_ptr, ADF_DOMAIN *out_ptr,
	char *error_text);
int ADF_COPY_DomainList(unsigned int in_count, const ADF_DOMAIN *in_list,
	unsigned int *out_count, ADF_DOMAIN **out_list, char *error_text);
int ADF_COPY_Pattern(const ADF_PATTERN *in_ptr, ADF_PATTERN *out_ptr,
	char *error_text);
int ADF_COPY_Section(const ADF_SECTION *in_ptr, ADF_SECTION *out_ptr,
	char *error_text);
int ADF_COPY_SectionList(unsigned int in_count,
	const ADF_SECTION *in_list, unsigned int *out_count,
	ADF_SECTION **out_list, char *error_text);
#else
#endif /* #ifndef NARGS */

#ifndef NARGS
void ADF_FREE_Control(ADF_CONTROL *control_ptr);
void ADF_FREE_Domain(ADF_DOMAIN *ptr);
void ADF_FREE_DomainList(unsigned int *count, ADF_DOMAIN **list);
void ADF_FREE_Pattern(ADF_PATTERN *ptr);
void ADF_FREE_Section(ADF_SECTION *ptr);
void ADF_FREE_SectionList(unsigned int *count, ADF_SECTION **list);
#else
#endif /* #ifndef NARGS */

#ifndef NARGS
int  ADF_CopyDefaultDefSpec(unsigned int *domain_count,
	ADF_DOMAIN **domain_list, char *error_text);
void ADF_GetDefaultDefSpec(unsigned int *domain_count,
	ADF_DOMAIN **domain_list);
#else
#endif /* #ifndef NARGS */

#ifndef NARGS
int ADF_EMIT_DefCDomainList(unsigned int domain_count,
	const ADF_DOMAIN *domain_list,
	void (*output_function)(void *, char *, ...), void *output_control,
	char *error_text);
#else
#endif /* #ifndef NARGS */

#ifndef NARGS
void ADF_EMIT_Def(unsigned int domain_count, const ADF_DOMAIN *domain_list,
	void (*output_function)(void *, char *, ...), void *output_control);
void ADF_EMIT_DomainDef(const ADF_DOMAIN *domain_ptr,
	void (*output_function)(void *, char *, ...), void *output_control);
void ADF_EMIT_PatternList(const ADF_PATTERN *pattern_ptr,
	const char *pattern_name, int trailing_comma_flag,
	void (*output_function)(void *, char *, ...), void *output_control);
void ADF_EMIT_PatternString(const char *pattern_string,
	const char *pattern_name, int trailing_comma_flag,
	void (*output_function)(void *, char *, ...), void *output_control);
void ADF_EMIT_SectionDef(const ADF_SECTION *section_ptr,
	void (*output_function)(void *, char *, ...), void *output_control);
#else
#endif /* #ifndef NARGS */

#ifndef NARGS
int ADF_ReadSourceFile(const char *file_name, unsigned int *line_count,
	char ***line_list, ADF_BIG_char **buffer_ptr, char *error_text);
int ADF_ReadDefinitionFile(ADF_CONTROL *control_ptr, const char *file_name,
	char *error_text);
int ADF_ReadFileBuffer(const char *file_name, unsigned int *buffer_length,
	char **buffer_ptr, char *error_text);
#else
#endif /* #ifndef NARGS */

#ifndef NARGS
char *ADF_AreaToParseArea(char *area_name);
char *ADF_GetAreaName(unsigned int area_index, char *area_name);
char *ADF_GetParseAreaName(unsigned int area_index, char *area_name);
char *ADF_GetOutputAreaName(int area_name_type, unsigned int area_index,
	char **area_name_list, const char *section_name,
	unsigned int max_area_name_length, char *area_name);
#else
#endif /* #ifndef NARGS */

#ifndef NARGS
char *ADF_GetSpecifedErrorString(int, char *);
char *ADF_GetLastErrorString(char *);
#else
char *ADF_GetSpecifedErrorString();
char *ADF_GetLastErrorString();
#endif /* #ifndef NARGS */

#ifndef NARGS
const ADF_AREA   *ADF_FIND_AreaByName(const char *area_name,
	unsigned int *found_index);
const ADF_DOMAIN *ADF_FIND_Domain(unsigned int domain_count,
	const ADF_DOMAIN *domain_list, const char *file_type,
	unsigned int *found_index);
#else
#endif /* #ifndef NARGS */

#ifndef NARGS
int ADF_GetParams(void *control_ptr, unsigned int argc, char **argv,
	int *help_flag, int *version_flag, int (*parse_function)(void *,
	unsigned int, char **, int, unsigned int, char *), char *error_text);
#else
int ADF_GetParams();
#endif /* #ifndef NARGS */

#ifndef NARGS
void ADF_DoSimpleUsage(int exit_code, const char *program_name,
	const char *exit_message, const char *usage_string);
void ADF_DoUsage(int exit_code, const char *program_name,
	const char *exit_message, const char **usage_string_list);
void ADF_DoFormatUsage(int exit_code, const char *program_name,
	const char *exit_message, const char **usage_string_list);
#else
void ADF_DoSimpleUsage();
void ADF_DoUsage();
void ADF_DoFormatUsage();
#endif /* #ifndef NARGS */

#ifndef NARGS
# ifdef __STDC__
void ADF_LogMessage(struct timeval *timeval_ptr, int log_priority,
	ADF_FILE *adf_file_ptr, FILE *file_ptr, int syslog_flag,
	const char *in_format, ...);
# elif __MSDOS__
void ADF_LogMessage(struct timeval *timeval_ptr, int log_priority,
	ADF_FILE *adf_file_ptr, FILE *file_ptr, int syslog_flag,
	const char *in_format, ...);
# else
void ADF_LogMessage(struct timeval *timeval_ptr, int log_priority,
	ADF_FILE *adf_file_ptr, FILE *file_ptr, int syslog_flag,
	const char *in_format, va_alist);
# endif /* #ifdef __STDC__ */
int  ADF_LogEnsureSpace(ADF_FILE *adf_file_ptr);
void ADF_LogSeparatorStartLog(ADF_FILE *adf_file_ptr, FILE *file_ptr);
void ADF_LogSeparatorEndLog(ADF_FILE *adf_file_ptr, FILE *file_ptr);
void ADF_LogSeparatorHyphenChar(ADF_FILE *adf_file_ptr, FILE *file_ptr);
void ADF_LogSeparatorEqualChar(ADF_FILE *adf_file_ptr, FILE *file_ptr);
void ADF_LogSeparatorChar(ADF_FILE *adf_file_ptr, FILE *file_ptr,
	int log_char);
void ADF_LogSeparatorString(ADF_FILE *adf_file_ptr, FILE *file_ptr,
	const char *log_string);
int  ADF_GetLogMessageFlagFILE(void);
int  ADF_GetLogMessageFlagADF_FILE(void);
int  ADF_GetLogMessageFlagSYSLOG(void);
int  ADF_SetLogMessageFlagFILE(int new_flag_value);
int  ADF_SetLogMessageFlagADF_FILE(int new_flag_value);
int  ADF_SetLogMessageFlagSYSLOG(int new_flag_value);
#else
void ADF_LogMessage();
int  ADF_LogEnsureSpace();
void ADF_LogSeparatorStartLog();
void ADF_LogSeparatorEndLog();
void ADF_LogSeparatorHyphenChar();
void ADF_LogSeparatorEqualChar();
void ADF_LogSeparatorChar();
void ADF_LogSeparatorString();
int  ADF_GetLogMessageFlagFILE();
int  ADF_GetLogMessageFlagADF_FILE();
int  ADF_GetLogMessageFlagSYSLOG();
int  ADF_SetLogMessageFlagFILE();
int  ADF_SetLogMessageFlagADF_FILE();
int  ADF_SetLogMessageFlagSYSLOG();
#endif /* #ifndef NARGS */

#ifndef NARGS
int   ADF_RUN_AllocFileString(ADF_CONTROL *control_ptr,
	unsigned int alloc_length, char *error_text);
int   ADF_RUN_AllocHTextString(ADF_CONTROL *control_ptr,
	unsigned int link_length, char *error_text);
int   ADF_RUN_AllocString(unsigned int alloc_length, const char *alloc_text,
	unsigned int *string_length, char **string_ptr, char *error_text);
char *ADF_RUN_CleanName(char *in_name);
int   ADF_RUN_OpenOutputFile(ADF_CONTROL *control_ptr, char *error_text);
int   ADF_RUN_OpenLogFile(ADF_CONTROL *control_ptr, char *error_text);
void  ADF_RUN_LogOutputFile(ADF_CONTROL *control_ptr,
	const ADF_ENTRY *entry_ptr, const char *output_file_name);
#else
int   ADF_RUN_AllocFileString();
int   ADF_RUN_AllocHTextString();
int   ADF_RUN_AllocString();
char *ADF_RUN_CleanName();
int   ADF_RUN_OpenOutputFile();
int   ADF_RUN_OpenLogFile();
void  ADF_RUN_LogOutputFile();
#endif /* #ifndef NARGS */

#ifndef NARGS
int ADF_PARG_ADFDefFile(const char *in_arg_ptr, unsigned int *in_arg_length,
	char **in_data_ptr, char **adf_def_file_name, int *error_code,
	char *error_text);
int ADF_PARG_IgnoreBadCmntFlag(const char *in_arg_ptr,
	unsigned int *in_arg_length, char **in_data_ptr, int *ignore_bad_cmt_flag,
	int *error_code, char *error_text);
int ADF_PARG_PrepADFFile(const char *in_arg_ptr, unsigned int *in_arg_length,
	char **in_data_ptr, char **prep_adf_file_name, int *error_code,
	char *error_text);
int ADF_PARG_PrepADFFileMode(const char *in_arg_ptr,
	unsigned int *in_arg_length, char **in_data_ptr, int *prep_adf_file_mode,
	int *error_code, char *error_text);
#else
#endif /* #ifndef NARGS */

#ifndef NARGS
int ADF_PUSE_ADFDefFile(const char *base_arg_ptr, int optional_flag,
	const char **extra_usage_list, unsigned int *usage_count,
	char ***usage_list, char *error_text);
int ADF_PUSE_IgnoreBadCmntFlag(const char *base_arg_ptr, int optional_flag,
	const char **extra_usage_list, unsigned int *usage_count,
	char ***usage_list, char *error_text);
int ADF_PUSE_PrepADFFile(const char *base_arg_ptr, int optional_flag,
	const char **extra_usage_list, unsigned int *usage_count,
	char ***usage_list, char *error_text);
int ADF_PUSE_PrepADFFileMode(const char *base_arg_ptr, int optional_flag,
	const char **extra_usage_list, unsigned int *usage_count,
	char ***usage_list, char *error_text);
#else
#endif /* #ifndef NARGS */

#ifndef NARGS
int ADF_OARG_AreaName(const char *in_arg_ptr,
	unsigned int *in_arg_length, char **in_data_ptr, char **area_name_list,
	int *error_code, char *error_text);
int ADF_OARG_AreaNameType(const char *in_arg_ptr,
	unsigned int *in_arg_length, char **in_data_ptr, int *area_name_type,
	int *error_code, char *error_text);
int ADF_OARG_AreaOrderType(const char *in_arg_ptr,
	unsigned int *in_arg_length, char **in_data_ptr, int *area_order_type,
	int *error_code, char *error_text);
int ADF_OARG_ExternalHTextRef(const char *in_arg_ptr,
	unsigned int *in_arg_length, char **in_data_ptr, char **external_ref,
	int *error_code, char *error_text);
int ADF_OARG_GenerateType(const char *in_arg_ptr,
	unsigned int *in_arg_length, char **in_data_ptr, int *generate_type,
	int *error_code, char *error_text);
int ADF_OARG_HyperTextFlag(const char *in_arg_ptr,
	unsigned int *in_arg_length, char **in_data_ptr, int *hyper_text_flag,
	int *error_code, char *error_text);
int ADF_OARG_KeepBadSeeAlso(const char *in_arg_ptr,
	unsigned int *in_arg_length, char **in_data_ptr,
	int *keep_bad_see_also_flag, int *error_code, char *error_text);
int ADF_OARG_OutputByFileFlag(const char *in_arg_ptr,
	unsigned int *in_arg_length, char **in_data_ptr,
	int *output_by_file_flag, int *error_code, char *error_text);
int ADF_OARG_OutputCommentFlag(const char *in_arg_ptr,
	unsigned int *in_arg_length, char **in_data_ptr,
	int *output_comment_flag, int *error_code, char *error_text);
int ADF_OARG_OutputDir(const char *in_arg_ptr, unsigned int *in_arg_length,
	char **in_data_ptr, char **output_dir, char **output_dir_basic,
	int *error_code, char *error_text);
int ADF_OARG_OutputToStdoutFlag(const char *in_arg_ptr,
	unsigned int *in_arg_length, char **in_data_ptr,
	int *output_to_stdout_flag, int *error_code, char *error_text);
int ADF_OARG_OutputType(const char *in_arg_ptr,
	unsigned int *in_arg_length, char **in_data_ptr, int *output_type,
	int *error_code, char *error_text);
int ADF_OARG_ParseOutParam(const char *in_arg_ptr,
	unsigned int *in_arg_length, char **in_data_ptr,
	ADF_CONTROL *control_ptr, int *error_code, char *error_text);
#else
int ADF_OARG_AreaName();
int ADF_OARG_AreaNameType();
int ADF_OARG_AreaOrderType();
int ADF_OARG_ExternalHTextRef();
int ADF_OARG_GenerateType();
int ADF_OARG_HyperTextFlag();
int ADF_OARG_KeepBadSeeAlso();
int ADF_OARG_OutputByFileFlag();
int ADF_OARG_OutputCommentFlag();
int ADF_OARG_OutputDir();
int ADF_OARG_OutputToStdoutFlag();
int ADF_OARG_OutputType();
int ADF_OARG_ParseOutParam();
#endif /* #ifndef NARGS */

#ifndef NARGS
int ADF_OUSE_AreaName(const char *base_arg_ptr, int optional_flag,
	const char **extra_usage_list, unsigned int *usage_count,
	char ***usage_list, char *error_text);
int ADF_OUSE_AreaNameType(const char *base_arg_ptr, int optional_flag,
	const char **extra_usage_list, unsigned int *usage_count,
	char ***usage_list, char *error_text);
int ADF_OUSE_AreaOrderType(const char *base_arg_ptr, int optional_flag,
	const char **extra_usage_list, unsigned int *usage_count,
	char ***usage_list, char *error_text);
int ADF_OUSE_ExternalHTextRef(const char *base_arg_ptr, int optional_flag,
	const char **extra_usage_list, unsigned int *usage_count,
	char ***usage_list, char *error_text);
int ADF_OUSE_GenerateType(const char *base_arg_ptr, int optional_flag,
	const char **extra_usage_list, unsigned int *usage_count,
	char ***usage_list, char *error_text);
int ADF_OUSE_HyperTextFlag(const char *base_arg_ptr, int optional_flag,
	const char **extra_usage_list, unsigned int *usage_count,
	char ***usage_list, char *error_text);
int ADF_OUSE_KeepBadSeeAlso(const char *base_arg_ptr, int optional_flag,
	const char **extra_usage_list, unsigned int *usage_count,
	char ***usage_list, char *error_text);
int ADF_OUSE_OutputByFileFlag(const char *base_arg_ptr, int optional_flag,
	const char **extra_usage_list, unsigned int *usage_count,
	char ***usage_list, char *error_text);
int ADF_OUSE_OutputCommentFlag(const char *base_arg_ptr, int optional_flag,
	const char **extra_usage_list, unsigned int *usage_count,
	char ***usage_list, char *error_text);
int ADF_OUSE_OutputDir(const char *base_arg_ptr, int optional_flag,
	const char **extra_usage_list, unsigned int *usage_count,
	char ***usage_list, char *error_text);
int ADF_OUSE_OutputToStdoutFlag(const char *base_arg_ptr, int optional_flag,
	const char **extra_usage_list, unsigned int *usage_count,
	char ***usage_list, char *error_text);
int ADF_OUSE_OutputType(const char *base_arg_ptr, int optional_flag,
	const char **extra_usage_list, unsigned int *usage_count,
	char ***usage_list, char *error_text);
int ADF_OUSE_ParseOutParam(const char *base_arg_ptr, int optional_flag,
	const char **extra_usage_list, unsigned int *usage_count,
	char ***usage_list, char *error_text);
#else
int ADF_OUSE_AreaName();
int ADF_OUSE_AreaNameType();
int ADF_OUSE_AreaOrderType();
int ADF_OUSE_ExternalHTextRef();
int ADF_OUSE_GenerateType();
int ADF_OUSE_HyperTextFlag();
int ADF_OUSE_KeepBadSeeAlso();
int ADF_OUSE_OutputByFileFlag();
int ADF_OUSE_OutputCommentFlag();
int ADF_OUSE_OutputDir();
int ADF_OARG_OutputToStdoutFlag();
int ADF_OUSE_OutputType();
int ADF_OUSE_ParseOutParam();
#endif /* #ifndef NARGS */

#ifndef NARGS
int ADF_OARG_FRAME_ParseOutParam(const char *in_arg_ptr,
	unsigned int *in_arg_length, char **in_data_ptr,
	ADF_FRAME_DATA *html_data_ptr, int *error_code, char *error_text);
int ADF_OARG_HTML_ParseOutParam(const char *in_arg_ptr,
	unsigned int *in_arg_length, char **in_data_ptr,
	ADF_HTML_DATA *html_data_ptr, int *error_code, char *error_text);
int ADF_OARG_MAN_ParseOutParam(const char *in_arg_ptr,
	unsigned int *in_arg_length, char **in_data_ptr,
	ADF_MAN_DATA *man_data_ptr, int *error_code, char *error_text);
#else
#endif /* #ifndef NARGS */

#ifndef NARGS
int ADF_OUSE_FRAME_ParseOutParam(const char *base_arg_ptr, int optional_flag,
	const char **extra_usage_list, unsigned int *usage_count,
	char ***usage_list, char *error_text);
int ADF_OUSE_HTML_ParseOutParam(const char *base_arg_ptr, int optional_flag,
	const char **extra_usage_list, unsigned int *usage_count,
	char ***usage_list, char *error_text);
int ADF_OUSE_MAN_ParseOutParam(const char *base_arg_ptr, int optional_flag,
	const char **extra_usage_list, unsigned int *usage_count,
	char ***usage_list, char *error_text);
#else
#endif /* #ifndef NARGS */

#ifndef NARGS
int  ADF_BARG_CheckOnlyFlag(const char *in_arg_ptr,
	unsigned int *in_arg_length, char **in_data_ptr, int *check_only_flag,
	int *error_code, char *error_text);
int  ADF_BARG_CludeEntry(const char *in_arg_ptr,
	unsigned int *in_arg_length, char **in_data_ptr, ADF_CONTROL *control_ptr,
	int *error_code, char *error_text);
int  ADF_BARG_CludeHText(const char *in_arg_ptr,
	unsigned int *in_arg_length, char **in_data_ptr, ADF_CONTROL *control_ptr,
	int *error_code, char *error_text);
int  ADF_BARG_ContOnErrorFlag(const char *in_arg_ptr,
	unsigned int *in_arg_length, char **in_data_ptr, int *cont_on_error_flag,
	int *error_code, char *error_text);
int  ADF_BARG_DuplicateType(const char *in_arg_ptr,
	unsigned int *in_arg_length, char **in_data_ptr, int *dup_handling_type,
	int *error_code, char *error_text);
int  ADF_BARG_IgnoreSection(const char *in_arg_ptr,
	unsigned int *in_arg_length, char **in_data_ptr, int *ignore_section_list,
	int *error_code, char *error_text);
int  ADF_BARG_LogDir(const char *in_arg_ptr, unsigned int *in_arg_length,
	char **in_data_ptr, char **log_dir, int *error_code, char *error_text);
int  ADF_BARG_LogFlag(const char *in_arg_ptr, unsigned int *in_arg_length,
	char **in_data_ptr, int *log_flag, int *error_code, char *error_text);
int  ADF_BARG_QuietFlag(const char *in_arg_ptr, unsigned int *in_arg_length,
	char **in_data_ptr, int *quiet_flag, int *error_code, char *error_text);
int  ADF_BARG_SortOrderType(const char *in_arg_ptr,
	unsigned int *in_arg_length, char **in_data_ptr, int *sort_order_type,
	int *error_code, char *error_text);
int  ADF_BARG_BasicParamAlloc(const char *in_arg_ptr, unsigned int arg_length,
	const char *data_ptr, char **alloc_ptr, char *error_text);
int  ADF_BARG_BasicPathExpand(const char *in_arg_ptr, unsigned int arg_length,
	const char *data_ptr, char **alloc_ptr, char *error_text);
void ADF_BARG_BadComponentMsg(const char *in_arg_ptr, unsigned int arg_length,
	const char *data_ptr, const char *expected_string, char *error_text);
#else
#endif /* #ifndef NARGS */

#ifndef NARGS
int ADF_BUSE_CheckOnlyFlag(const char *base_arg_ptr, int optional_flag,
	const char **extra_usage_list, unsigned int *usage_count,
	char ***usage_list, char *error_text);
int ADF_BUSE_CludeEntry(const char *base_arg_ptr, int optional_flag,
	const char **extra_usage_list, unsigned int *usage_count,
	char ***usage_list, char *error_text);
int ADF_BUSE_CludeHText(const char *base_arg_ptr, int optional_flag,
	const char **extra_usage_list, unsigned int *usage_count,
	char ***usage_list, char *error_text);
int ADF_BUSE_ContOnErrorFlag(const char *base_arg_ptr, int optional_flag,
	const char **extra_usage_list, unsigned int *usage_count,
	char ***usage_list, char *error_text);
int ADF_BUSE_DuplicateType(const char *base_arg_ptr, int optional_flag,
	const char **extra_usage_list, unsigned int *usage_count,
	char ***usage_list, char *error_text);
int ADF_BUSE_Help(const char *base_arg_ptr, int optional_flag,
	const char **extra_usage_list, unsigned int *usage_count,
	char ***usage_list, char *error_text);
int ADF_BUSE_IgnoreSection(const char *base_arg_ptr, int optional_flag,
	const char **extra_usage_list, unsigned int *usage_count,
	char ***usage_list, char *error_text);
int ADF_BUSE_LogDir(const char *base_arg_ptr, int optional_flag,
	const char **extra_usage_list, unsigned int *usage_count,
	char ***usage_list, char *error_text);
int ADF_BUSE_LogFlag(const char *base_arg_ptr, int optional_flag,
	const char **extra_usage_list, unsigned int *usage_count,
	char ***usage_list, char *error_text);
int ADF_BUSE_QuietFlag(const char *base_arg_ptr, int optional_flag,
	const char **extra_usage_list, unsigned int *usage_count,
	char ***usage_list, char *error_text);
int ADF_BUSE_SortOrderType(const char *base_arg_ptr, int optional_flag,
	const char **extra_usage_list, unsigned int *usage_count,
	char ***usage_list, char *error_text);
int ADF_BUSE_Version(const char *base_arg_ptr, int optional_flag,
	const char **extra_usage_list, unsigned int *usage_count,
	char ***usage_list, char *error_text);
int ADF_BUSE_AppendParamText(unsigned int *usage_count, char ***usage_list,
	char *error_text);
int ADF_BUSE_AppendLine(const char *in_line, unsigned int *usage_count,
	char ***usage_list, char *error_text);
int ADF_BUSE_AppendNL(unsigned int *usage_count, char ***usage_list,
	char *error_text);
int ADF_BUSE_AppendNULL(unsigned int *usage_count, char ***usage_list,
	char *error_text);
int ADF_BUSE_BasicConstruct(const char *base_arg_ptr, const char *arg_ptr,
	int optional_flag, const char **arg_usage_list,
	const char **extra_usage_list, unsigned int *usage_count,
	char ***usage_list, char *error_text);
#else
#endif /* #ifndef NARGS */

/*	***********************************************************************	*/

#endif /* #ifndef h__ADF_H__h */

