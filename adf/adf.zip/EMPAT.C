/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	Automated Documentation Facility (ADF) Program Module							*/
/*	***********************************************************************	*/
/*
	File Name			:	%M%

	File Version		:	%I%

	Last Extracted		:	%D%	%T%

	Last Updated		:	%E%	%U%

	File Description	:	Outputs ADF pattern specifications to the specified
								output handler.

	Revision History	:	1995-08-15 --- Creation.
									Michael L. Brock
*/
/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*		Necessary include files . . .														*/
/*	***********************************************************************	*/

#include "adf.h"

/*	***********************************************************************	*/

/*	***********************************************************************	*/
void ADF_EMIT_PatternList(pattern_ptr, pattern_name, trailing_comma_flag,
	output_function, output_control)
const ADF_PATTERN  *pattern_ptr;
const char         *pattern_name;
int                 trailing_comma_flag;
#ifndef NARGS
void               (*output_function)(void *, char *, ...);
#else
void               (*output_function)();
#endif /* #ifndef NARGS */
void                *output_control;
{
	unsigned int count_1;

#ifndef NARGS
	output_function = (output_function != NULL) ? output_function :
		((void (*)(void *, char *, ...)) fprintf);
#else
	output_function = (output_function != NULL) ? output_function : fprintf;
#endif /* #ifndef NARGS */
	output_control  = (output_control  != NULL) ? output_control  : stdout;

	for (count_1 = 0; count_1 < pattern_ptr->pattern_count; count_1++)
		ADF_EMIT_PatternString(pattern_ptr->pattern_list[count_1], pattern_name,
			((count_1 < (pattern_ptr->pattern_count - 1)) ||
			trailing_comma_flag) ? ADF_TRUE : ADF_FALSE, output_function,
			output_control);
}
/*	***********************************************************************	*/

/*	***********************************************************************	*/
void ADF_EMIT_PatternString(pattern_string, pattern_name, trailing_comma_flag,
	output_function, output_control)
const char  *pattern_string;
const char  *pattern_name;
int          trailing_comma_flag;
#ifndef NARGS
void       (*output_function)(void *, char *, ...);
#else
void       (*output_function)();
#endif /* #ifndef NARGS */
void        *output_control;
{
#ifndef NARGS
	output_function = (output_function != NULL) ? output_function :
		((void (*)(void *, char *, ...)) fprintf);
#else
	output_function = (output_function != NULL) ? output_function : fprintf;
#endif /* #ifndef NARGS */
	output_control  = (output_control  != NULL) ? output_control  : stdout;

	(*output_function)(output_control, "%s(\"%s\")%s\n", pattern_name,
		pattern_string, (trailing_comma_flag) ? "," : "");
}
/*	***********************************************************************	*/

