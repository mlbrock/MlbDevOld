/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	Automated Documentation Facility (ADF) Program Module							*/
/*	***********************************************************************	*/
/*
	File Name			:	%M%

	File Version		:	%I%

	Last Extracted		:	%D%	%T%

	Last Updated		:	%E%	%U%

	File Description	:	

	Revision History	:	1990-06-27 --- Creation.
									Michael L. Brock
*/
/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*		Necessary include files . . .														*/
/*	***********************************************************************	*/

#include <stdlib.h>
#include <string.h>

#include "adf.h"

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

#define ADF_PARSE_ROOT_DEF_COUNT			2

static const SPF_SPEC ADF_PARSE_RootDefList[ADF_PARSE_ROOT_DEF_COUNT] = {
	{
		"@include",
		{	"@include_file"	},
		SPF_TYPE_INCLUDE_FILE,
		0,		UINT_MAX,
		0,		UINT_MAX,
		0.0,	0.0,
		0,
		0,
		{	NULL,
			NULL
		}
	},
	{
		"@domain",
		{	""	},
		ADF_PARSE_TYPE_DOMAIN,
		0,		UINT_MAX,
		0,		0,
		0.0,	0.0,
		0,
		0,
		{
			ADF_PARSE_Any,
			NULL
		}
	}
};
/*	***********************************************************************	*/

/*	***********************************************************************	*/
int ADF_PARSE_Main(context_ptr, file_name, def_string, error_text)
SPF_CONTEXT *context_ptr;
const char  *file_name;
const char  *def_string;
char        *error_text;
{
	int            return_code;
	SPF_SPEC_FUNCS funcs_data;

	SPF_INIT_SpecFuncs(&funcs_data);

	funcs_data.parse      = ADF_PARSE_Any;
	funcs_data.post_parse = NULL;

	return_code = SPF_PARSE_File(context_ptr, file_name, def_string,
		&funcs_data, ADF_PARSE_ROOT_DEF_COUNT, ADF_PARSE_RootDefList,
		error_text);

	return(return_code);
}
/*	***********************************************************************	*/

#ifdef TEST_MAIN

#include <memory.h>
#include <stdlib.h>
#include <string.h>

#include <genfuncs.h>

#ifdef __MSDOS__
extern unsigned int _stklen = 32000;
#endif /* __MSDOS__ */

#ifndef NARGS
int main(int argc, char **argv);
#else
int main();
#endif /* #ifndef NARGS */

int main(argc, argv)
int    argc;
char **argv;
{
	int                return_code = ADF_SUCCESS;
	int                emit_flag   = ADF_FALSE;
	ADF_CONTROL        control_data;
	SPF_CONTEXT        context_data;
	unsigned int       count_1;
	GEN_TVAL_STAT      stat_data_1;
	GEN_TVAL_STAT      stat_data_2;
	GEN_TVAL_STAT      stat_data_3;
	GEN_TVAL_STAT      stat_data_4;
	char               time_buffer[512];
	char               error_text[ADF_MAX_ERROR_TEXT];

	fprintf(stderr,
		"Test routine for function 'ADF_PARSE_Main()'\n");
	fprintf(stderr,
		"---- ------- --- -------- ------------------\n");

	ADF_INIT_Control(&control_data);
	SPF_INIT_Context(&context_data);
	context_data.user_data_ptr       = &control_data;
	context_data.user_data_free_func = ((void *) ADF_FREE_Control);

	GEN_TVAL_STAT_Init(&stat_data_1);
	GEN_TVAL_STAT_Init(&stat_data_2);
	GEN_TVAL_STAT_Init(&stat_data_3);
	GEN_TVAL_STAT_Init(&stat_data_4);

	for (count_1 = 1; count_1 < argc; count_1++) {
		if (!stricmp(argv[count_1], "-EMIT=ON")) {
			emit_flag = ADF_TRUE;
			continue;
		}
		else if (!stricmp(argv[count_1], "-EMIT=OFF")) {
			emit_flag = ADF_FALSE;
			continue;
		}
		fprintf(stderr, "ADF Definition File: %s\n", argv[count_1]);
		STR_EMIT_CharLine('*', 78, NULL, NULL);
		STR_EMIT_CharLine('*', 78, NULL, NULL);
		printf("ADF Definition File: %s\n", argv[count_1]);
		STR_EMIT_CharLine('*', 78, NULL, NULL);
		GEN_TVAL_STAT_StartTime(&stat_data_1);
		if ((return_code = ADF_ReadDefinitionFile(&control_data, argv[count_1],
			error_text)) != ADF_SUCCESS)
			break;
		GEN_TVAL_STAT_EndTime(&stat_data_1, 1);
		GEN_TVAL_STAT_StartTime(&stat_data_2);
		GEN_TVAL_STAT_EndTime(&stat_data_2, 1);
		if (emit_flag == ADF_TRUE) {
			GEN_TVAL_STAT_StartTime(&stat_data_3);
			GEN_TVAL_STAT_EndTime(&stat_data_3, 1);
		}
		GEN_TVAL_STAT_StartTime(&stat_data_4);
		ADF_FREE_Control(&control_data);
		GEN_TVAL_STAT_EndTime(&stat_data_4, 1);
		STR_EMIT_CharLine('*', 78, NULL, NULL);
	}

	if (return_code == ADF_SUCCESS) {
		fprintf(stderr, "Create Time: %s\n",
			GEN_FormatInterval_timeval(&stat_data_1.total_interval, time_buffer));
		fprintf(stderr, "Check Time : %s\n",
			GEN_FormatInterval_timeval(&stat_data_2.total_interval, time_buffer));
		fprintf(stderr, "Emit Time  : %s\n",
			GEN_FormatInterval_timeval(&stat_data_3.total_interval, time_buffer));
		fprintf(stderr, "Free Time  : %s\n",
			GEN_FormatInterval_timeval(&stat_data_4.total_interval, time_buffer));
	}
	else
		fprintf(stderr, "ERROR: %s\n", error_text);

/*
	CODE NOTE: To be removed.
	ADF_FREE_Control(&control_data);
*/
	SPF_FREE_Context(&context_data);

	return(return_code);
}

#endif /* #ifdef TEST_MAIN */

