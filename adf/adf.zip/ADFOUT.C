/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	Automated Documentation Facility (ADF) Program Module							*/
/*	***********************************************************************	*/
/*
	File Name			:	%M%

	File Version		:	%I%

	Last Extracted		:	%D%	%T%

	Last Updated		:	%E%	%U%

	File Description	:	Run-time logic for the executable 'adfout'.

	Revision History	:	1995-07-27 --- Creation.
									Michael L. Brock
*/
/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*		Necessary include files . . .														*/
/*	***********************************************************************	*/

#include <locale.h>
#include <memory.h>
#include <stdlib.h>
#include <string.h>

#include <genfuncs.h>

#include "adf.h"

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

#define ADF_RUN_OUT_VERSION_NUMBER		"01.00.00A"

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

static const ADF_RUN_USAGE ADF_RUN_OUT_UsageFuncList[] = {
	{	ADF_TRUE,	ADF_BUSE_Help,						NULL	},
	{	ADF_TRUE,	ADF_BUSE_Version,					NULL	},
	{	ADF_TRUE,	ADF_BUSE_CheckOnlyFlag,			NULL	},
	{	ADF_TRUE,	ADF_BUSE_LogFlag,					NULL	},
	{	ADF_TRUE,	ADF_BUSE_LogDir,					NULL	},
	{	ADF_TRUE,	ADF_BUSE_DuplicateType,			NULL	},
	{	ADF_TRUE,	ADF_BUSE_QuietFlag,				NULL	},
	{	ADF_TRUE,	ADF_BUSE_SortOrderType,			NULL	},
	{	ADF_TRUE,	ADF_OUSE_HyperTextFlag,			NULL	},
	{	ADF_TRUE,	ADF_BUSE_ContOnErrorFlag,		NULL	},
	{	ADF_TRUE,	ADF_OUSE_OutputDir,				NULL	},
	{	ADF_TRUE,	ADF_OUSE_OutputType,				NULL	},
	{	ADF_TRUE,	ADF_OUSE_OutputByFileFlag,		NULL	},
	{	ADF_TRUE,	ADF_OUSE_OutputToStdoutFlag,	NULL	},
	{	ADF_TRUE,	ADF_OUSE_GenerateType,			NULL	},
	{	ADF_TRUE,	ADF_BUSE_CludeEntry,				NULL	},
	{	ADF_TRUE,	ADF_BUSE_CludeHText,				NULL	},
	{	ADF_TRUE,	ADF_OUSE_AreaNameType,			NULL	},
	{	ADF_TRUE,	ADF_OUSE_AreaOrderType,			NULL	},
	{	ADF_TRUE,	ADF_OUSE_AreaName,				NULL	},
	{	ADF_TRUE,	ADF_BUSE_IgnoreSection,			NULL	},
	{	ADF_TRUE,	ADF_OUSE_KeepBadSeeAlso,		NULL	},
	{	ADF_TRUE,	ADF_OUSE_ExternalHTextRef,		NULL	},
	{	ADF_TRUE,	ADF_OUSE_ParseOutParam,			NULL	}
};

static const unsigned int  ADF_RUN_OUT_UsageFuncCount  =
	sizeof(ADF_RUN_OUT_UsageFuncList) / sizeof(ADF_RUN_OUT_UsageFuncList[0]);

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

#ifdef __MSDOS__
extern unsigned int _stklen = 32000;
#endif /* __MSDOS__ */

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

#ifndef NARGS
int main(int argc, char **argv);
#else
int main();
#endif /* #ifndef NARGS */

#ifndef NARGS
static int  ADF_RUN_OUT_DoByEntry(ADF_CONTROL *control_ptr,	char *error_text);
static int  ADF_RUN_OUT_DoToStdout(ADF_CONTROL *control_ptr, char *error_text);
static int  ADF_RUN_OUT_DoByFile(ADF_CONTROL *control_ptr, char *error_text);
static int  ADF_RUN_OUT_DoTOC(ADF_CONTROL *control_ptr, char *error_text);
static int  ADF_RUN_OUT_DoClassTOC(ADF_CONTROL *control_ptr,
	char *error_text);
static int  ADF_RUN_OUT_DoTOF(ADF_CONTROL *control_ptr, char *error_text);
static int  ADF_RUN_OUT_DoIndex(ADF_CONTROL *control_ptr, char *error_text);
static int  ADF_RUN_OUT_DoPermIndex(ADF_CONTROL *control_ptr, char *error_text);
static int  ADF_RUN_OUT_GetParams(ADF_CONTROL *control_ptr, unsigned int argc,
	char **argv, char *error_text);
static int  ADF_RUN_OUT_CreateUsageList(ADF_CONTROL *control_ptr,
	unsigned int *usage_count, char ***usage_list, char *error_text);
static int  ADF_RUN_OUT_FixOutputDir(ADF_CONTROL *control_ptr,
	char *error_text);
static void ADF_RUN_OUT_ShowSettings(const ADF_CONTROL *control_ptr);
static int  ADF_RUN_OUT_CheckParams(ADF_CONTROL *control_ptr,
	char *error_text);
static int  ADF_RUN_OUT_Parse(ADF_CONTROL *control_ptr, unsigned int argc,
	char **argv, int init_flag, unsigned int current_arg, char *error_text);
static void ADF_RUN_OUT_End(ADF_CONTROL *control_ptr, int signal_number,
	int *exit_code_ptr, const char *message_buffer);
#else
static int  ADF_RUN_OUT_DoByEntry();
static int  ADF_RUN_OUT_DoToStdout();
static int  ADF_RUN_OUT_DoByFile();
static int  ADF_RUN_OUT_DoTOC();
static int  ADF_RUN_OUT_DoClassTOC();
static int  ADF_RUN_OUT_DoTOF();
static int  ADF_RUN_OUT_DoIndex();
static int  ADF_RUN_OUT_DoPermIndex();
static int  ADF_RUN_OUT_GetParams();
static int  ADF_RUN_OUT_CreateUsageList();
static int  ADF_RUN_OUT_FixOutputDir();
static void ADF_RUN_OUT_ShowSettings();
static int  ADF_RUN_OUT_CheckParams();
static int  ADF_RUN_OUT_Parse();
static void ADF_RUN_OUT_End();
#endif /* #ifndef NARGS */

/*	***********************************************************************	*/

/*	***********************************************************************	*/
int main(argc, argv)
int    argc;
char **argv;
{
	int         return_code;
	ADF_CONTROL control_data;
	char        error_text[ADF_MAX_ERROR_TEXT];

	memset(&control_data, '\0', sizeof(control_data));

	if ((return_code = ADF_RUN_OUT_GetParams(&control_data,
		((unsigned int) argc), argv, error_text)) == ADF_SUCCESS) {
		if ((return_code = ADF_LoadInFileList(&control_data, error_text)) ==
			ADF_SUCCESS) {
			if ((return_code = ADF_LoadHTextRefFileList(&control_data,
				error_text)) == ADF_SUCCESS) {
				if (control_data.check_only_flag != ADF_TRUE) {
					if ((return_code = ADF_RUN_OUT_FixOutputDir(&control_data,
						error_text)) == ADF_SUCCESS) {
						if ((return_code = ADF_FinalizeEntries(&control_data,
							error_text)) == ADF_SUCCESS) {
							if (control_data.generate_type == ADF_GENERATE_TYPE_TOC)
								return_code = ADF_RUN_OUT_DoTOC(&control_data,
									error_text);
							else if (control_data.generate_type ==
								ADF_GENERATE_TYPE_CLASS_TOC)
								return_code = ADF_RUN_OUT_DoClassTOC(&control_data,
									error_text);
							else if (control_data.generate_type ==
								ADF_GENERATE_TYPE_TOF)
								return_code = ADF_RUN_OUT_DoTOF(&control_data,
									error_text);
							else if (control_data.generate_type ==
								ADF_GENERATE_TYPE_INDEX)
								return_code = ADF_RUN_OUT_DoIndex(&control_data,
									error_text);
							else if (control_data.generate_type ==
								ADF_GENERATE_TYPE_PERM_INDEX)
								return_code = ADF_RUN_OUT_DoPermIndex(&control_data,
									error_text);
							else if (control_data.output_by_file_flag == ADF_TRUE)
								return_code = ADF_RUN_OUT_DoByFile(&control_data,
									error_text);
							else if (control_data.output_to_stdout_flag == ADF_TRUE)
								return_code = ADF_RUN_OUT_DoToStdout(&control_data,
									error_text);
							else
								return_code = ADF_RUN_OUT_DoByEntry(&control_data,
									error_text);
						}
					}
				}
			}
		}
		if ((return_code != ADF_SUCCESS) &&
			(control_data.log_flag == ADF_TRUE))
			ADF_LogMessage(NULL, LOG_ERR, control_data.log_file_ptr, stderr,
				ADF_FALSE, "%s\n", error_text);
		ADF_RUN_OUT_End(&control_data, 0, NULL, NULL);
		GEN_SIGNAL_SignalDefault();
	}

	if (return_code != ADF_SUCCESS)
		fprintf(stderr, "\n\nERROR: %s\n\n%s", error_text,
			(return_code != ADF_BAD_ARGS_FAILURE) ? "" :
			"       Help is available with the '-HELP' parameter.\n\n");

	return(return_code);
}
/*	***********************************************************************	*/

/*	***********************************************************************	*/
static int ADF_RUN_OUT_DoByEntry(control_ptr, error_text)
ADF_CONTROL *control_ptr;
char        *error_text;
{
	int           return_code = ADF_SUCCESS;
	unsigned int  count_1;
	char          output_type_string[ADF_OUTPUT_TYPE_NAME_LENGTH + 1];
#ifndef NARGS
	int          (*init_function)(ADF_CONTROL *, char *);
	int          (*by_entry_function)(ADF_CONTROL *, const ADF_ENTRY *, char *);
#else
	int          (*init_function)();
	int          (*by_entry_function)();
#endif /* #ifndef NARGS */

	if ((return_code = ADF_GetOutputFunctions(control_ptr->output_type,
		&init_function, &by_entry_function, NULL, NULL, NULL, NULL, NULL, NULL,
		NULL, NULL, NULL, NULL, error_text)) != ADF_SUCCESS)
		goto EXIT_FUNCTION;
	else if (by_entry_function == NULL) {
		sprintf(error_text, "The %s output type may not be emitted 'by-entry'.",
			ADF_GetOutputTypeString(control_ptr->output_type,
			output_type_string));
		return_code = ADF_FAILURE;
		goto EXIT_FUNCTION;
	}
	else if ((init_function != NULL) &&
		((return_code = (*init_function)(control_ptr, error_text)) !=
		ADF_SUCCESS))
		goto EXIT_FUNCTION;

	for (count_1 = 0; count_1 < control_ptr->in_entry_order_count; count_1++) {
		if ((return_code = (*by_entry_function)(control_ptr,
			control_ptr->in_entry_order_list[count_1], error_text)) !=
			ADF_SUCCESS)
			break;
	}

EXIT_FUNCTION:

	return(return_code);
}
/*	***********************************************************************	*/

/*	***********************************************************************	*/
static int ADF_RUN_OUT_DoToStdout(control_ptr, error_text)
ADF_CONTROL *control_ptr;
char        *error_text;
{
	int            return_code = ADF_SUCCESS;
	unsigned int   count_1;
	time_t         output_date;
	char           output_type_string[ADF_OUTPUT_TYPE_NAME_LENGTH + 1];
#ifndef NARGS
	int          (*init_function)(ADF_CONTROL *, char *);
	int          (*to_stdout_function)(ADF_CONTROL *, const ADF_ENTRY *,
						const time_t *, char *);
	void         (*output_start_function)(ADF_CONTROL *contrl_ptr,
		const char *output_name, const time_t *output_date_ptr,
		void (*output_function)(void *, char *, ...), void *output_control);
	void         (*output_end_function)(ADF_CONTROL *contrl_ptr,
		void (*output_function)(void *, char *, ...), void *output_control);
	void         (*output_between_function)(ADF_CONTROL *contrl_ptr,
		const ADF_ENTRY *entry_ptr, const char *output_name,
		void (*output_function)(void *, char *, ...), void *output_control);
#else
	int          (*init_function)();
	int          (*to_stdout_function)();
	void         (*output_start_function);
	void         (*output_end_function);
	void         (*output_between_function);
#endif /* #ifndef NARGS */

	if ((return_code = ADF_GetOutputFunctions(control_ptr->output_type,
		&init_function, NULL, &to_stdout_function, NULL, NULL, NULL, NULL, NULL,
		NULL, &output_start_function, &output_end_function,
		&output_between_function, error_text)) != ADF_SUCCESS)
		goto EXIT_FUNCTION;
	else if (to_stdout_function == NULL) {
		sprintf(error_text,
			"The %s output type may not be emitted to <stdout>.",
			ADF_GetOutputTypeString(control_ptr->output_type,
			output_type_string));
		return_code = ADF_FAILURE;
		goto EXIT_FUNCTION;
	}
	else if ((init_function != NULL) &&
		((return_code = (*init_function)(control_ptr, error_text)) !=
		ADF_SUCCESS))
		goto EXIT_FUNCTION;

	output_date = time(NULL);

	if (output_start_function != NULL)
#ifndef NARGS
		(*output_start_function)(control_ptr, "Output to <stdout>",
			&output_date, ((void (*)(void *, char *, ...)) fprintf), stdout);
#else
		(*output_start_function)(control_ptr, "Output to <stdout>",
			&output_date, fprintf, stdout);
#endif /* #ifndef NARGS */

	for (count_1 = 0; count_1 < control_ptr->in_entry_order_count; count_1++) {
		if (count_1 && (output_between_function != NULL))
#ifndef NARGS
			(*output_between_function)(control_ptr,
				control_ptr->in_entry_order_list[count_1], "Output to <stdout>",
				((void (*)(void *, char *, ...)) fprintf), stdout);
#else
			(*output_between_function)(control_ptr,
				control_ptr->in_entry_order_list[count_1], "Output to <stdout>",
				fprintf, stdout);
#endif /* #ifndef NARGS */
		if ((return_code = (*to_stdout_function)(control_ptr,
			control_ptr->in_entry_order_list[count_1], &output_date,
			error_text)) != ADF_SUCCESS)
			break;
	}

	if (output_end_function != NULL)
#ifndef NARGS
		(*output_end_function)(control_ptr,
			((void (*)(void *, char *, ...)) fprintf), stdout);
#else
		(*output_end_function)(control_ptr, fprintf, stdout);
#endif /* #ifndef NARGS */

EXIT_FUNCTION:

	return(return_code);
}
/*	***********************************************************************	*/

/*	***********************************************************************	*/
static int ADF_RUN_OUT_DoByFile(control_ptr, error_text)
ADF_CONTROL *control_ptr;
char        *error_text;
{
	int           return_code = ADF_SUCCESS;
	unsigned int  count_1;
	char          output_type_string[ADF_OUTPUT_TYPE_NAME_LENGTH + 1];
#ifndef NARGS
	int          (*init_function)(ADF_CONTROL *, char *);
	int          (*by_file_function)(ADF_CONTROL *, unsigned int *, char *);
#else
	int          (*init_function)();
	int          (*by_file_function)();
#endif /* #ifndef NARGS */

	if ((return_code = ADF_GetOutputFunctions(control_ptr->output_type,
		&init_function, NULL, NULL, &by_file_function, NULL, NULL, NULL, NULL,
		NULL, NULL, NULL, NULL, error_text)) != ADF_SUCCESS)
		goto EXIT_FUNCTION;
	else if (by_file_function == NULL) {
		sprintf(error_text, "The %s output type may not be emitted 'by-file'.",
			ADF_GetOutputTypeString(control_ptr->output_type,
			output_type_string));
		return_code = ADF_FAILURE;
		goto EXIT_FUNCTION;
	}
	else if ((init_function != NULL) &&
		((return_code = (*init_function)(control_ptr, error_text)) !=
		ADF_SUCCESS))
		goto EXIT_FUNCTION;

	for (count_1 = 0; count_1 < control_ptr->in_entry_order_count; ) {
		if ((return_code = (*by_file_function)(control_ptr, &count_1,
			error_text)) != ADF_SUCCESS)
			break;
	}

EXIT_FUNCTION:

	return(return_code);
}
/*	***********************************************************************	*/

/*	***********************************************************************	*/
static int ADF_RUN_OUT_DoTOC(control_ptr, error_text)
ADF_CONTROL *control_ptr;
char        *error_text;
{
	int    return_code = ADF_SUCCESS;
	char   output_type_string[ADF_OUTPUT_TYPE_NAME_LENGTH + 1];
#ifndef NARGS
	int  (*init_function)(ADF_CONTROL *, char *);
	int  (*toc_function)(ADF_CONTROL *, char *);
#else
	int  (*init_function)();
	int  (*toc_function)();
#endif /* #ifndef NARGS */

	if ((return_code = ADF_GetOutputFunctions(control_ptr->output_type,
		&init_function, NULL, NULL, NULL, &toc_function, NULL, NULL, NULL,
		NULL, NULL, NULL, NULL, error_text)) == ADF_SUCCESS) {
		if (toc_function == NULL) {
			sprintf(error_text, "The %s output type does not support %s.",
				ADF_GetOutputTypeString(control_ptr->output_type,
				output_type_string), "table-of-contents generation");
			return_code = ADF_FAILURE;
		}
		else if ((init_function == NULL) || ((init_function != NULL) &&
			((return_code = (*init_function)(control_ptr, error_text)) ==
			ADF_SUCCESS)))
			return_code = (*toc_function)(control_ptr, error_text);
	}

	return(return_code);
}
/*	***********************************************************************	*/

/*	***********************************************************************	*/
static int ADF_RUN_OUT_DoClassTOC(control_ptr, error_text)
ADF_CONTROL *control_ptr;
char        *error_text;
{
	int    return_code = ADF_SUCCESS;
	char   output_type_string[ADF_OUTPUT_TYPE_NAME_LENGTH + 1];
#ifndef NARGS
	int  (*init_function)(ADF_CONTROL *, char *);
	int  (*class_toc_function)(ADF_CONTROL *, char *);
#else
	int  (*init_function)();
	int  (*class_toc_function)();
#endif /* #ifndef NARGS */

	if ((return_code = ADF_GetOutputFunctions(control_ptr->output_type,
		&init_function, NULL, NULL, NULL, NULL, &class_toc_function, NULL,
		NULL, NULL, NULL, NULL, NULL, error_text)) == ADF_SUCCESS) {
		if (class_toc_function == NULL) {
			sprintf(error_text, "The %s output type does not support %s.",
				ADF_GetOutputTypeString(control_ptr->output_type,
				output_type_string), "entry class table-of-contents generation");
			return_code = ADF_FAILURE;
		}
		else if ((init_function == NULL) || ((init_function != NULL) &&
			((return_code = (*init_function)(control_ptr, error_text)) ==
			ADF_SUCCESS)))
			return_code = (*class_toc_function)(control_ptr, error_text);
	}

	return(return_code);
}
/*	***********************************************************************	*/

/*	***********************************************************************	*/
static int ADF_RUN_OUT_DoTOF(control_ptr, error_text)
ADF_CONTROL *control_ptr;
char        *error_text;
{
	int    return_code = ADF_SUCCESS;
	char   output_type_string[ADF_OUTPUT_TYPE_NAME_LENGTH + 1];
#ifndef NARGS
	int  (*init_function)(ADF_CONTROL *, char *);
	int  (*tof_function)(ADF_CONTROL *, char *);
#else
	int  (*init_function)();
	int  (*tof_function)();
#endif /* #ifndef NARGS */

	if ((return_code = ADF_GetOutputFunctions(control_ptr->output_type,
		&init_function, NULL, NULL, NULL, NULL, NULL, &tof_function, NULL, NULL,
		NULL, NULL, NULL, error_text)) == ADF_SUCCESS) {
		if (tof_function == NULL) {
			sprintf(error_text, "The %s output type does not support %s.",
				ADF_GetOutputTypeString(control_ptr->output_type,
				output_type_string), "table-of-files generation");
			return_code = ADF_FAILURE;
		}
		else if ((init_function == NULL) || ((init_function != NULL) &&
			((return_code = (*init_function)(control_ptr, error_text)) ==
			ADF_SUCCESS)))
			return_code = (*tof_function)(control_ptr, error_text);
	}

	return(return_code);
}
/*	***********************************************************************	*/

/*	***********************************************************************	*/
static int ADF_RUN_OUT_DoIndex(control_ptr, error_text)
ADF_CONTROL *control_ptr;
char        *error_text;
{
	int    return_code = ADF_SUCCESS;
	char   output_type_string[ADF_OUTPUT_TYPE_NAME_LENGTH + 1];
#ifndef NARGS
	int  (*init_function)(ADF_CONTROL *, char *);
	int  (*index_function)(ADF_CONTROL *, char *);
#else
	int  (*init_function)();
	int  (*index_function)();
#endif /* #ifndef NARGS */

	if ((return_code = ADF_GetOutputFunctions(control_ptr->output_type,
		&init_function, NULL, NULL, NULL, NULL, NULL, NULL, &index_function,
		NULL, NULL, NULL, NULL, error_text)) == ADF_SUCCESS) {
		if (index_function == NULL) {
			sprintf(error_text, "The %s output type does not support %s.",
				ADF_GetOutputTypeString(control_ptr->output_type,
				output_type_string), "index generation");
			return_code = ADF_FAILURE;
		}
		else if ((init_function == NULL) || ((init_function != NULL) &&
			((return_code = (*init_function)(control_ptr, error_text)) ==
			ADF_SUCCESS)))
			return_code = (*index_function)(control_ptr, error_text);
	}

	return(return_code);
}
/*	***********************************************************************	*/

/*	***********************************************************************	*/
static int ADF_RUN_OUT_DoPermIndex(control_ptr, error_text)
ADF_CONTROL *control_ptr;
char        *error_text;
{
	int    return_code = ADF_SUCCESS;
	char   output_type_string[ADF_OUTPUT_TYPE_NAME_LENGTH + 1];
#ifndef NARGS
	int  (*init_function)(ADF_CONTROL *, char *);
	int  (*perm_index_function)(ADF_CONTROL *, char *);
#else
	int  (*init_function)();
	int  (*perm_index_function)();
#endif /* #ifndef NARGS */

	if ((return_code = ADF_GetOutputFunctions(control_ptr->output_type,
		&init_function, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
		&perm_index_function, NULL, NULL, NULL, error_text)) == ADF_SUCCESS) {
		if (perm_index_function == NULL) {
			sprintf(error_text, "The %s output type does not support %s.",
				ADF_GetOutputTypeString(control_ptr->output_type,
				output_type_string), "permutated index generation");
			return_code = ADF_FAILURE;
		}
		else if ((init_function == NULL) || ((init_function != NULL) &&
			((return_code = (*init_function)(control_ptr, error_text)) ==
			ADF_SUCCESS)))
			return_code = (*perm_index_function)(control_ptr, error_text);
	}

	return(return_code);
}
/*	***********************************************************************	*/

/*	***********************************************************************	*/
static int ADF_RUN_OUT_GetParams(control_ptr, argc, argv, error_text)
ADF_CONTROL   *control_ptr;
unsigned int   argc;
char         **argv;
char          *error_text;
{
	int            return_code;
	unsigned int   usage_count = 0;
	char         **usage_list  = NULL;
	char          *prog;

	ADF_INIT_Control(control_ptr);

#ifndef NARGS
	GEN_SIGNAL_SignalInit(&control_ptr->signal_received_flag,
		&control_ptr->queue_signal_flag, control_ptr,
		&control_ptr->log_file_ptr,
		((int (*)(const void *, size_t, size_t, void *)) ADF_fwrite),
		((void (*)(void *, int, int *, const char *)) ADF_RUN_OUT_End));
#else
	GEN_SIGNAL_SignalInit(&control_ptr->signal_received_flag,
		&control_ptr->queue_signal_flag, control_ptr,
		&control_ptr->log_file_ptr, ADF_fwrite, ADF_RUN_OUT_End);
#endif /* #ifndef NARGS */
	GEN_SIGNAL_SignalSet();

	gettimeofday(&control_ptr->start_time, ((struct timezone *) NULL));

	control_ptr->overhead_end_time = control_ptr->start_time;

	control_ptr->process_id        = getpid();

	if (setlocale(LC_ALL, "C") == NULL) {
		strcpy(error_text, "Attempt to 'setlocale(LC_ALL, \"C\")' failed.");
		return_code = ADF_FAILURE;
		goto EXIT_FUNCTION;
	}

/*
	if ((return_code = SPS_GEN_SetResourceLimitsToMax(error_text)) !=
		ADF_SUCCESS)
		goto EXIT_FUNCTION;
*/

	if ((control_ptr->program_name = strdup(argv[0])) == NULL) {
		sprintf(error_text,
			"Unable to allocate memory for the program name.");
		return_code = ADF_MEMORY_FAILURE;
		goto EXIT_FUNCTION;
	}

	if (gethostname(control_ptr->host_name,
		sizeof(control_ptr->host_name) - 1)) {
		strcpy(error_text, "Unable to determine the current host-name: ");
		ADF_GetLastErrorString(error_text);
		return_code = ADF_SYSTEM_FAILURE;
		goto EXIT_FUNCTION;
	}

	if (getwd(control_ptr->current_dir) == NULL) {
		strcpy(error_text, "Unable to determine the current directory: ");
		ADF_GetLastErrorString(error_text);
		return_code = ADF_SYSTEM_FAILURE;
		goto EXIT_FUNCTION;
	}

	prog = control_ptr->program_name;
	/* For Unix */
	prog = (strrchr(prog, '/')  != NULL) ? (strrchr(prog, '/')  + 1) : prog;
	/* For VMS */
	prog = (strrchr(prog, ']')  != NULL) ? (strrchr(prog, ']')  + 1) : prog;
	/* For MS-DOS */
	prog = (strrchr(prog, ':')  != NULL) ? (strrchr(prog, ':')  + 1) : prog;
	/* For MS-DOS */
	prog = (strrchr(prog, '\\') != NULL) ? (strrchr(prog, '\\') + 1) : prog;

	if ((control_ptr->short_program_name = strdup(prog)) == NULL) {
		sprintf(error_text, "%s (%u bytes required).",
			"Unable to allocate memory for the short program name",
			strlen(argv[0]) + 1);
		return_code = ADF_MEMORY_FAILURE;
		goto EXIT_FUNCTION;
	}

	if ((return_code = ADF_RUN_OUT_CreateUsageList(control_ptr,
		&usage_count, &usage_list, error_text)) != ADF_SUCCESS)
		goto EXIT_FUNCTION;

#ifndef NARGS
	if ((return_code = ADF_GetParams(control_ptr,
		((unsigned int) argc), argv, &control_ptr->help_flag,
		&control_ptr->version_flag,
		((int (*)(void *, unsigned int, char **, int, unsigned int, char *))
		ADF_RUN_OUT_Parse), error_text)) == ADF_SUCCESS) {
#else
	else if ((return_code = ADF_GetParams(control_ptr,
		((unsigned int) argc), argv, &control_ptr->help_flag,
		&control_ptr->version_flag, ADF_RUN_OUT_Parse, error_text)) ==
		ADF_SUCCESS) {
#endif /* #ifndef NARGS */
		if (control_ptr->help_flag == ADF_TRUE) {
			ADF_FREE_Control(control_ptr);
			GEN_SIGNAL_SignalDefault();
			ADF_DoFormatUsage(return_code, argv[0],
				"Help request with '-HELP' noted . . .", usage_list);
		}
		else if (control_ptr->version_flag == ADF_TRUE) {
			ADF_FREE_Control(control_ptr);
			GEN_SIGNAL_SignalDefault();
			fprintf(stderr, "%s Version Number %s\n", argv[0],
				ADF_RUN_OUT_VERSION_NUMBER);
			exit(0);
		}
		else if ((return_code = ADF_RUN_OUT_CheckParams(control_ptr,
			error_text)) == ADF_SUCCESS) {
			if (control_ptr->log_flag == ADF_TRUE) {
				if (control_ptr->quiet_flag == ADF_TRUE)
					ADF_SetLogMessageFlagFILE(ADF_FALSE);
				if ((return_code = ADF_RUN_OpenLogFile(control_ptr,
					error_text)) == ADF_SUCCESS)
					ADF_RUN_OUT_ShowSettings(control_ptr);
			}
		}
		if (return_code != ADF_SUCCESS)
			ADF_RUN_OUT_End(control_ptr, 0, NULL, NULL);
	}

EXIT_FUNCTION:

	gettimeofday(&control_ptr->overhead_end_time,
		((struct timezone *) NULL));

	strl_remove_all(&usage_count, &usage_list);

	if (return_code != ADF_SUCCESS)
		ADF_FREE_Control(control_ptr);

	return(return_code);
}
/*	***********************************************************************	*/

/*	***********************************************************************	*/
static int ADF_RUN_OUT_CreateUsageList(control_ptr, usage_count, usage_list,
	error_text)
ADF_CONTROL    *control_ptr;
unsigned int   *usage_count;
char         ***usage_list;
char           *error_text;
{
	int          return_code = ADF_MEMORY_FAILURE;
	unsigned int count_1;
	char         buffer[4096];

	*usage_count = 0;
	*usage_list  = NULL;

	*error_text  = '\0';

	sprintf(buffer, "\t%s [<a mixture of '-' parameters, and '@' commands>]",
		control_ptr->short_program_name);
	if (strl_append(usage_count, usage_list, "Usage:") != STRFUNCS_SUCCESS)
		goto EXIT_FUNCTION;
	else if (strl_append(usage_count, usage_list, "------") !=
		STRFUNCS_SUCCESS)
		goto EXIT_FUNCTION;
	else if (strl_append(usage_count, usage_list, buffer) != STRFUNCS_SUCCESS)
		goto EXIT_FUNCTION;
	else if (strl_append(usage_count, usage_list, "\n") != STRFUNCS_SUCCESS)
		goto EXIT_FUNCTION;
	else if (strl_append(usage_count, usage_list, "Description:") !=
		STRFUNCS_SUCCESS)
		goto EXIT_FUNCTION;
	else if (strl_append(usage_count, usage_list, "------------") !=
		STRFUNCS_SUCCESS)
		goto EXIT_FUNCTION;

	sprintf(buffer, "\tThis is version %s of %s.", ADF_RUN_OUT_VERSION_NUMBER,
		control_ptr->short_program_name);
	if (strl_append(usage_count, usage_list, buffer) != STRFUNCS_SUCCESS)
		goto EXIT_FUNCTION;
	else if (strl_append(usage_count, usage_list, "\n") != STRFUNCS_SUCCESS)
		goto EXIT_FUNCTION;

	if (strl_append(usage_count, usage_list, "Parameters:") !=
		STRFUNCS_SUCCESS)
		goto EXIT_FUNCTION;
	else if (strl_append(usage_count, usage_list, "-----------") !=
		STRFUNCS_SUCCESS)
		goto EXIT_FUNCTION;

	for (count_1 = 0; count_1 < ADF_RUN_OUT_UsageFuncCount; count_1++) {
		if (((return_code =
			(*ADF_RUN_OUT_UsageFuncList[count_1].usage_function)(NULL,
			ADF_RUN_OUT_UsageFuncList[count_1].optional_flag, NULL, usage_count,
			usage_list, error_text)) != ADF_SUCCESS) ||
			((ADF_RUN_OUT_UsageFuncList[count_1].added_text != NULL) &&
			((return_code = ADF_BUSE_AppendLine(
			ADF_RUN_OUT_UsageFuncList[count_1].added_text, usage_count,
			usage_list, error_text)) != ADF_SUCCESS)))
			goto EXIT_FUNCTION;
	}

	if ((return_code = ADF_BUSE_AppendParamText(usage_count, usage_list,
		error_text)) != ADF_SUCCESS)
		goto EXIT_FUNCTION;

	return_code = ADF_BUSE_AppendNULL(usage_count, usage_list, error_text);

EXIT_FUNCTION:

	if (return_code != ADF_SUCCESS) {
		strl_remove_all(usage_count, usage_list);
		if (!(*error_text))
			strcpy(error_text, "Unable to allocate memory for the usage text.");
	}

	return(return_code);
}
/*	***********************************************************************	*/

/*	***********************************************************************	*/
static int ADF_RUN_OUT_FixOutputDir(control_ptr, error_text)
ADF_CONTROL *control_ptr;
char        *error_text;
{
	int           return_code = ADF_SUCCESS;
	unsigned int  length;
	char         *tmp_ptr;

#ifdef __MSDOS__
	if ((control_ptr->output_dir != NULL) && *control_ptr->output_dir &&
		(*control_ptr->output_dir != '/') &&
		(*control_ptr->output_dir != '\\') &&
		(control_ptr->output_dir[1] != ':')) {
#else
	if ((control_ptr->output_dir != NULL) && *control_ptr->output_dir &&
		(*control_ptr->output_dir != '/')) {
#endif /* #ifdef __MSDOS__ */
		if ((tmp_ptr = calloc(length = (strlen(control_ptr->current_dir) + 1 +
			strlen(control_ptr->output_dir) + 1), sizeof(char))) == NULL) {
			GEN_AllocMsgItem(length, error_text,
				"Unable to expand the output directory string");
			return_code = ADF_MEMORY_FAILURE;
		}
		else {
			strcat(strcat(strcpy(tmp_ptr, control_ptr->current_dir), "/"),
				control_ptr->output_dir);
			free(control_ptr->output_dir);
			control_ptr->output_dir = tmp_ptr;
		}
	}

	return(return_code);
}
/*	***********************************************************************	*/

/*	***********************************************************************	*/
static void ADF_RUN_OUT_ShowSettings(control_ptr)
const ADF_CONTROL *control_ptr;
{
	unsigned int count_1;
	char         buffer[100];

	ADF_LogSeparatorStartLog(control_ptr->log_file_ptr, stderr);

	ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
		ADF_FALSE, "Program Name       : %s\n", control_ptr->program_name);
	ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
		ADF_FALSE, "Version Number     : %s\n", ADF_RUN_OUT_VERSION_NUMBER);
	ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
		ADF_FALSE, "Host Name          : %s\n", control_ptr->host_name);
	ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
		ADF_FALSE, "Process ID         : %u\n", control_ptr->process_id);
	ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
		ADF_FALSE, "Current Directory  : %s\n", control_ptr->current_dir);
	ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
		ADF_FALSE, "Log File Name      : %s\n", control_ptr->log_file_name);

	ADF_LogSeparatorEqualChar(control_ptr->log_file_ptr, stderr);
}
/*	***********************************************************************	*/

/*	***********************************************************************	*/
static int ADF_RUN_OUT_CheckParams(control_ptr, error_text)
ADF_CONTROL *control_ptr;
char        *error_text;
{
	int return_code = ADF_BAD_ARGS_FAILURE;

	if ((control_ptr->output_by_file_flag == ADF_TRUE) &&
		(control_ptr->output_to_stdout_flag == ADF_TRUE))
		sprintf(error_text,
			"Parameter conflict detected --- both the %s and the %s are 'TRUE'.",
			"'-OUTPUT_BY_FILE=' parameter", "'-OUTPUT_TO_STDOUT=' parameter");
	else if (!control_ptr->in_file_name_count)
		strcpy(error_text,
			"No ADF database files were specified on the command line.");
	else
		return_code = ADF_SUCCESS;
		
	return(return_code);
}
/*	***********************************************************************	*/

/*	***********************************************************************	*/
static int ADF_RUN_OUT_Parse(control_ptr, argc, argv, init_flag, current_arg,
	error_text)
ADF_CONTROL   *control_ptr;
unsigned int   argc;
char         **argv;
int            init_flag;
unsigned int   current_arg;
char          *error_text;
{
	int           return_code = ADF_SUCCESS;
	char         *this_arg;
	char         *data_ptr;
	unsigned int  arg_length;
	char         *tmp_string;

	if (init_flag != ADF_TRUE) {
		this_arg = argv[current_arg];
		if (ADF_BARG_CheckOnlyFlag(this_arg, &arg_length, &data_ptr,
			&control_ptr->check_only_flag, &return_code, error_text) == ADF_TRUE)
			;
		else if (ADF_BARG_DuplicateType(this_arg, &arg_length, &data_ptr,
			&control_ptr->duplicate_handling_type, &return_code, error_text) ==
			ADF_TRUE)
			;
		else if (ADF_BARG_LogFlag(this_arg, &arg_length, &data_ptr,
			&control_ptr->log_flag, &return_code, error_text) == ADF_TRUE)
			;
		else if (ADF_BARG_LogDir(this_arg, &arg_length, &data_ptr,
			&control_ptr->log_dir, &return_code, error_text) == ADF_TRUE)
			;
		else if (ADF_BARG_QuietFlag(this_arg, &arg_length, &data_ptr,
			&control_ptr->quiet_flag, &return_code, error_text) == ADF_TRUE)
			;
		else if (ADF_BARG_SortOrderType(this_arg, &arg_length, &data_ptr,
			&control_ptr->sort_order_type, &return_code, error_text) == ADF_TRUE)
			;
		else if (ADF_BARG_ContOnErrorFlag(this_arg, &arg_length, &data_ptr,
			&control_ptr->cont_on_error_flag, &return_code, error_text) ==
			ADF_TRUE)
			;
		else if (ADF_OARG_HyperTextFlag(this_arg, &arg_length, &data_ptr,
			&control_ptr->hyper_text_flag, &return_code, error_text) == ADF_TRUE)
			;
		else if (ADF_OARG_OutputDir(this_arg, &arg_length, &data_ptr,
			&control_ptr->output_dir, &control_ptr->output_dir_basic,
			&return_code, error_text) == ADF_TRUE)
			;
		else if (ADF_OARG_OutputType(this_arg, &arg_length, &data_ptr,
			&control_ptr->output_type, &return_code, error_text) == ADF_TRUE)
			;
		else if (ADF_OARG_OutputByFileFlag(this_arg, &arg_length, &data_ptr,
			&control_ptr->output_by_file_flag, &return_code, error_text) ==
			ADF_TRUE)
			;
		else if (ADF_OARG_OutputToStdoutFlag(this_arg, &arg_length, &data_ptr,
			&control_ptr->output_to_stdout_flag, &return_code, error_text) ==
			ADF_TRUE)
			;
		else if (ADF_OARG_GenerateType(this_arg, &arg_length, &data_ptr,
			&control_ptr->generate_type, &return_code, error_text) == ADF_TRUE)
			;
		else if (ADF_BARG_CludeEntry(this_arg, &arg_length, &data_ptr,
			control_ptr, &return_code, error_text) == ADF_TRUE)
			;
		else if (ADF_BARG_CludeHText(this_arg, &arg_length, &data_ptr,
			control_ptr, &return_code, error_text) == ADF_TRUE)
			;
		else if (ADF_OARG_AreaNameType(this_arg, &arg_length, &data_ptr,
			&control_ptr->area_name_type, &return_code, error_text) == ADF_TRUE)
			;
		else if (ADF_OARG_AreaOrderType(this_arg, &arg_length, &data_ptr,
			&control_ptr->area_order_type, &return_code, error_text) == ADF_TRUE)
			;
		else if (ADF_OARG_AreaName(this_arg, &arg_length, &data_ptr,
			control_ptr->area_name_list, &return_code, error_text) == ADF_TRUE)
			;
		else if (ADF_BARG_IgnoreSection(this_arg, &arg_length, &data_ptr,
			control_ptr->ignore_section_list, &return_code, error_text) ==
			ADF_TRUE)
			;
		else if (ADF_OARG_KeepBadSeeAlso(this_arg, &arg_length, &data_ptr,
			&control_ptr->keep_bad_see_also_flag, &return_code, error_text) ==
			ADF_TRUE)
			;
		else if (ADF_OARG_ExternalHTextRef(this_arg, &arg_length, &data_ptr,
			&tmp_string, &return_code, error_text) == ADF_TRUE) {
			if (return_code == ADF_SUCCESS) {
				if (strl_append(&control_ptr->htext_ref_file_name_count,
					&control_ptr->htext_ref_file_name_list, tmp_string) !=
					STRFUNCS_SUCCESS) {
					GEN_AllocMsgItem(strlen(tmp_string) + 1, error_text,
						"Unable to copy the external reference string '%-.500s'",
						tmp_string);
					return_code = ADF_MEMORY_FAILURE;
				}
				free(tmp_string);
			}
		}
		else if (ADF_OARG_ParseOutParam(this_arg, &arg_length, &data_ptr,
			control_ptr, &return_code, error_text) == ADF_TRUE)
			;
		else if (strl_append(&control_ptr->in_file_name_count,
			&control_ptr->in_file_name_list, this_arg) != STRFUNCS_SUCCESS) {
			strcpy(error_text,
				"Unable to allocate memory for the ADF database file list.");
			return_code = ADF_MEMORY_FAILURE;
		}
	}

	return(return_code);
}
/*	***********************************************************************	*/

/*	***********************************************************************	*/
static void ADF_RUN_OUT_End(control_ptr, signal_number, exit_code_ptr,
	message_buffer)
ADF_CONTROL *control_ptr;
int          signal_number;
int         *exit_code_ptr;
const char  *message_buffer;
{
	unsigned long  total_usecs;
	struct timeval overhead_interval;
	struct timeval total_interval;
	struct rusage  rusage_data;
	char           tmp_buffer_1[512];
	char           tmp_buffer_2[512];
	char           tmp_interval[256];

	if (control_ptr->shut_down_flag == GENFUNCS_TRUE)
		return;

	control_ptr->shut_down_flag = GENFUNCS_TRUE;

	/*	**************************************************************	*/
	/*	**************************************************************	*/
	/*		Get the end time of the program . . .								*/
	/*	**************************************************************	*/
	gettimeofday(&control_ptr->end_time, ((struct timezone *) NULL));
	/*	**************************************************************	*/

	sprintf(tmp_buffer_1, "%s %s %s",
		"========== ===============", "=============",
		"========================================================");
	sprintf(tmp_buffer_2, "%s %s %s",
		"---------- ---------------", "-------------",
		"--------------------------------------------------------");

	/*	**************************************************************	*/
	/*	**************************************************************	*/
	/*		Inform the user that we're bailing out . . .						*/
	/*	**************************************************************	*/
	if (control_ptr->log_file_ptr != NULL) {
		ADF_LogSeparatorEqualChar(control_ptr->log_file_ptr, stderr);
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr,
			stderr, ADF_FALSE, "Exiting . . .\n");
	}
	else if ((ADF_GetLogMessageFlagFILE() == ADF_TRUE) &&
		(control_ptr->help_flag != ADF_TRUE) &&
		(control_ptr->version_flag != ADF_TRUE) &&
		(control_ptr->quiet_flag != ADF_TRUE))
		fprintf(stderr, "Exiting . . .\n");
	/*	**************************************************************	*/

	/*	**************************************************************	*/
	/*	**************************************************************	*/
	/*	**************************************************************	*/
	total_usecs            = GEN_GET_TIMEVAL_USECS(&control_ptr->end_time) -
		GEN_GET_TIMEVAL_USECS(&control_ptr->start_time);
	total_interval.tv_sec  = ((long) total_usecs) / 1000000L;
	total_interval.tv_usec = ((long) total_usecs) % 1000000L;
	if (control_ptr->overhead_end_time.tv_sec ||
		control_ptr->overhead_end_time.tv_usec) {
		total_usecs               =
			GEN_GET_TIMEVAL_USECS(&control_ptr->overhead_end_time) -
			GEN_GET_TIMEVAL_USECS(&control_ptr->start_time);
		overhead_interval.tv_sec  = ((long) total_usecs) / 1000000L;
		overhead_interval.tv_usec = ((long) total_usecs) % 1000000L;
	}
	else {
		overhead_interval.tv_sec  = 0L;
		overhead_interval.tv_usec = 0L;
	}
	/*	**************************************************************	*/

	/*	**************************************************************	*/
	/*	**************************************************************	*/
	/*		Show timing statistics . . .											*/
	/*	**************************************************************	*/
	if (control_ptr->log_file_ptr != NULL) {
		ADF_LogSeparatorString(control_ptr->log_file_ptr, stderr,
			tmp_buffer_1);
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
			ADF_FALSE, "%-28.28s: %s\n", "Start Time",
			GEN_Format_timeval(&control_ptr->start_time, tmp_interval));
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
			ADF_FALSE, "%-28.28s: %s\n", "End Time",
			GEN_Format_timeval(&control_ptr->end_time, tmp_interval));
		ADF_LogSeparatorString(control_ptr->log_file_ptr, stderr,
			tmp_buffer_2);
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
			ADF_FALSE, "%-28.28s: %s\n", "Overhead Time",
			GEN_FormatInterval_timeval(&overhead_interval, tmp_interval));
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
			ADF_FALSE, "%-28.28s: %s\n", "Total Time",
			GEN_FormatInterval_timeval(&total_interval, tmp_interval));
		ADF_LogSeparatorString(control_ptr->log_file_ptr, stderr, tmp_buffer_2);
	}
	/*	**************************************************************	*/

	/*	**************************************************************	*/
	/*	**************************************************************	*/
	/*		Show system resource usage . . .										*/
	/*	**************************************************************	*/
	if (control_ptr->log_file_ptr != NULL) {
		if (getrusage(RUSAGE_SELF, &rusage_data))
			memset(&rusage_data, '\0', sizeof(rusage_data));
		ADF_LogSeparatorString(control_ptr->log_file_ptr, stderr, tmp_buffer_1);
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
			ADF_FALSE, "%-28.28s: %s\n", "Total User Time",
			GEN_FormatInterval_timeval(&rusage_data.ru_utime, tmp_interval));
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
			ADF_FALSE, "%-28.28s: %s\n", "Total System Time",
			GEN_FormatInterval_timeval(&rusage_data.ru_stime, tmp_interval));
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
			ADF_FALSE, "%-28.28s: %10ld\n", "Maximum Resident Set Size",
			rusage_data.ru_maxrss);
#if 0
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
			ADF_FALSE, "%-28.28s: %10ld\n", "?",
			rusage_data.ru_ixrss);
#endif /* #if 0 */
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
			ADF_FALSE, "%-28.28s: %10ld\n", "Integral Resident Set Size",
			rusage_data.ru_idrss);
#if 0
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
			ADF_FALSE, "%-28.28s: %10ld\n", "?",
			rusage_data.ru_isrss);
#endif /* #if 0 */
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
			ADF_FALSE, "%-28.28s: %10ld\n", "Minor Page Faults",
			rusage_data.ru_minflt);
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
			ADF_FALSE, "%-28.28s: %10ld\n", "Major Page Faults",
			rusage_data.ru_majflt);
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
			ADF_FALSE, "%-28.28s: %10ld\n", "Process Swapped Count",
			rusage_data.ru_nswap);
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
			ADF_FALSE, "%-28.28s: %10ld\n", "Block Input Count",
			rusage_data.ru_inblock);
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
			ADF_FALSE, "%-28.28s: %10ld\n", "Block Output Count",
			rusage_data.ru_oublock);
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
			ADF_FALSE, "%-28.28s: %10ld\n", "Messages Sent",
			rusage_data.ru_msgsnd);
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
			ADF_FALSE, "%-28.28s: %10ld\n", "Messages Received",
			rusage_data.ru_msgrcv);
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
			ADF_FALSE, "%-28.28s: %10ld\n", "Signals Received",
			rusage_data.ru_nsignals);
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
			ADF_FALSE, "%-28.28s: %10ld\n", "Voluntary Context Switches",
			rusage_data.ru_nvcsw);
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
			ADF_FALSE, "%-28.28s: %10ld\n", "Involuntary Context Switches",
			rusage_data.ru_nivcsw);
		ADF_LogSeparatorString(control_ptr->log_file_ptr, stderr, tmp_buffer_1);
	}
	/*	**************************************************************	*/

	/*	**************************************************************	*/
	/*	**************************************************************	*/
	/*		Free the memory allocated to store the program name . . .	*/
	/*	**************************************************************	*/
	if (control_ptr->program_name != NULL) {
		free(control_ptr->program_name);
		control_ptr->program_name = NULL;
	}
	/*	**************************************************************	*/

	/*	**************************************************************	*/
	/*	**************************************************************	*/
	/*		Close the log file (if open) and free-up any memory which	*/
	/*	associated with it . . .													*/
	/*	**************************************************************	*/
	if (control_ptr->log_file_ptr != NULL) {
		ADF_LogMessage(NULL, LOG_INFO, control_ptr->log_file_ptr, stderr,
			ADF_FALSE, "Closing the log file '%s'.\n",
			control_ptr->log_file_name);
		ADF_LogSeparatorEndLog(control_ptr->log_file_ptr, stderr);
		ADF_fclose(control_ptr->log_file_ptr);
		control_ptr->log_file_ptr = NULL;
	}
	if (control_ptr->log_dir != NULL) {
		free(control_ptr->log_dir);
		control_ptr->log_dir = NULL;
	}
	if (control_ptr->log_file_name != NULL) {
		free(control_ptr->log_file_name);
		control_ptr->log_file_name = NULL;
	}
	/*	**************************************************************	*/

	ADF_FREE_Control(control_ptr);
}
/*	***********************************************************************	*/

