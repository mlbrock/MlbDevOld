/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	Automated Documentation Facility (ADF) Program Module							*/
/*	***********************************************************************	*/
/*
	File Name			:	%M%

	File Version		:	%I%

	Last Extracted		:	%D%	%T%

	Last Updated		:	%E%	%U%

	File Description	:	Frees an ADF domain.

	Revision History	:	1994-06-13 --- Creation.
									Michael L. Brock
*/
/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*		Necessary include files . . .														*/
/*	***********************************************************************	*/

#include <stdlib.h>

#include "adf.h"

/*	***********************************************************************	*/

/*	***********************************************************************	*/
void ADF_FREE_Domain(ptr)
ADF_DOMAIN *ptr;
{
	if (ptr->domain_name != NULL)
		free(ptr->domain_name);

	if (ptr->domain_description != NULL)
		free(ptr->domain_description);

	strl_remove_all(&ptr->file_type_count,
		&ptr->file_type_list);

	ADF_FREE_Pattern(&ptr->boh_pattern);

	ADF_FREE_Pattern(&ptr->eoh_pattern);

	ADF_FREE_Pattern(&ptr->bol_pattern);

	ADF_FREE_Pattern(&ptr->eol_pattern);

	ADF_FREE_Pattern(&ptr->empty_line_pattern);

	ADF_FREE_Pattern(&ptr->strip_pattern);

	ADF_FREE_SectionList(&ptr->section_count, &ptr->section_list);

	ADF_INIT_Domain(ptr);
}
/*	***********************************************************************	*/

/*	***********************************************************************	*/
void ADF_FREE_DomainList(count, list)
unsigned int  *count;
ADF_DOMAIN   **list;
{
	while (*count)
		ADF_FREE_Domain(*list + --(*count));

	if (*list != NULL)
		free(*list);

	*count = 0;
	*list  = NULL;
}
/*	***********************************************************************	*/

