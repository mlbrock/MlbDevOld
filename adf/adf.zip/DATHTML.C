/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	Automated Documentation Facility (ADF) Program Module							*/
/*	***********************************************************************	*/
/*
	File Name			:	%M%

	File Version		:	%I%

	Last Extracted		:	%D%	%T%

	Last Updated		:	%E%	%U%

	File Description	:	Manages use of the 'ADF_STRING_PAIR' structure.

	Revision History	:	1996-07-03 --- Creation.
									Michael L. Brock
*/
/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*		Necessary include files . . .														*/
/*	***********************************************************************	*/

#include <memory.h>
#include <stdlib.h>

#include "adf.h"

/*	***********************************************************************	*/

/*	***********************************************************************	*/
void ADF_InitDataHTML(html_data_ptr)
ADF_HTML_DATA *html_data_ptr;
{
	memset(html_data_ptr, '\0', sizeof(*html_data_ptr));

	html_data_ptr->author_link_count    = 0;
	html_data_ptr->author_link_list     = NULL;
	html_data_ptr->copyright_link_count = 0;
	html_data_ptr->copyright_link_list  = NULL;

	nstrcpy(html_data_ptr->html_heading_level, "1",
		sizeof(html_data_ptr->html_heading_level) - 1);
}
/*	***********************************************************************	*/

/*	***********************************************************************	*/
void ADF_FreeDataHTML(html_data_ptr)
ADF_HTML_DATA *html_data_ptr;
{
	ADF_StrPairListFree(&html_data_ptr->author_link_count,
		&html_data_ptr->author_link_list);
	ADF_StrPairListFree(&html_data_ptr->copyright_link_count,
		&html_data_ptr->copyright_link_list);

	ADF_InitDataHTML(html_data_ptr);
}
/*	***********************************************************************	*/

