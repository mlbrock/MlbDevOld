/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	Automated Documentation Facility (ADF) Program Module							*/
/*	***********************************************************************	*/
/*
	File Name			:	%M%

	File Version		:	%I%

	Last Extracted		:	%D%	%T%

	Last Updated		:	%E%	%U%

	File Description	:	Removes ADF entries from a list of entries.

	Revision History	:	1996-01-10 --- Creation.
									Michael L. Brock
*/
/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*		Necessary include files . . .														*/
/*	***********************************************************************	*/

#include "adf.h"

/*	***********************************************************************	*/

/*	***********************************************************************	*/
void ADF_RemoveExistingEntry(control_ptr, entry_index)
ADF_CONTROL  *control_ptr;
unsigned int  entry_index;
{
	ADF_RemoveHText(control_ptr->in_entry_list + entry_index,
		&control_ptr->in_htext_count, &control_ptr->in_htext_list);

	mema_remove(&control_ptr->in_entry_count,
		((void **) &control_ptr->in_entry_list), sizeof(ADF_ENTRY),
		entry_index, 1);
}
/*	***********************************************************************	*/

/*	***********************************************************************	*/
void ADF_RemoveHText(entry_ptr, htext_count, htext_list)
const ADF_ENTRY  *entry_ptr;
unsigned int     *htext_count;
ADF_HTEXT       **htext_list;
{
	unsigned int count_1;

	for (count_1 = 0; count_1 < *htext_count; ) {
		if (((*htext_list)[count_1].file_index == entry_ptr->file_index) &&
			((*htext_list)[count_1].entry_index == entry_ptr->entry_index))
			mema_remove(htext_count, ((void **) htext_list),
				sizeof(**htext_list), count_1, 1);
		else
			count_1++;
	}
}
/*	***********************************************************************	*/

