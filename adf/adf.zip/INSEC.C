/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	Automated Documentation Facility (ADF) Program Module							*/
/*	***********************************************************************	*/
/*
	File Name			:	%M%

	File Version		:	%I%

	Last Extracted		:	%D%	%T%

	Last Updated		:	%E%	%U%

	File Description	:	Initializes an ADF section specification.

	Revision History	:	1994-06-13 --- Creation.
									Michael L. Brock
*/
/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*		Necessary include files . . .														*/
/*	***********************************************************************	*/

#include <memory.h>

#include "adf.h"

/*	***********************************************************************	*/

/*	***********************************************************************	*/
void ADF_INIT_Section(ptr)
ADF_SECTION *ptr;
{
	memset(ptr, '\0', sizeof(*ptr));

	ptr->section_name        = NULL;
	ptr->output_section_name = NULL;
	ptr->required_flag       = ADF_FALSE;
	ptr->wrap_flag           = ADF_FALSE;
	ptr->ltrim_flag          = ADF_FALSE;
	ptr->rtrim_flag          = ADF_FALSE;
	ptr->squeeze_flag        = ADF_FALSE;
	ptr->para_format_flag    = ADF_FALSE;
	ptr->char_format_flag    = ADF_FALSE;

	ADF_INIT_Pattern(&ptr->match_pattern);
}
/*	***********************************************************************	*/

/*	***********************************************************************	*/
void ADF_INIT_SectionList(count, list)
unsigned int  count;
ADF_SECTION  *list;
{
	while (count--)
		ADF_INIT_Section(list++);
}
/*	***********************************************************************	*/

