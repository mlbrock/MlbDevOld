/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	Automated Documentation Facility (ADF) Program Module							*/
/*	***********************************************************************	*/
/*
	File Name			:	%M%

	File Version		:	%I%

	Last Extracted		:	%D%	%T%

	Last Updated		:	%E%	%U%

	File Description	:	Attempts to find the specified ADF area.

	Revision History	:	1994-06-15 --- Creation.
									Michael L. Brock
*/
/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*		Necessary include files . . .														*/
/*	***********************************************************************	*/

#include <string.h>

#include "adf.h"

/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	***********************************************************************	*/

extern const ADF_AREA ADF_AreaNameList[];

/*	***********************************************************************	*/

const ADF_AREA *ADF_FIND_AreaByName(area_name, found_index)
const char   *area_name;
unsigned int *found_index;
{
	const ADF_AREA *return_ptr = NULL;
	unsigned int    count_1;

	for (count_1 = 0; count_1 < ADF_AREA_COUNT; count_1++) {
		if (!stricmp(area_name, ADF_AreaNameList[count_1].area_tag)) {
			if (found_index != NULL)
				*found_index = count_1;
			return_ptr = ADF_AreaNameList + count_1;
			break;
		}
	}

	return(return_ptr);
}
/*	***********************************************************************	*/

