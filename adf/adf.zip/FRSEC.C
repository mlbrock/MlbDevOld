/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	Automated Documentation Facility (ADF) Program Module							*/
/*	***********************************************************************	*/
/*
	File Name			:	%M%

	File Version		:	%I%

	Last Extracted		:	%D%	%T%

	Last Updated		:	%E%	%U%

	File Description	:	Frees an ADF section.

	Revision History	:	1994-06-13 --- Creation.
									Michael L. Brock
*/
/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*		Necessary include files . . .														*/
/*	***********************************************************************	*/

#include <stdlib.h>

#include "adf.h"

/*	***********************************************************************	*/

/*	***********************************************************************	*/
void ADF_FREE_SectionList(count, list)
unsigned int   *count;
ADF_SECTION   **list;
{
	while (*count)
		ADF_FREE_Section(*list + --(*count));

	if (*list != NULL)
		free(*list);

	*count = 0;
	*list  = NULL;
}
/*	***********************************************************************	*/

/*	***********************************************************************	*/
void ADF_FREE_Section(ptr)
ADF_SECTION *ptr;
{
	if (ptr->section_name != NULL)
		free(ptr->section_name);

	if (ptr->output_section_name != NULL)
		free(ptr->output_section_name);

	ADF_FREE_Pattern(&ptr->match_pattern);

	ADF_INIT_Section(ptr);
}
/*	***********************************************************************	*/

