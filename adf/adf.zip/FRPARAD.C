/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*	Automated Documentation Facility (ADF) Program Module							*/
/*	***********************************************************************	*/
/*
	File Name			:	%M%

	File Version		:	%I%

	Last Extracted		:	%D%	%T%

	Last Updated		:	%E%	%U%

	File Description	:	Logic to support the freeing of 'ADF_PARA_DATA'
								structures.

	Revision History	:	1996-04-15 --- Creation.
									Michael L. Brock
*/
/*	***********************************************************************	*/

/*	***********************************************************************	*/
/*	***********************************************************************	*/
/*		Necessary include files . . .														*/
/*	***********************************************************************	*/

#include <stdlib.h>

#include "adf.h"

/*	***********************************************************************	*/

/*	***********************************************************************	*/
void ADF_FREE_ParaDataList(para_count, para_list)
unsigned int   *para_count;
ADF_PARA_DATA **para_list;
{
	unsigned int count_1;

	for (count_1 = 0; count_1 < *para_count; count_1++)
		ADF_FREE_ParaData(*para_list + count_1);

	if (*para_list != NULL)
		free(*para_list);

	*para_count = 0;
	*para_list  = NULL;
}
/*	***********************************************************************	*/

/*	***********************************************************************	*/
void ADF_FREE_ParaData(para_ptr)
ADF_PARA_DATA *para_ptr;
{
	if (para_ptr->text_ptr != NULL)
		free(para_ptr->text_ptr);

	ADF_INIT_ParaData(para_ptr);
}
/*	***********************************************************************	*/

